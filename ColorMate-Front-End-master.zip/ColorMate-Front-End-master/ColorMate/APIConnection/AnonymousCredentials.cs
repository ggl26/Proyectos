﻿using Microsoft.Rest;

namespace APIConnection
{
    /* *
    * Sirve para poder realizar las peticiones sin autenticar, luego se cambiará.
    * 
    * */
    public class AnonymousCredential : ServiceClientCredentials
    {
    }
}
