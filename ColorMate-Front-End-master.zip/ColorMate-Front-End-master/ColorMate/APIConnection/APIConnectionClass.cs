﻿using APIConnection.Models;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace APIConnection
{


    public class APIConnectionClass
    {
        private String _url;
        private String _token;
        public String APIUrl { get { return _url; } set { _url = value; } }
        public String Token
        {
            get { return _token; }
            set
            {
                if (value != "" && value != null)
                {
                    client = new APIConnectionClient(new Uri(APIUrl), new Microsoft.Rest.TokenCredentials(value, "Bearer"));
                    _token = value;
                }
                else
                {
                    client = new APIConnectionClient(new Uri(APIUrl), new AnonymousCredential());
                }
            }
        }
        private APIConnectionClient client;

        /*
        * Url donde se encuentra la api, token del usuario en caso de que ya esté logueado null en caso de que sea para loguearse
        */
        public APIConnectionClass(String APIUrl, String token = null )
        {
            this.APIUrl = APIUrl;
            if (token != null)
            {
                client = new APIConnectionClient(new Uri(APIUrl), new Microsoft.Rest.TokenCredentials(token, "Bearer"));
                Token = token;
            }
            else
                client = new APIConnectionClient(new Uri(APIUrl), new AnonymousCredential());
        }
        #region Peticiones al controlador User
        public async Task<User> GetUser() => await client.ApiGetUserGetAsync();

        public async Task RegisterUser(User user) => await client.ApiRegisterUserPostAsync(user);

        public async Task UpdateUser(User user) => await client.ApiUpdateUserPutAsync(user);

        public async Task DeleteUser() => await client.ApiDeleteUserDeleteAsync();
        public async Task<Boolean> LogoutUser()
        {
            Boolean exito = false;
            var result = await client.ApiLogoutPostWithHttpMessagesAsync();

            if (result.Response.ReasonPhrase == "OK")
                exito = true;

            return exito;
        }
        /*
         * Devuelve el token del usuario si el usuario y contraseña son correcto, en caso contrario devuelve "LOGIN INCORRECTO"
         * */
        public async Task<String> LoginUser(User user)
        {
            String resultado;
            try
            {
                var result = await client.ApiLoginUserPostWithHttpMessagesAsync(user);
                var contentString = await result.Response.Content.ReadAsStringAsync();
                JObject obj = (JObject)JsonConvert.DeserializeObject(contentString);
                resultado = obj["result"].ToString();
            }
            catch (Microsoft.Rest.HttpOperationException)
            {
                resultado = "LOGIN INCORRECTO";
            }

            return resultado;

        }

        public async Task/* Cuando se implemente <IFormFile>*/ GetProfileImage() => await client.ApiGetProfileImageGetAsync();

        //  public async Task SetProfileImage(IFormFile img) => /*await cuando se arregle lo de Swagger*/client.ApiSetProfileImagePost(img);
        #endregion

        #region Peticiones al controlador Clothing

        public async Task<IEnumerable<ClothingItem>> GetCloset() => await client.ApiGetClosetGetAsync();

        public async Task<ClothingItem> GetClothingItem(int idClothingItem) => await client.ApiGetClothingItemByIdGetAsync(idClothingItem);

        public async Task UpdateClothingItem(ClothingItem item) => await client.ApiUpdateClothingItemPutAsync(item);

        public async Task DeleteClothingItem(int idClothingItem) => await client.ApiDeleteClothingItemByIdDeleteAsync(idClothingItem);

        public async Task<IEnumerable<ClothingItem>> GetClothingItemCategory(int categoria) => await client.ApiGetClothingItemCategoryByCategoriaGetAsync(categoria);

        #endregion
        
        #region Peticiones al controlador Clasifier
        public async Task AddClothingItem(IFormFile image) => await client.ApiAddClothingItemPostAsync(image);

        public async Task<IEnumerable<ClothingItem>> DoesCombine(IFormFile image) => await client.ApiDoesCombinePostAsync(image);

        public async Task/*<bool> cuando se cambie en controlador*/ CheckOutfit(IFormFile image) => await client.ApiCheckOutfitPostAsync(image);

        public async Task<IEnumerable<ClothingItem>> CombineClothingItem(int idPrenda, double latitud, double longitud) => await client.ApiCombineClothingItemByIdPrendaByLatitudByLongitudGetAsync(idPrenda, latitud, longitud);

        #endregion
    }
}
