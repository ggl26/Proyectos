﻿
namespace APIConnection.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Microsoft.Rest;
    using Microsoft.Rest.Serialization;
    using SQLite;
    using SQLiteNetExtensions.Attributes;

    public partial class ClothPila
    {


        /// <summary>
        /// </summary>
        [PrimaryKey, AutoIncrement]
        public int? Id { get; set; }

        public int? ClothingItemId { get; set; }

        //0 borrado, 1 Modificado
        public int? Action { get; set; }

        public ClothPila() { }

        public ClothPila(int? idc, int? a)
        {
            ClothingItemId = idc;
            Action = a;
        }
    }
}
