﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using ColorMate.Data;
using ColorMate.Droid.Data;
using SQLite;
using Xamarin.Forms;
using SQLiteNetExtensionsAsync.Extensions;

[assembly: Dependency(typeof(SQLite_Android))]
namespace ColorMate.Droid.Data
{
    [BroadcastReceiver]
    public class SQLite_Android : ISQLite
    {

        private SQLiteAsyncConnection con;

        public SQLite_Android()
        {

        }

        public SQLite.SQLiteAsyncConnection GetConnection()
        {
            var sqliteFileName = "CMDB.db3";
            string documentsPath = System.Environment.GetFolderPath(System.Environment.SpecialFolder.Personal);
            var path = Path.Combine(documentsPath, sqliteFileName);
            if (con == null)
                con = new SQLite.SQLiteAsyncConnection(path, SQLiteOpenFlags.ReadWrite | SQLiteOpenFlags.Create | SQLiteOpenFlags.FullMutex,true);

            return con;
        }

        public String GetPath()
        {/*
            var dir = Android.OS.Environment.GetExternalStoragePublicDirectory(Android.OS.Environment.DirectoryDcim);

            var pictures = dir.AbsolutePath + "/Camera";*/

            return System.Environment.GetFolderPath(System.Environment.SpecialFolder.Personal);
        }
    }
}