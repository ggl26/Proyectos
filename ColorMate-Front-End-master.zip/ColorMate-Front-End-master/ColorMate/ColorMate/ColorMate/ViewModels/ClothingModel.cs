﻿using ColorMate.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace ColorMate.ViewModels
{
    public class ClothingModel : BaseViewModel
    {
		public APIConnection.Models.ClothingItem Prenda { get; set; }
		public String colores { get; set; }
		public String categoria { get; set; }
		public List<String> categorias = new List<string>();

		public ClothingModel(APIConnection.Models.ClothingItem item = null)
        {
			if (item.Name == "")
				Title = "Sin nombre";

			else
				Title = item.Name;

                  
            Prenda = item;


			CATEGORY cat = (CATEGORY)Prenda.Category;

			categoria = cat.ToString();

            if (Prenda.Colores == null)
            {
                foreach (var color in Prenda.Colors)
                {
                    COLOR c = (COLOR)color.ItemColor.Color;

                    colores += c.ToString() + ", ";
                }
            }
            else
            {
                foreach (var color in Prenda.Colores)
                {
                    COLOR c = (COLOR)color.Color;

                    colores += c.ToString() + ", ";
                }
            }
			

			/*
			foreach (var category in Enum.GetValues(typeof(CATEGORY))) {
				categorias.Add(category.ToString());
			}*/



			colores = colores.Remove(colores.Length - 2);
        }
    }
}
