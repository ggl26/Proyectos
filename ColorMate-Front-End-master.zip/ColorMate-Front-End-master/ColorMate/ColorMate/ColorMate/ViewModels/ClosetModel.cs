﻿using ColorMate.Models;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using APIConnection;
using APIConnection.Models;
using System.Threading.Tasks;
using System.Net.Http;
using Xamarin.Forms;
using System.IO;
using System.Linq;
using System;

namespace ColorMate.ViewModels
{
    public class ClosetModel : BaseViewModel
    {
        public Dictionary<APIConnection.Models.ClothingItem, ImageSource> Prendas { get; set; }
        public string Icono { get; set; }
        public CATEGORY categoria { get; set; }


        public ClosetModel(string icon, string title, CATEGORY cat, List<APIConnection.Models.ClothingItem> ropa = null, List<ImageSource> imagenes = null)
        {
            Icono = icon;
            Title = title;
            Prendas = new Dictionary<APIConnection.Models.ClothingItem, ImageSource>();
            if (ropa != null)
            {
                //Prendas = ropa;
                int i = 0;
                foreach (var prenda in ropa)
                {
                    if (prenda.Name == "")
                        prenda.Name = "Sin nombre";
                    Prendas.Add(prenda, imagenes[i]);
                    ++i;
                }
            }

            categoria = cat;

            /*
            if(ropa != null)
            {
                for(int i=0; i < ropa.Count(); i++)
                {
                    Prendas.Add(ropa[i]);
                }
            }
            */
        }

        public ClosetModel()
        {
            Icono = null;
            Title = null;
            Prendas = new Dictionary<APIConnection.Models.ClothingItem, ImageSource>();
			categoria = CATEGORY.Abrigo;

        }


    }
}
