﻿using ColorMate.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;


namespace ColorMate.ViewModels
{
    class CategoryModel : BaseViewModel
    {
        public ObservableCollection<ClosetModel> Categorias { get; set; }
        public CategoryModel()
        {
            Title = "Armario";
            Categorias = new ObservableCollection<ClosetModel>();
            agregarCategorias();
        }

        protected void agregarCategorias()
        {
			Categorias.Add(
                new ClosetModel(
                    "outerwear.png",
                    "Abrigos",
					CATEGORY.Abrigo
                    ));
			
			Categorias.Add(
                new ClosetModel(
                    "jacket.jpg",
                    "Chaquetas",
					CATEGORY.Chaqueta
                    ));

			Categorias.Add(
                new ClosetModel(
                    "blazer.png",
                    "Americanas",
					CATEGORY.Americana
                    ));

			Categorias.Add(
                new ClosetModel(
                    "shirt.png",
                    "Camisas",
					CATEGORY.Camisa
                    ));
			
			Categorias.Add(
                new ClosetModel(
                    "knitwear.png",
                    "Jerseys",
					CATEGORY.Jersey
                    ));

            Categorias.Add(
                new ClosetModel(
                    "categoria_pantalon.png",
                    "Pantalones",
					CATEGORY.Pantalon
                    ));

			Categorias.Add(
                new ClosetModel(
                    "shorts.png",
                    "Bermudas",
					CATEGORY.Bermuda
                    ));

			Categorias.Add(
                new ClosetModel(
                    "jeans.png",
                    "Vaqueros",
					CATEGORY.Vaquero
                    ));
			
			Categorias.Add(
                new ClosetModel(
                    "chandal.png",
                    "Chandals",
					CATEGORY.Chandal
            ));

			Categorias.Add(
				new ClosetModel(
					"categoria_camiseta.png",
					"Camisetas",
					CATEGORY.Camiseta
			));

			Categorias.Add(
                new ClosetModel(
                    "polo.png",
                    "Polos",
					CATEGORY.Polo
                    ));

			Categorias.Add(
                new ClosetModel(
                    "sweatshirt.png",
                    "Sudaderas",
					CATEGORY.Sudadera
                    ));

			Categorias.Add(
                new ClosetModel(
                    "vestido.jpeg",
                    "Vestidos",
					CATEGORY.Vestido
                    ));

			Categorias.Add(
                new ClosetModel(
                    "falda.jpeg",
                    "Faldas",
					CATEGORY.Falda
                    ));

			Categorias.Add(
                new ClosetModel(
                    "blusa.jpeg",
                    "Blusas",
					CATEGORY.Blusa
                    ));

			Categorias.Add(
                new ClosetModel(
                    "sueter.jpeg",
                    "Sueters",
					CATEGORY.Sueter
                    ));

			Categorias.Add(
                new ClosetModel(
                    "shoes.jpg",
                    "Zapatos",
					CATEGORY.Zapatos
                    ));

           
            
        }

        public ClosetModel DevolverCategoria(string categoria)
        {
            ClosetModel aux = new ClosetModel();

            for(int i = 0; i < Categorias.Count; i++)
            {
                if(Categorias[i].Title == categoria)
                {
                    return Categorias[i];
                }
            }

            return aux;
        }
    }
}
