﻿using SQLite;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;
using SQLiteNetExtensions.Attributes;
using SQLiteNetExtensions.Extensions;
using SQLiteNetExtensionsAsync.Extensions;
using APIConnection;
using APIConnection.Models;
using System.Net.Http;
using System.IO;
using System.Drawing;
using Android.Graphics;

namespace ColorMate.Data
{
    public class ClothingItemLocalController
    {
        static object locker = new object();
        SQLiteAsyncConnection database;
        String path;

        public ClothingItemLocalController()
        {
            path = DependencyService.Get<ISQLite>().GetPath();

            database = DependencyService.Get<ISQLite>().GetConnection();
            database.CreateTableAsync<ClothingItem>().Wait();
            database.CreateTableAsync<ClothingItemColor>().Wait();
            database.CreateTableAsync<ItemColor>().Wait();
            database.CreateTableAsync<ClothPila>().Wait();
            Dataseeder();
        }

        public async void deleteTableClothingItem()
        {
            database.DeleteAllAsync<ClothingItem>();
        }

        public async void deleteTableClothingItemColor()
        {
            database.DeleteAllAsync<ClothingItemColor>();
        }

        public async void deleteTableClothPila()
        {
            database.DeleteAllAsync<ClothPila>();
        }

        public void AgregarPrenda(ClothingItem ci)
        {
            GuardarImagenLocal(ci);

            AgregarClothingItem(ci);

            foreach (var x in ci.Colors)
            {
                ClothingItemColor cic = ObtenerClothingItemColor((int)x.ItemColor.Color + 1, (int)ci.ClothingItemId);
                ItemColor a = ObtenerItemColor((int)x.ItemColor.Color).Result;
                ActualizarClothingItem(ci, a);
                ActualizarClothingItemColor(cic);
            }
        }

        public void GuardarImagenLocal(ClothingItem ci)
        {
            //1.RECIBIR IMAGENES DE LA API PARA GUARDAR EN BD
            //Nueva Ubicacion Local
            ci.ImageUrl = System.IO.Path.Combine(path, ci.ClothingItemId.ToString() + ".jpg");
            //Guardamos la imagen
            var httpClient = new HttpClient();
            httpClient.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", App.Token);
            string url = "http://colormate.azurewebsites.net/api/getClothingImage/" + ci.ClothingItemId;

            var uri = new Uri(string.Format(url, string.Empty));

            Stream stream = httpClient.GetStreamAsync(url).Result;

            var bitmap = BitmapFactory.DecodeStream(stream);

            var finalStream = new MemoryStream();

            bitmap.Compress(Bitmap.CompressFormat.Jpeg, 50, finalStream);
            bitmap = null;

            finalStream.Position = 0;

            var filename2 = ci.ImageUrl;

            using (var fileStream = File.Create(filename2))
            {
                finalStream.Seek(0, SeekOrigin.Begin);
                finalStream.CopyTo(fileStream);
                fileStream.Close();

                finalStream.Dispose();
                stream.Dispose();
                fileStream.Dispose();
                GC.Collect();
            }
        }

        #region Metodos de la tabla ClothingItem

        public void AgregarClothingItem(ClothingItem ClothingItem, ItemColor ItemColor = null)
        {
            lock (locker)
            {
                database.InsertAsync(ClothingItem);
            }
        }

        public void ActualizarClothingItem(ClothingItem ClothingItem, ItemColor ItemColor = null)
        {
            lock (locker)
            {
                database.UpdateAsync(ClothingItem);

                if (ItemColor != null)
                {
                    if (ClothingItem.Colores == null)
                    {
                        ClothingItem.Colores = new List<ItemColor>();
                    }

                    if (ClothingItem.Colores.Where(x => x.Color == ItemColor.Color).Count() == 0)
                        ClothingItem.Colores.Add(ItemColor);

                    database.UpdateWithChildrenAsync(ClothingItem);
                }
            }
        }


        public void EliminarClothingItem(ClothingItem ClothingItem)
        {
            lock (locker)
            {
                File.Delete(ClothingItem.ImageUrl);
                database.DeleteAsync(ClothingItem);
            }
        }

        public List<ClothingItem> ObtenerClothingItems()
        {
            lock (locker)
            {
            return database.GetAllWithChildrenAsync<ClothingItem>().Result.ToList();
            }
        }

        public List<ClothingItem> ObtenerClothingItemsCategorias(int? categoria)
        {
            lock (locker)
            {
                return database.GetAllWithChildrenAsync<ClothingItem>(x => x.Category == categoria).Result.ToList();
            }
        }

        public async Task<ClothingItem> ObtenerClothingItem(int id)
        {
            lock (locker)
            {

                return database.GetWithChildrenAsync<ClothingItem>(id).Result;

                //return database.Table<ClothingItem>().Where(x => x.ClothingItemId == id).FirstAsync().Result;
            }
        }

        public List<ItemColor> ObteneColoresClothingItem(int id)
        {
            lock (locker)
            {
                return database.GetWithChildrenAsync<ClothingItem>(id).Result.Colores;
            }
        }

        public async Task<bool> EsVaciaClothingItems()
        {
            int i = database.Table<ClothingItem>().CountAsync().Result;
            return (i == 0);
        }

        #endregion

        #region Metodos de la tabla ItemColor
        public void AgregarItemColor(ItemColor ItemColor)
        {
            //lock (locker)
            //{
            database.InsertAsync(ItemColor);
            //}
        }

        public void ActualizarItemColor(ItemColor ItemColor)
        {
            //lock (locker)
            //{
            database.UpdateAsync(ItemColor);
            //}
        }

        public void EliminarItemColor(ItemColor ItemColor)
        {
            //lock (locker)
            //{
            database.DeleteAsync(ItemColor);
            //}
        }

        public List<ItemColor> ObtenerItemColors()
        {
            //lock (locker)
            //{
            return database.GetAllWithChildrenAsync<ItemColor>().Result.ToList();
            //}
        }

        public async Task<ItemColor> ObtenerItemColor(int id)
        {
            lock (locker)
            {
                return database.Table<ItemColor>().Where(x => x.Color == id).FirstAsync().Result;
            }
        }

        public List<ClothingItem> ObtenerClothingItemsColor(int id)
        {
            //lock (locker)
            //{
            return database.GetWithChildrenAsync<ItemColor>(id).Result.ClothingItem;
            //}
        }

        public void Dataseeder()
        {
            for (int i = 0; i < 20; i++)
            {
                ItemColor c = new ItemColor { ItemColorId = i + 1, Color = i };
                AgregarItemColor(c);
            }
        }
        #endregion

        #region Metodos de la tabla ClothingItemColor
        public ClothingItemColor ObtenerClothingItemColor(int idColor, int idClothingItem)
        {
            lock (locker)
            {
                var tabla = database.Table<ClothingItemColor>();
                var num = tabla.Where(x => x.ItemColorId == idColor && x.ClothingItemId == idClothingItem).CountAsync().Result;

                if (num > 0)
                    return tabla.Where(x => x.ItemColorId == idColor && x.ClothingItemId == idClothingItem).FirstAsync().Result;
                else
                    return new ClothingItemColor() { ItemColorId = idColor, ClothingItemId = idClothingItem };
            }
        }


        public void ActualizarClothingItemColor(ClothingItemColor ClothingItemColor)
        {
            lock (locker)
            {
                database.UpdateAsync(ClothingItemColor);
            }
        }
        #endregion

        #region Metodos de la tabla ClothPila
        public void AgregarClothPila(ClothPila ClothPila)
        {
            lock (locker)
            {
                database.InsertAsync(ClothPila);
            }
        }

        public void ActualizarClothPila(ClothPila ClothPila)
        {
            lock (locker)
            {
                database.UpdateAsync(ClothPila);
            }
        }

        public void EliminarClothPila(ClothPila ClothPila)
        {
            lock (locker)
            {
                database.DeleteAsync(ClothPila);
            }
        }

        public async Task<bool> EsVaciaClothPila()
        {
            int i = database.Table<ClothPila>().CountAsync().Result;
            return (i == 0);
        }

        public List<ClothPila> ObtenerClothPilas()
        {
            lock (locker)
            {
                return database.Table<ClothPila>().ToListAsync().Result;
            }
        }

        public async Task<ClothPila> ObtenerClothPila(int? id)
        {
            lock (locker)
            {
                return database.Table<ClothPila>().Where(x => x.ClothingItemId == id).FirstOrDefaultAsync().Result;
            }
        }

        public void AgregarPila(int? id, int? Action)
        {
            ClothPila cp = App.ClothingItemDatabase.ObtenerClothPila(id).Result;
            if (cp != null)
            {
                cp.Action = Action;
                App.ClothingItemDatabase.ActualizarClothPila(cp);
            }
            else
            {
                cp = new ClothPila(id, Action);
                App.ClothingItemDatabase.AgregarClothPila(cp);
            }
        }

        #endregion

        // Sincroniza la bd de azure con local
        public async void SincronizaBDs()
        {
            List<ClothPila> pila = ObtenerClothPilas();

            foreach (var operacion in pila)
            {
                // Borrar
                if (operacion.Action == 0)
                {
                    App.Conexion.DeleteClothingItem((int)operacion.ClothingItemId);
                }
                else // Modificar
                {
                    ClothingItem prenda = ObtenerClothingItem((int)operacion.ClothingItemId).Result;
                    App.Conexion.UpdateClothingItem(prenda);
                }

                // Eliminamos la operacion realizada de a pila
                EliminarClothPila(operacion);
            }
        }
    }
}
