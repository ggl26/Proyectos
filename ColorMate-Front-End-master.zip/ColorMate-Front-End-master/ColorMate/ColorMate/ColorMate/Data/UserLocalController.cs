﻿using Android.Graphics;
using APIConnection;
using APIConnection.Models;
using SQLite;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace ColorMate.Data
{
    public class UserLocalController
    {
        static object locker = new object();
        public SQLiteAsyncConnection database;
        String path;


        public UserLocalController()
        {
            path = DependencyService.Get<ISQLite>().GetPath();

            database = DependencyService.Get<ISQLite>().GetConnection();
            database.CreateTableAsync<User>().Wait();
        }
        
        public async Task<User> GetUser()
        {
            return await database.Table<User>().FirstOrDefaultAsync();
        }

        public async Task<List<User>> GetItemsCat(string email)
        {
            return await database.QueryAsync<User>("SELECT * FROM User WHERE Email = " + email);
        }

        public async Task<User> GetItem(int? id)
        {
            return await database.Table<User>().Where(i => i.UserId == id).FirstOrDefaultAsync();
        }

        public async Task<bool> CheckItem(int? id)
        {
            User x = database.Table<User>().Where(i => i.UserId == id).FirstOrDefaultAsync().Result;

            return id == x.UserId;
        }

        public async Task<int> UpdateItem(User item)
        {
            return await database.UpdateAsync(item);

        }
        public async Task<int> InsertItem(User item)
        {
            GuardarImagenLocal(item);
            return await database.InsertAsync(item);
        }


        public void GuardarImagenLocal(User ci)
        {
            //1.RECIBIR IMAGENES DE LA API PARA GUARDAR EN BD
            //Nueva Ubicacion Local
            ci.ProfilePicUrl = System.IO.Path.Combine(path, "UserProfileImage" + ".jpg");
            //Guardamos la imagen
            var httpClient = new HttpClient();
            httpClient.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", App.Token);
            string url = "http://colormate.azurewebsites.net/api/getProfileImage/";

            var uri = new Uri(string.Format(url, string.Empty));

            Stream stream = httpClient.GetStreamAsync(url).Result;

            var bitmap = BitmapFactory.DecodeStream(stream);

            var finalStream = new MemoryStream();

            bitmap.Compress(Bitmap.CompressFormat.Jpeg, 50, finalStream);
            bitmap = null;

            finalStream.Position = 0;

            var filename2 = ci.ProfilePicUrl;

            using (var fileStream = File.Create(filename2))
            {
                finalStream.Seek(0, SeekOrigin.Begin);
                finalStream.CopyTo(fileStream);
                fileStream.Close();

                finalStream.Dispose();
                stream.Dispose();
                fileStream.Dispose();
                GC.Collect();
            }
        }

        public async Task<int> DeleteItem(User item)
        {
            return await database.DeleteAsync(item);
        }

        public async void deleteTableUser() {
            database.DeleteAllAsync<User>();
        }

        public async Task SincronizarUserBD()
        {
            User usuario = await GetUser();

            if (usuario.Sync == false)
            {
                App.Conexion.UpdateUser(usuario);
                usuario.Sync = true;
                App.UserDatabase.UpdateItem(usuario);
            }
        }

    }
}
