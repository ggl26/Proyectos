﻿using SQLite;
using System;
using System.Collections.Generic;
using System.Text;

using SQLiteNetExtensionsAsync.Extensions;

namespace ColorMate.Data
{
    public interface ISQLite
    {
        SQLiteAsyncConnection GetConnection();
        String GetPath();

    }
}
