﻿using System;
using Android.Preferences;
using ColorMate.Data;
using ColorMate.Views;
using Plugin.Connectivity;
using Xamarin.Forms;
using APIConnection;
using Plugin.Geolocator;


namespace ColorMate
{
	public partial class App : Application
	{
 
        static APIConnectionClass _conexion;
        static UserLocalController userdatabase;
        static ClothingItemLocalController clothingitemdatabase;
        bool hasConnection = false;

        public App ()
		{
            UpdateConnection();
			InitializeComponent();
       
            if (Token != "")
            {
                Conexion = new APIConnectionClass("http://colormate.azurewebsites.net/", Token);
                MainPage = new MasterMenu(0,null);
            }
            else
            {
                Conexion = new APIConnectionClass("http://colormate.azurewebsites.net/");
                MainPage = new Login();

            }

    
 
        }
		protected override void OnStart ()
		{

		}

		protected override void OnSleep ()
		{
			// Handle when your app sleeps
		}

		protected override void OnResume ()
		{
			// Handle when your app resumes
		}


        public static UserLocalController UserDatabase
        {
            get
            {
                if (userdatabase == null)
                {
                    userdatabase = new UserLocalController();
                }
                return userdatabase;
            }
        }

        public static ClothingItemLocalController ClothingItemDatabase
        {
            get
            {
                if (clothingitemdatabase == null)
                {
                    clothingitemdatabase = new ClothingItemLocalController();
                }
                return clothingitemdatabase;
            }
        }

        private async void UpdateConnection()
        {
            if (CrossConnectivity.Current.IsConnected)
                hasConnection = true;
            else
                hasConnection = false;
        }
        public static APIConnectionClass Conexion
        {
            get
            {
                return _conexion;
            }
            set
            {
                _conexion = value;
            }
        }

        public static String Token
        {
            get
            {
                return PreferenceManager.GetDefaultSharedPreferences(Android.App.Application.Context).GetString("token", "");//en caso de que no se encuentre devuelve cadena vacia
            }
            set
            {
                if (value != "")
                {
                    PreferenceManager.GetDefaultSharedPreferences(Android.App.Application.Context).Edit().PutString("token", value).Apply();
                    Conexion.Token = value;
                }
                else
                {
                    PreferenceManager.GetDefaultSharedPreferences(Android.App.Application.Context).Edit().Remove("token").Commit();
                    //Conexion.Token = "";
                }
            }

        }

    }
}
