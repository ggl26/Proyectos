﻿using APIConnection.Models;
using ColorMate.ViewModels;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace ColorMate.Views
{
	[XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class ImagenGrande
    {
		
		public ImagenGrande(ClothingItem prenda)
        {
            InitializeComponent();
			ClothingModel modelo = new ClothingModel(prenda);
            GetImage(prenda);
            BindingContext = modelo;
        }

        public async Task GetImage(ClothingItem prenda)
        {/*
            var httpClient = new HttpClient();
            string url = "http://colormate.azurewebsites.net/api/getClothingImage/" + id;
            httpClient.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", App.Token);
            var uri = new Uri(string.Format(url, string.Empty));
            Stream stream = await httpClient.GetStreamAsync(url);*/

            string path = prenda.ImageUrl;
            var imageSource = ImageSource.FromFile(path);
            ImagenPrenda.Source = imageSource;

        }
    }
}
