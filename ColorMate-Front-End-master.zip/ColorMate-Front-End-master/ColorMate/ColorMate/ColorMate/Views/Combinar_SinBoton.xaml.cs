﻿using APIConnection;
using APIConnection.Models;
using ColorMate.ViewModels;
using Plugin.Media.Abstractions;
using Rg.Plugins.Popup.Services;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace ColorMate.Views
{
    public partial class Combinar_SinBoton : ContentPage
    {

        public IEnumerable<ClothingItem> listaCombinaciones;

        public Combinar_SinBoton(ViewModels.ClothingModel clothingModel)
        {
            InitializeComponent();
            GetImage(clothingModel.Prenda);
            ShowCombineClothingItem((int)clothingModel.Prenda.ClothingItemId);
            //Prueba(clothingModel);
            //Prueba2(clothingModel);
        }

        public async Task Prueba2(ViewModels.ClothingModel clothingModel)
        {
            //int i = await App.ClothingItemDatabase.CountCloths();
            //SearchingCombinationLabel.Text = i.ToString();
            //ClothingItem lci = App.ClothingItemDatabase.ObtenerClothingItem((int)clothingModel.Prenda.ClothingItemId).Result;
            //App.ClothingItemDatabase.EliminarClothingItem(clothingModel.Prenda);

            bool vacia = App.ClothingItemDatabase.EsVaciaClothPila().Result;
            // ClothingItem lci = App.ClothingItemDatabase.ObtenerClothingItems();
            int comprobacion = 1;
        }


        public async Task Prueba(ViewModels.ClothingModel clothingModel)
        {
            App.ClothingItemDatabase.AgregarPrenda(clothingModel.Prenda);
        }

        public async Task GetImage(ClothingItem prenda)
        {
            /*
            var httpClient = new HttpClient();
            string url = "http://colormate.azurewebsites.net/api/getClothingImage/" + id;
            httpClient.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", App.Token);
            var uri = new Uri(string.Format(url, string.Empty));
            Stream stream = await httpClient.GetStreamAsync(url);
            ImagenPrendaCombinar.Source = ImageSource.FromStream(() => stream);*/
            string path = prenda.ImageUrl;

            var imageSource = ImageSource.FromFile(path);
            ImagenPrendaCombinar.Source = imageSource;
        }

        //Mostramos las prendas que combinan en el armario del usuario con la nueva prenda escaneada
        public async Task ShowCombineClothingItem(int id_prenda)
        {
            listaCombinaciones = await App.Conexion.CombineClothingItem(id_prenda,0,0);
            List<ClothingItem> listaItems = listaCombinaciones.ToList();
            //No combina con nada de nuetro armario
            if (listaItems.Count == 0)
            {
                SearchingCombinationLabel.IsVisible = false;
                NoCombinationLabel.IsVisible = true;
            }
            //Nos devuelve la lista de CPrendas con las que combina
            else
            {
                //Para cada una de las prendas obtendremos su imagen y su informacion
                foreach (ClothingItem prenda in listaItems)
                {
                    ClothingItem p = App.ClothingItemDatabase.ObtenerClothingItem((int)prenda.ClothingItemId).Result;
                    GetClothingImage(p.ClothingItemId.Value, p);
                }
            }
        }

        //Obtenemos la imagen de la prenda asociada al id que recibimos
        public async Task GetClothingImage(int id, ClothingItem prenda_combinada)
        {/*
            var httpClient = new HttpClient();
            string url = "http://colormate.azurewebsites.net/api/getClothingImage/" + id;
            httpClient.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", App.Token);
            var uri = new Uri(string.Format(url, string.Empty));
            Stream stream = await httpClient.GetStreamAsync(url);*/
            //Lo guarda en el listview horizontal
            string path = prenda_combinada.ImageUrl;
            var imageSource = ImageSource.FromFile(path);
            anyadeAListView(imageSource, prenda_combinada);
            //anyadeAListView(ImageSource.FromStream(() => stream), prenda_combinada);
        }

        //Permite almacenar miembros al listview horizontal
        public void anyadeAListView(ImageSource url, ClothingItem prenda_combinada)
        {
            ThicknessTypeConverter a = new ThicknessTypeConverter();
            var image = new Image()
            {
                Source = url,
                Aspect = Aspect.AspectFill,
                Margin = (Thickness)a.ConvertFromInvariantString((string)"3,5"),
                HeightRequest = 135,
                WidthRequest = 100,
                VerticalOptions = LayoutOptions.Center,
                HorizontalOptions = LayoutOptions.Center
            };

            //MOSTRARA INFORMACION PARA CADA PRENDA AL TOCAR UN COMPONENTE DEL LISTVIEW
            TapGestureRecognizer imageTap = new TapGestureRecognizer();
            imageTap.Tapped += (sender, e) => {
               
                PopupNavigation.PushAsync(new ViewItemPreview(prenda_combinada));
            };

            image.GestureRecognizers.Add(imageTap);
            this.Scroll.Children.Add(image);
        }

    }
}
