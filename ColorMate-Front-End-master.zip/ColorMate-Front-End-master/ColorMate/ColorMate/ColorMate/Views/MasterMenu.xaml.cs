﻿using APIConnection.Models;
using Plugin.Media.Abstractions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace ColorMate.Views
{
	[XamlCompilation(XamlCompilationOptions.Compile)]
	public partial class MasterMenu : MasterDetailPage
    {
		public MasterMenu ()
		{
			InitializeComponent ();
            //Detail = new NavigationPage(new Inicio());

            IsPresented = false;
            List<Opcion> items = new List<Opcion>();
            items.Add(new Opcion() { IconSource = "Inicio.png", Title = "Inicio", TargetType = typeof(Inicio) });
            items.Add(new Opcion() { IconSource = "Login.png", Title = "Login", TargetType = typeof(Login) });
            items.Add(new Opcion() { IconSource = "Inicio_Perfil.png", Title = "Mi perfil", TargetType = typeof(MyProfile) });
            items.Add(new Opcion() { IconSource = "Inicio_Escaner.png", Title = "Escanear look", TargetType = typeof(Escaner) });
			items.Add(new Opcion() { IconSource = "Inicio_Armario.png", Title = "Mi Armario", TargetType = typeof(Categorias) });
         
            this.listView.ItemsSource = items;
            this.listView.ItemSelected += OnItemSelected;
            this.listView.SelectedItem = items[0];
            


        }

        public MasterMenu(int i,MediaFile photoPath)
        {
            InitializeComponent();
            //Detail = new NavigationPage(new Inicio());
            IsPresented = false;

            List<Opcion> items = new List<Opcion>();
            items.Add(new Opcion() { IconSource = "Inicio.png", Title = "Inicio", TargetType = typeof(Inicio) });

            if (App.Token != "")
            {
                items.Add(new Opcion() { IconSource = "Inicio_Perfil.png", Title = "Mi Perfil", TargetType = typeof(MyProfile) });
            }
            else
            {
                items.Add(new Opcion() { IconSource = "Login.png", Title = "Login", TargetType = typeof(Login) });
            }

            if (App.Token != "")
            {
                items.Add(new Opcion() { IconSource = "Inicio_Escaner.png", Title = "Escanear look", TargetType = typeof(Escaner) });
            
                items.Add(new Opcion() { IconSource = "Inicio_Armario.png", Title = "Mi Armario", TargetType = typeof(Categorias) });

                items.Add(new Opcion() { IconSource = "Login.png", Title = "Cerrar Sesion", TargetType = typeof(Inicio) });
            }


            this.listView.ItemsSource = items;

            this.listView.ItemSelected += OnItemSelected;
            if (i < 5)
            {
                this.listView.SelectedItem = items[i];
            }
            else if (i == 5)
            {
                Registro();
            }
            else if (i == 6)
            {
                Combinar(photoPath);
            }


        }

        void Registro()
        {
            Opcion item = new Opcion() { TargetType = typeof(Registro) };
            Detail = new NavigationPage((Page)Activator.CreateInstance(item.TargetType));
            IsPresented = false;
        }
        void Combinar(MediaFile photoPath)
        {
            Opcion item = new Opcion() { TargetType = typeof(Combinar), photoParameter = photoPath };
            Detail = new NavigationPage((Page)Activator.CreateInstance(item.TargetType, item.photoParameter));
            IsPresented = false;
        }


        async void OnItemSelected(object sender, SelectedItemChangedEventArgs e)
        {
            var item = e.SelectedItem as Opcion;

            if (item != null)
            {
                if (item.TargetType== typeof(Combinar)) {
                    Detail = new NavigationPage((Page)Activator.CreateInstance(item.TargetType,item.photoParameter));
                    //this.listView.SelectedItem = null;
                    IsPresented = false;
                }

                else if (item.TargetType == typeof(Escaner))
                {
                    Navigation.PushModalAsync(new Escaner());
                }
                else if (item.Title == "Cerrar Sesion")
                {

                    Boolean sesionCerrada = await App.Conexion.LogoutUser();
                    if (sesionCerrada)
                    {
                        // Borramos los datos de la tabla del usuario
                        App.UserDatabase.deleteTableUser();

                        // Borramos los datos de la ropa
                        App.ClothingItemDatabase.deleteTableClothingItemColor();
                        App.ClothingItemDatabase.deleteTableClothPila();
                        App.ClothingItemDatabase.deleteTableClothingItem();

                        App.Token = "";
                        Application.Current.MainPage = new MasterMenu(0, null);
                    }
                    IsPresented = false;
                }
                else { 
                Detail = new NavigationPage((Page)Activator.CreateInstance(item.TargetType));
                //this.listView.SelectedItem = null;
                IsPresented = false;
                }
            }
        }

        public class Opcion
        {
            public string IconSource { get; set; }

            public string Title { get; set; }
            public System.Type TargetType { get; set; }
            public MediaFile photoParameter { get; set; }

        }

     
    }
}