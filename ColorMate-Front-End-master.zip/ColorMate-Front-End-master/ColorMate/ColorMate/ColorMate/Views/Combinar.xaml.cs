﻿using APIConnection;
using APIConnection.Models;
using Microsoft.Rest;
using Microsoft.Rest.Serialization;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Org.Json;
using Plugin.Media.Abstractions;
using Rg.Plugins.Popup.Services;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using GeoCoordinatePortable;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using Plugin.Geolocator;
using Plugin.Connectivity;

namespace ColorMate.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class Combinar : ContentPage
    {
        int id_prenda; //ID de la prenda que acabamos de escanear
        ClothingItem prenda = new ClothingItem(); //Lo usaremos cuando vayamos a realizar un update
        MediaFile newClothingItemPhoto;
        IEnumerable<ClothingItem> clothingItemsCombineList;

        public Combinar(MediaFile photo)
        {
            InitializeComponent();
            SearchingCombinationLabel.IsVisible = true;
            newClothingItemPhoto = photo;
            //Recibe la imagen desde Nueva Prenda y la muestra
            ImagenPrendaCombinar.Source = photo.Path;
            //GUARDAMOS PRENDA AL ENTRAR EN LA PÁGINA
            saveClothingItem();
        }


        //En primer lugar guardamos la prenda nada mas acceder a la vista
        public async Task saveClothingItem()
        {
            // Sincronizamos la bd local con la de azure si es necesario
            if (CrossConnectivity.Current.IsConnected)
            {
                // Sincronizacion db local y azure
                App.ClothingItemDatabase.SincronizaBDs();
                App.UserDatabase.SincronizarUserBD();
            }

            string url = "http://colormate.azurewebsites.net/api/addClothingItem/";
            var httpClient = new HttpClient();
            httpClient.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", App.Token);
            var content = new MultipartFormDataContent();
            FileStream file = File.OpenRead(newClothingItemPhoto.Path);
            content.Add(new StreamContent(file), "image", Path.GetFileName(newClothingItemPhoto.Path));
            HttpResponseMessage response = await httpClient.PostAsync(url, content);

            if (response.IsSuccessStatusCode)
            {
                string respuesta_string = await response.Content.ReadAsStringAsync();

                //No se detecta ninguna prenda
                if (respuesta_string.Equals("{\"message\":\"ERROR: No detecto ninguna prenda\"}"))
                {
                    SavingItemLabel.IsVisible = false;
                    SaveButton.IsVisible = false;
                    CancelButton.IsVisible = false;
                    SearchingCombinationLabel.IsVisible = false;
                    NoCombinationLabel.IsVisible = true;
                    NoItemLabel.IsVisible = true;
                    App.Conexion.DeleteClothingItem(id_prenda);
                }

                else if (respuesta_string.Equals("{\"message\":\"ERROR: No detecto ningún color\"}"))
                {
                    SavingItemLabel.IsVisible = false;
                    SaveButton.IsVisible = false;
                    CancelButton.IsVisible = false;
                    SearchingCombinationLabel.IsVisible = false;
                    NoCombinationLabel.IsVisible = true;
                    NoColorsLabel.IsVisible = true;
                    App.Conexion.DeleteClothingItem(id_prenda);
                }
                //Se detecta y guarda la prenda y extraemos su id
                else
                {
                    Int32.TryParse(respuesta_string, out id_prenda);
                    file.Close();

                    // Insertamos la prenda en la bd local
                    // prenda = await App.Conexion.GetClothingItem(id_prenda);

                    url = "http://colormate.azurewebsites.net/api/getClothingItem/" + id_prenda;
                    httpClient.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", App.Token);
                    HttpResponseMessage responsePrenda = await httpClient.GetAsync(url);

                    var respuesta = responsePrenda.Content.ReadAsStringAsync();
                    var prenda = JsonConvert.DeserializeObject<ClothingItem>(respuesta.Result);

                    App.ClothingItemDatabase.AgregarPrenda(prenda);
                }
            }

            else
            {
                SaveButton.IsVisible = false;
                CancelButton.IsVisible = false;
                SavingItemLabel.IsVisible = false;
                SearchingCombinationLabel.IsVisible = false;
                NoCombinationLabel.IsVisible = true;
                NoItemLabel.IsVisible = true;
            }

            //Mostramos las prendas que combinan en el armario del usuario con la nueva prenda escaneada
            await ShowCombineClothingItem();
        }

        //Mostramos con las otras prendas que combina
        public async Task ShowCombineClothingItem()
        {           

            clothingItemsCombineList = await App.Conexion.CombineClothingItem(id_prenda, 0, 0);
            List<ClothingItem> listaItems = clothingItemsCombineList.ToList();
            //No combina con nada de nuetro armario
            if (listaItems.Count==0)
            {
                 SearchingCombinationLabel.IsVisible = false;
                 NoCombinationLabel.IsVisible = true;
            }
            //Nos devuelve la lista de CPrendas con las que combina
            else
            {
                SearchingCombinationLabel.IsVisible = false;
                //Para cada una de las prendas obtendremos su imagen y su informacion
                foreach(ClothingItem prenda in listaItems)
                    {
                    ClothingItem p = App.ClothingItemDatabase.ObtenerClothingItem((int)prenda.ClothingItemId).Result;
                    GetClothingImage(p.ClothingItemId.Value, p);
                }
            }
        }

        //Obtenemos la imagen de la prenda asociada al id que recibimos
        public async Task GetClothingImage(int id, ClothingItem prenda_combinada)
        {
            /*
                var httpClient = new HttpClient();
                httpClient.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", App.Token);
                string url = "http://colormate.azurewebsites.net/api/getClothingImage/" + id;
                var uri = new Uri(string.Format(url, string.Empty));
                Stream stream = await httpClient.GetStreamAsync(url);*/
            //Lo guarda en el listview horizontal
            string path = prenda_combinada.ImageUrl;
            var imageSource = ImageSource.FromFile(path);
            anyadeAListView(imageSource, prenda_combinada);
        }

        //Permite almacenar miembros al listview horizontal
        public void anyadeAListView(ImageSource url, ClothingItem prenda_combinada)
        {
            ThicknessTypeConverter a = new ThicknessTypeConverter();
            var image = new Image()
            {
                Source = url,
                Aspect = Aspect.AspectFill,
                Margin = (Thickness)a.ConvertFromInvariantString((string)"2,5"),
                HeightRequest = 135,
                WidthRequest = 100,
                VerticalOptions = LayoutOptions.Center,
                HorizontalOptions = LayoutOptions.Center
            };

            //MOSTRARA INFORMACION PARA CADA PRENDA AL TOCAR UN COMPONENTE DEL LISTVIEW
            TapGestureRecognizer imageTap = new TapGestureRecognizer();
            imageTap.Tapped += (sender, e) => {
                PopupNavigation.PushAsync(new ViewItemPreview(prenda_combinada));
            };

            image.GestureRecognizers.Add(imageTap);
            this.Scroll.Children.Add(image);
        }

        //Hara un udate de la prenda, con el nombre en caso que se le asigne, al pulsar sobre confirmar
        public async Task UpdateClothingItem_Clicked(object sender, EventArgs e)
        {
            SaveButton.IsVisible = false;
            CancelButton.IsVisible = false;
            SavingItemLabel.IsVisible = true;

            if (!String.IsNullOrEmpty(ClothingItemName.Text))
            {
                // Obtenemos la prenda de la bd local y la actualizamos
                ClothingItem prenda = App.ClothingItemDatabase.ObtenerClothingItem(id_prenda).Result;
                prenda.Name = ClothingItemName.Text;
                App.ClothingItemDatabase.ActualizarClothingItem(prenda);

                // Intentamos actualizarla en azure
                if (CrossConnectivity.Current.IsConnected)
                {
                    // Sincronizacion db local y azure
                    App.ClothingItemDatabase.SincronizaBDs();
                    App.UserDatabase.SincronizarUserBD();

                    App.Conexion.UpdateClothingItem(prenda);
                }
                else // Si no se puede actualizamos la pila
                {
                    App.ClothingItemDatabase.AgregarPila(id_prenda, 1);
                }

                
            }
            SavingItemLabel.IsVisible = false;
            DisplayAlert("Añadir Nueva Prenda", "Prenda añadida a su armario", "OK");
            Application.Current.MainPage = new MasterMenu(0, null);

        }

        //Borraremos la prenda en caso de que el usuario pulse sobre cancelar
        public async Task CancelClothingItem_Clicked(object sender, EventArgs e)
        {
            App.Conexion.DeleteClothingItem(id_prenda);
            Application.Current.MainPage = new MasterMenu(0, null);
        }


        //Sobreescribe para que al volver hacia atrás no cierre la aplicación Y Borra la prenda insertada
        protected override Boolean OnBackButtonPressed()
        {
            App.Conexion.DeleteClothingItem(id_prenda);
            Application.Current.MainPage = new MasterMenu(0, null);
            return true;
        }


    }
    
   
}
