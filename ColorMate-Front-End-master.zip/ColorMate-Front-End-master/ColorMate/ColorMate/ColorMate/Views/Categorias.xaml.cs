﻿using ColorMate.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Http;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using APIConnection;
using APIConnection.Models;
using PruebaAPI;
using Newtonsoft.Json;
using Plugin.Connectivity;

namespace ColorMate.Views
{

    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class Categorias : ContentPage
    {
        CategoryModel viewModel;
        
        public Categorias()
        {
            InitializeComponent();
            // Comprobamos si la bd local esta vacia y hay conexion a Internet
            if (App.ClothingItemDatabase.EsVaciaClothingItems().Result)
            {
                if (CrossConnectivity.Current.IsConnected)
                {
                    string url = "http://colormate.azurewebsites.net/api/getCloset/";
                    var httpClient = new HttpClient();
                    httpClient.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", App.Token);
                    HttpResponseMessage response = httpClient.GetAsync(url).Result;

                    var respuesta = response.Content.ReadAsStringAsync();
                    var ropa = JsonConvert.DeserializeObject<List<ClothingItem>>(respuesta.Result);

                    // Rellenamos la bd local
                    foreach (var prenda in ropa)
                    {
                        App.ClothingItemDatabase.AgregarPrenda(prenda);
                    }
                }
                else
                {
                    
                }
            }

            // var r = App.ClothingItemDatabase.ObtenerClothingItems();

            BindingContext = viewModel = new CategoryModel();
        }


        async void OnItemSelected(object sender, SelectedItemChangedEventArgs args)
        {
			ClosetModel item = args.SelectedItem as ClosetModel;
            if (item == null)
                return;
            //var a = await App.Conexion.GetClothingItemCategory((int)item.categoria);
            var a = App.ClothingItemDatabase.ObtenerClothingItemsCategorias((int?)item.categoria);

            await Navigation.PushAsync(new Closet(item.Icono, item.Title, item.categoria, a));
            ItemsListView.SelectedItem = null;
        }

		//Sobreescribe para que al volver hacia atrás no cierre la aplicación 
        protected override Boolean OnBackButtonPressed()
        {
            
            Application.Current.MainPage = new MasterMenu(0, null);
            return true;
        }


    }
}
