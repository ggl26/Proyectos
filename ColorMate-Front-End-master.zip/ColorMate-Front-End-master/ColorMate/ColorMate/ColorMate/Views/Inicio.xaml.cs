﻿using Plugin.Connectivity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace ColorMate.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class Inicio : ContentPage
    {
        public Inicio()
        {
            InitializeComponent();
        }


        async void OnButtonClicked(object sender, EventArgs e)
        {
            if (App.Token != "")
            {
                await Navigation.PushModalAsync(new MasterMenu(3, null));

                if (CrossConnectivity.Current.IsConnected)
                {
                }
                else
                {
                    await DisplayAlert("Error de conexión", "Hay un problema con la conexión, por favor, comprueba que tengas acceso a Internet", "OK");
                }
            }
            else
            {
                await Navigation.PushModalAsync(new MasterMenu(1, null));
            }
        }
        async void OnButtonClicked_MiPerfil(object sender, EventArgs e)
        {
            await Navigation.PushModalAsync(new MasterMenu(1, null));
        }

        async void OnButtonClicked_Escaner(object sender, EventArgs e)
        {
            //No llamar a la master
            if (App.Token != "")
            {
                if (CrossConnectivity.Current.IsConnected)
                {
                    await Navigation.PushModalAsync(new Escaner());
                }
                else
                {
                    await DisplayAlert("Error de conexión", "Hay un problema con la conexión, por favor, comprueba que tengas acceso a Internet", "OK");
                }
            }
            else
            {
                await Navigation.PushModalAsync(new MasterMenu(1, null));
            }
        }

        async void OnButtonClicked_PrendaNueva(object sender, EventArgs e)
        {
            //No llamar a la master
            if (App.Token != "")
            {
                if (CrossConnectivity.Current.IsConnected)
                {
                    await Navigation.PushModalAsync(new NuevaPrenda());
                }
                else
                {
                    await DisplayAlert("Error de conexión", "Hay un problema con la conexión, por favor, comprueba que tengas acceso a Internet", "OK");
                }
            }
            else
            {
                await Navigation.PushModalAsync(new MasterMenu(1, null));
            }
        }

        async void OnButtonClicked_Combinaciones(object sender, EventArgs e)
        {
            //No llamar a la master
            await DisplayAlert("Combinaciones", "Esta función estará disponible en futuras actualizaciones", "OK");
        }

        async void OnButtonClicked_Agenda(object sender, EventArgs e)
        {
            //No llamar a la master
            await DisplayAlert("Agenda", "Esta función estará disponible en futuras actualizaciones", "OK");
        }
    }
}