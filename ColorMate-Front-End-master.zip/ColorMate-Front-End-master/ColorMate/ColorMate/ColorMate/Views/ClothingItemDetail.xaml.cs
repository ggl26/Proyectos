﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using APIConnection;
using APIConnection.Models;
using ColorMate.Views;
using ColorMate.ViewModels;
using System.Collections.ObjectModel;
using System.Net.Http;
using Rg.Plugins.Popup;
using Plugin.Connectivity;
using Rg.Plugins.Popup.Services;

namespace ColorMate.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class ClothingItemDetail : ContentPage
    {
        ClothingModel viewModel;
		APIConnection.Models.ClothingItem prenda;
		CATEGORY seleccion;

		public ClothingItemDetail(ClothingModel viewModel)
        {
            InitializeComponent();

			GetImage(viewModel.Prenda);
			prenda = viewModel.Prenda;
           
			GetPrenda((int)viewModel.Prenda.ClothingItemId);
            BindingContext = this.viewModel = viewModel;
        }


		public async Task GetPrenda(int id)
        {

            //prenda = await App.Conexion.GetClothingItem(id);
            prenda = await App.ClothingItemDatabase.ObtenerClothingItem(id);
        }

      

		async void OnButtonClicked_Combinar(object sender, EventArgs e)
        {
            if (CrossConnectivity.Current.IsConnected)
            {
                await Navigation.PushAsync(new Combinar_SinBoton(viewModel));
            }
            else
            {
                await DisplayAlert("Error de conexión", "Hay un problema con la conexión, por favor, comprueba que tengas acceso a Internet", "OK");
            }
        }

		async void OnButtonClicked_Borrar(object sender, EventArgs e)
        {
            int idPrenda = (int)prenda.ClothingItemId;

            // Borramos la prenda en la bd local
            App.ClothingItemDatabase.EliminarClothingItem(prenda);

            // Intentamos borrarla en azure
            if (CrossConnectivity.Current.IsConnected)
            {
                // Sincronizacion db local y azure
                App.ClothingItemDatabase.SincronizaBDs();
                App.UserDatabase.SincronizarUserBD();

                App.Conexion.DeleteClothingItem((int)prenda.ClothingItemId);
            }
            else // Si no se puede actualizamos la pila
            {
                App.ClothingItemDatabase.AgregarPila(idPrenda, 0);
            }

            DisplayAlert("Detalles prenda", "Prenda eliminada", "OK");
        }

		async void OnButtonClicked_Guardar(object sender, EventArgs e)
        {
			if (String.IsNullOrEmpty(EntradaNombre.Text) && Categorias.SelectedIndex==-1)
            {
                await DisplayAlert("Modificación fallida", "Falta algún campo por rellenar", "OK");
            }
            else
            {
				if (!String.IsNullOrEmpty(EntradaNombre.Text))
				    prenda.Name = EntradaNombre.Text;
                            
                // selecciona un cambio de categoria
				if (Categorias.SelectedIndex!=-1)
				    prenda.Category = Categorias.SelectedIndex;

                // Actualizamos la prenda en la bd local
                App.ClothingItemDatabase.ActualizarClothingItem(prenda);

                // Intentamos actualizarla en azure
                if (CrossConnectivity.Current.IsConnected)
                {
                    // Sincronizacion db local y azure
                    App.ClothingItemDatabase.SincronizaBDs();
                    App.UserDatabase.SincronizarUserBD();

                    App.Conexion.UpdateClothingItem(prenda);
                }
                else // Si no se puede actualizamos la pila
                {
                    App.ClothingItemDatabase.AgregarPila(prenda.ClothingItemId, 1);
                }
                
                DisplayAlert("Detalles prenda", "Modificación completada con éxito", "OK");
            }
            
        }
        
        
		public async Task GetImage(ClothingItem prenda)
        {
            string path = prenda.ImageUrl;


            var imageSource = ImageSource.FromFile(path);
            ImagenPrenda.Source = imageSource;

            //MOSTRARA INFORMACION PARA CADA PRENDA AL TOCAR UN COMPONENTE DEL LISTVIEW
            TapGestureRecognizer imageTap = new TapGestureRecognizer();
            imageTap.Tapped += (sender, e) => {
				PopupNavigation.PushAsync(new ImagenGrande(prenda));
            };

			ImagenPrenda.GestureRecognizers.Add(imageTap);
        }

		//Sobreescribe para que al volver hacia atrás no cierre la aplicación 
        protected override Boolean OnBackButtonPressed()
        {
            
            Application.Current.MainPage = new MasterMenu(3, null);
            return true;
        }
    
    }
}
