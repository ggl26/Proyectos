﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using APIConnection;
using APIConnection.Models;
using Newtonsoft.Json;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace ColorMate.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class Registro : ContentPage
    {
        public Registro()
        {
            InitializeComponent();
        }

        public async Task RegisterUser_Clicked(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(FirstNameEntry.Text) || String.IsNullOrEmpty(LastNameEntry.Text) || String.IsNullOrEmpty(EmailEntry.Text) || String.IsNullOrEmpty(PasswordEntry.Text))
            {
                await DisplayAlert("Registro Fallido", "Falta algún campo por rellenar", "OK");
            }
            else if (PasswordEntry.Text.Length < 6)
            {
                await DisplayAlert("Error en contraseña", "La contraseña debe contener al menos 6 caracteres", "OK");
            }
            else { 
                User usuario=new User();
                usuario.Name = FirstNameEntry.Text;
                usuario.Surnames = LastNameEntry.Text;
                usuario.Email = EmailEntry.Text;
                usuario.Password = PasswordEntry.Text;
                usuario.Birthdate = BirthDateEntry.Date;
                App.Conexion.RegisterUser(usuario);

                DisplayAlert("Registro", "Usuario creado correctamente", "OK");
                Navigation.PushModalAsync(new MasterMenu(1, null));
            }
        }
        
    }
}
