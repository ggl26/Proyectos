﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Plugin.Media.Abstractions;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using PruebaAPI;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace ColorMate.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class Escaner : ContentPage
    {
        public Escaner()
        {
            Camara_Al_Inicio();
            InitializeComponent();
        }

        //NOS MOSTRARÁ LA CÁMARA AL ABRIR ESCANER PERMITIENDONOS REALIZAR UNA FOTO
        public async void Camara_Al_Inicio()
        {
            if (!Plugin.Media.CrossMedia.Current.IsCameraAvailable || !Plugin.Media.CrossMedia.Current.IsTakePhotoSupported)
            {
                await DisplayAlert("No Camera", "Camara no disponible", "OK");
                return;
            }
            var photo = await Plugin.Media.CrossMedia.Current.TakePhotoAsync(new Plugin.Media.Abstractions.StoreCameraMediaOptions()
            {
                CompressionQuality = 70,
                PhotoSize = PhotoSize.Small,
                // SaveToAlbum = true,
                Name = "Escaner_Look.jpg"
            });

            if (photo != null)
            {
                PhotoImage.Source = ImageSource.FromStream(() => photo.GetStream());
                LabelLook.IsVisible = false;
                PhotoImage.IsVisible = true;
                string path = photo.Path.ToString();
                await EscanearImagen(photo);//Mandamos el post hacia la API
            }
            else
            {
                Application.Current.MainPage = new MasterMenu(0, null);
            }
        }


        //LO UTILIZAREMOS CUANDO QUERAMOS SUBIR UNA FOTO DESDE NUESTRA GALERÍA
        private async void UploadImageButton_Clicked(object sender, EventArgs e)
        {
            LabelLookError.IsVisible = false;
            LabelLook.IsVisible = false;
            LabelLookCorrecto.IsVisible = false;
            LikeImage.IsVisible = false;
            LabelLookIncorrecto.IsVisible = false;
            DislikeImage.IsVisible = false;
            LabelLookErrorPrenda.IsVisible = false;
            LabelLookCargando.IsVisible = true;
            ProcesandoImage.IsVisible = true;

            if (!Plugin.Media.CrossMedia.Current.IsPickPhotoSupported)
            {
                await DisplayAlert("No Upload", "Subir foto no disponible", "OK");
                return;
            }
            var photo = await Plugin.Media.CrossMedia.Current.PickPhotoAsync(new Plugin.Media.Abstractions.PickMediaOptions()
            {
                
                CompressionQuality = 70,
                PhotoSize = PhotoSize.Small,
            });
            
            if (photo != null)
            {
                PhotoImage.Source = ImageSource.FromStream(() => photo.GetStream());
                var image = new Image { Source = ImageSource.FromStream(() => photo.GetStream()) };
                LabelLook.IsVisible = false;
                PhotoImage.IsVisible = true;
                string path = photo.Path.ToString();
                await EscanearImagen(photo);//Mandamos el post hacia la API
            }
            else
            {
                PhotoImage.IsVisible = false;
                LabelLookCorrecto.IsVisible = false;
                LikeImage.IsVisible = false;
                LabelLookIncorrecto.IsVisible = false;
                DislikeImage.IsVisible = false;
                LabelLookErrorPrenda.IsVisible = false;
                LabelLookCargando.IsVisible = false;
                ProcesandoImage.IsVisible = false;
                LabelLook.IsVisible = false;
                LabelLookError.IsVisible = true;
            }
        }

        //LO UTILIZAREMOS CUANDO QUERAMOS HACER UNA NUEVA FOTO PARA ANALIZAR
        private async void TakeImageButton_Clicked(object sender, EventArgs e)
        {
            LabelLookError.IsVisible = false;
            LabelLook.IsVisible = false;
            LabelLookCorrecto.IsVisible = false;
            LikeImage.IsVisible = false;
            LabelLookIncorrecto.IsVisible = false;
            DislikeImage.IsVisible = false;
            LabelLookErrorPrenda.IsVisible = false;
            LabelLookCargando.IsVisible = true;
            ProcesandoImage.IsVisible = true;

            if (!Plugin.Media.CrossMedia.Current.IsCameraAvailable || !Plugin.Media.CrossMedia.Current.IsTakePhotoSupported)
            {
                await DisplayAlert("No Camera", "Camara no disponible", "OK");
                return;
            }
            var photo = await Plugin.Media.CrossMedia.Current.TakePhotoAsync(new Plugin.Media.Abstractions.StoreCameraMediaOptions()
            {
                CompressionQuality = 70,
                PhotoSize = PhotoSize.Small,
                SaveToAlbum = false,
                Name = "Escaner_Look.jpg"
            });

            if (photo != null)
            {
                PhotoImage.Source = ImageSource.FromStream(() => photo.GetStream());
                LabelLook.IsVisible = false;
                PhotoImage.IsVisible = true;
                string path = photo.Path.ToString();
                await EscanearImagen(photo);//Mandamos el post hacia la API
            }
            else
            {
                Application.Current.MainPage = new MasterMenu(0, null);
            }
        }

        //POST
        //Método empleada para mandar el post con la imagen hacia la API y que nos muestre el resultado obtenido
        public async Task EscanearImagen(MediaFile photo)
        {
            string url = "http://colormate.azurewebsites.net/api/checkOutfit/";
            LabelLookError.IsVisible = false;
            LabelLookCorrecto.IsVisible = false;
            LikeImage.IsVisible = false;
            LabelLookIncorrecto.IsVisible = false;
            DislikeImage.IsVisible = false;
            LabelLookErrorPrenda.IsVisible = false;
            LabelLookCargando.IsVisible = true;
            ProcesandoImage.IsVisible = true;

            //  Petición a la API 
            if (App.Token != "")
            {
                var httpClient = new HttpClient();
                httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", App.Token);
                var content = new MultipartFormDataContent();
                FileStream file = File.OpenRead(photo.Path);
                content.Add(new StreamContent(file), "image", Path.GetFileName(photo.Path));
                HttpResponseMessage response = await httpClient.PostAsync(url, content);

                //PETICION CORRECTA

                if (response.IsSuccessStatusCode)
                {
                    string respuesta_string = await response.Content.ReadAsStringAsync();
                    Console.Out.WriteLine("Response: \r\n {0}", respuesta_string);
                    file.Close();

                    if (respuesta_string.Equals("{ \"message\":\"La ropa no combina\"}"))
                    {
                        LabelLookCargando.IsVisible = false;
                        ProcesandoImage.IsVisible = false;
                        LabelLookIncorrecto.IsVisible = true;
                        DislikeImage.IsVisible = true;
                    }

                    else if (respuesta_string.Equals("{\"message\":\"ERROR: No detecto ninguna prenda\"}"))
                    {
                        PhotoImage.IsVisible = false;
                        LabelLookCargando.IsVisible = false;
                        ProcesandoImage.IsVisible = false;
                        LabelLookErrorPrenda.IsVisible = true;
                    }
                    //LA ROPA COMBINA
                    else
                    {
                        LabelLookCargando.IsVisible = false;
                        ProcesandoImage.IsVisible = false;
                        LabelLookCorrecto.IsVisible = true;
                        LikeImage.IsVisible = true;
                    }
                }
                //PETICION INCORRECTA
                else
                {
                    try
                    {
                        if (Clasificador.combina(photo.Path))
                        {

                            LabelLookCargando.IsVisible = false;
                            ProcesandoImage.IsVisible = false;
                            LabelLookCorrecto.IsVisible = true;
                            LikeImage.IsVisible = true;
                        }

                        else
                        {
                            LabelLookCargando.IsVisible = false;
                            ProcesandoImage.IsVisible = false;
                            LabelLookIncorrecto.IsVisible = true;
                            DislikeImage.IsVisible = true;
                        }
                    }
                    catch(LibraryException ex)
                    {
                        if (ex.Message == "ERROR: No detecto ninguna prenda")
                        {
                            PhotoImage.IsVisible = false;
                            LabelLookCargando.IsVisible = false;
                            ProcesandoImage.IsVisible = false;
                            LabelLookErrorPrenda.IsVisible = true;
                        }
                    }
                }
            }
            else
            {
                //LLAMA A LA LIBRERIA

                try
                {
                    if (Clasificador.combina(photo.Path))
                    {

                        LabelLookCargando.IsVisible = false;
                        ProcesandoImage.IsVisible = false;
                        LabelLookCorrecto.IsVisible = true;
                        LikeImage.IsVisible = true;
                    }

                    else
                    {
                        LabelLookCargando.IsVisible = false;
                        ProcesandoImage.IsVisible = false;
                        LabelLookIncorrecto.IsVisible = true;
                        DislikeImage.IsVisible = true;
                    }
                }
                catch (Exception ex)
                {
                    if (ex.Message == "ERROR: No detecto ninguna prenda")
                    {
                        PhotoImage.IsVisible = false;
                        LabelLookCargando.IsVisible = false;
                        ProcesandoImage.IsVisible = false;
                        LabelLookErrorPrenda.IsVisible = true;
                    }
                }
            }

        }
        

    }
}
