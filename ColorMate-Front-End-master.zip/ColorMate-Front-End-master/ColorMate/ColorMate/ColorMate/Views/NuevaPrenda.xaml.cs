﻿using Plugin.Media.Abstractions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace ColorMate.Views
{
	[XamlCompilation(XamlCompilationOptions.Compile)]
	public partial class NuevaPrenda : ContentPage
	{
		public NuevaPrenda ()
		{
			InitializeComponent ();
            Camara_Al_Inicio();

        }

        public async void Camara_Al_Inicio()
        {
            if (!Plugin.Media.CrossMedia.Current.IsCameraAvailable || !Plugin.Media.CrossMedia.Current.IsTakePhotoSupported)
            {
                await DisplayAlert("No Camera", "Camara no disponible", "OK");
                return;
            }
            var photo = await Plugin.Media.CrossMedia.Current.TakePhotoAsync(new Plugin.Media.Abstractions.StoreCameraMediaOptions()
            {
                CompressionQuality = 70,
                PhotoSize = PhotoSize.Small,
                // SaveToAlbum = true,
                Name = "Nueva_Prenda.jpg"
            });

            if (photo != null)
            {
                Application.Current.MainPage = new MasterMenu(6, photo);
            }
            else
            {
                Application.Current.MainPage = new MasterMenu(0, null);
            }
        }



    }
}