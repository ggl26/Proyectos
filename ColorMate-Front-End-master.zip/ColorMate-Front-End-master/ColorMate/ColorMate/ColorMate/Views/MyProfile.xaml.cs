﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using APIConnection;
using APIConnection.Models;
using Plugin.Connectivity;
using Plugin.Media.Abstractions;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace ColorMate.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class MyProfile : ContentPage
    {
        Boolean ActualizaFoto = false;
        public User usuario;
        public User u;
        public bool exists;
        MediaFile photo;

        public MyProfile()
        {
            InitializeComponent();
            GetProfileImage();
            GetUserInfo();

        }

        public async Task GetProfileImage()
        {
            /*var httpClient = new HttpClient();
            httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", App.Token);
            string url = "http://colormate.azurewebsites.net/api/getProfileImage/";
            var uri = new Uri(string.Format(url, string.Empty));

            Stream stream = await httpClient.GetStreamAsync(url);*/
            usuario = await App.UserDatabase.GetUser();

            string path = usuario.ProfilePicUrl;

            var imageSource = ImageSource.FromFile(path);
            ImageProfile.Source = imageSource;
        }
        public async Task GetExists(int id)
        {
            //COMPROBAMOS SI ESTA EN LA BD
            exists = await App.UserDatabase.CheckItem(id);
        }

        public async Task GetUserInfo()
        {

            usuario =await  App.UserDatabase.GetUser();
            EntradaEmail.Text = usuario.Email;
            EntradaNombre.Text = usuario.Name;
            EntradaApellido.Text = usuario.Surnames;
            EntradaNacimiento.Date = usuario.Birthdate.Value;

        }

        private async void ChangeData_Clicked(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(EntradaNombre.Text) || String.IsNullOrEmpty(EntradaApellido.Text) || String.IsNullOrEmpty(EntradaEmail.Text))
            {
                await DisplayAlert("Modificación fallida", "Falta algún campo por rellenar", "OK");
            }
            else
            {
                usuario.Name = EntradaNombre.Text;
                usuario.Surnames = EntradaApellido.Text;
                usuario.Birthdate = EntradaNacimiento.Date;
                Console.Out.WriteLine("Response: \r\n {0}", usuario.Name);
 //               conexion.UpdateUser(usuario.UserId.Value, usuario);
                if (ActualizaFoto) { 
                    setProfileImage(photo);
                }

                // Actualizamos el usuario en la bd local
                App.UserDatabase.UpdateItem(usuario);

                // Intentamos actualizarlo en azure
                if (CrossConnectivity.Current.IsConnected)
                {
                    // Sincronizacion db local y azure
                    App.ClothingItemDatabase.SincronizaBDs();
                    App.UserDatabase.SincronizarUserBD();

                    App.Conexion.UpdateUser(usuario);
                }
                else
                {
                    usuario.Sync = false;
                    App.UserDatabase.UpdateItem(usuario);
                }


                DisplayAlert("Mi Perfil", "Modificación completada con éxito", "OK");
            }
        }

        private async void ChangePhot_Clicked(object sender, EventArgs e)
        {
             photo = await Plugin.Media.CrossMedia.Current.PickPhotoAsync(new Plugin.Media.Abstractions.PickMediaOptions()
            {

                CompressionQuality = 70,
                PhotoSize = PhotoSize.Medium,
            });

            if (photo != null)
            {
                ImageProfile.Source = ImageSource.FromStream(() => photo.GetStream());
                ActualizaFoto = true;
            }


        }

        public async Task setProfileImage(MediaFile photo)
        {
            usuario = await App.UserDatabase.GetUser();
            usuario.ProfilePicUrl = photo.Path;

            if (CrossConnectivity.Current.IsConnected)
            {
                string url = "http://colormate.azurewebsites.net/api/setProfileImage/";

                //  Petición a la API 
                var httpClient = new HttpClient();
                httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", App.Token);
                var content = new MultipartFormDataContent();
                FileStream file = File.OpenRead(photo.Path);
                content.Add(new StreamContent(file), "image", Path.GetFileName(photo.Path));
                HttpResponseMessage response = await httpClient.PostAsync(url, content);

                //PETICION CORRECTA

                if (response.IsSuccessStatusCode)
                {
                    string respuesta_string = await response.Content.ReadAsStringAsync();
                    Console.Out.WriteLine("Response: \r\n {0}", respuesta_string);
                    file.Close();
                }
            }
            else
            {
                usuario.Sync = false;
            }
            App.UserDatabase.UpdateItem(usuario);


        }
    }
}
 