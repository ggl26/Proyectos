﻿using APIConnection;
using APIConnection.Models;
using System;
using Android.Content;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using APIConnection;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using Android.Preferences;
using System.Net.Http;
using System.Net.Http.Headers;
using Newtonsoft.Json;

namespace ColorMate.Views
{
	[XamlCompilation(XamlCompilationOptions.Compile)]
	public partial class Login : ContentPage
	{
        public Login ()
		{
			InitializeComponent ();
		}

        async void OnButtonClicked_SinSesion(object sender, EventArgs e)
        {
            Application.Current.MainPage = new MasterMenu(0, null);
        }

        async void OnButtonClicked_Registro(object sender, EventArgs e)
        {
            Application.Current.MainPage = new MasterMenu(5, null);
        }

        async void OnButtonClicked_Login(object sender, EventArgs e)
        {

            APIConnection.Models.User user = new APIConnection.Models.User()
            {
                Email = EmailEntry.Text,
                Password = PasswordEntry.Text
            };
            String token = await App.Conexion.LoginUser(user);
            if (token != "LOGIN INCORRECTO")
            { // ya tendriamos el token que nos autoriza a realizar peticiones y con la variable conexion podriamos hacer las peticiones.
                App.Token = token;
                Application.Current.MainPage = new MasterMenu(0, null);

                // Obtenemos los datos del usuario de azure
                var httpClient = new HttpClient();
                httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", App.Token);
                string url = "http://colormate.azurewebsites.net/api/getUser/";
                HttpResponseMessage response = httpClient.GetAsync(url).Result;

                var respuesta = response.Content.ReadAsStringAsync();
                var usuario = JsonConvert.DeserializeObject<User>(respuesta.Result);

                // Insertamos el usuario en la bd local
                App.UserDatabase.InsertItem(usuario);
            }
            else
                await DisplayAlert("Login", "El usuario o la contraseña son incorrectos", "OK");
           
          


            //User user = new User();
            //if (user.checkUser())
            //{/*
            //    App.UserDatabase.SaveUser(user);
            //    if (App.UserDatabase.GetUser().Name == user.Name)
            //    {
            //        await DisplayAlert("Login", "Bienvenido!", "OK");
            //        EmailEntry.Text = App.UserDatabase.GetUser().Name;
            //    }*/
            //}
            //else
            //{
            //    await Navigation.PushModalAsync(new Inicio());
            //}
            
        }
        


    }
}