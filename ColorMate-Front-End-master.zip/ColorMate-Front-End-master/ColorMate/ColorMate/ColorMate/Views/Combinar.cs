﻿using System;

using Xamarin.Forms;

namespace ColorMate.Views
{
    public class Combinar : ContentPage
    {
        public Combinar()
        {
            Content = new StackLayout
            {
                Children = {
                    new Label { Text = "Hello ContentPage" }
                }
            };
        }
    }
}

