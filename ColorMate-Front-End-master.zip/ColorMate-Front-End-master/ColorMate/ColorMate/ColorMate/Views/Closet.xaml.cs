﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

using ColorMate.Models;
using ColorMate.Views;
using ColorMate.ViewModels;
using System.Collections.ObjectModel;
using System.Net.Http;
using Plugin.Connectivity;

namespace ColorMate.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class Closet : ContentPage
    {
        ClosetModel viewModel;


        public Closet(string icono, string title, CATEGORY cat, IEnumerable<APIConnection.Models.ClothingItem> ropa = null)
        {
            InitializeComponent();

            var httpClient = new HttpClient();

            if (CrossConnectivity.Current.IsConnected)
            {
                // Sincronizacion db local y azure
                App.ClothingItemDatabase.SincronizaBDs();
                App.UserDatabase.SincronizarUserBD();
                ropa = App.ClothingItemDatabase.ObtenerClothingItemsCategorias((int?)cat);
            }

            var aux = ropa.ToList();
            List<ImageSource> imagenes = new List<ImageSource>();
            foreach (var prenda in aux)
            {
                GetImagen(prenda, imagenes);
            }
            

            BindingContext = viewModel = new ClosetModel(icono, title, cat, aux, imagenes);
        }


        async void OnItemSelected(object sender, SelectedItemChangedEventArgs args)
        {
           var item =(KeyValuePair < APIConnection.Models.ClothingItem, ImageSource >)args.SelectedItem ;
           // if (item == null)
            //    return;

           await Navigation.PushAsync(new ClothingItemDetail(new ClothingModel(item.Key)));
        }
        
        public async Task GetImagen(APIConnection.Models.ClothingItem prenda, List<ImageSource> imagenes)
        {

            string path = prenda.ImageUrl;

            var imageSource = ImageSource.FromFile(path);

            /*
            Stream stream = File.OpenRead(path);
                long length = stream.Length;
                byte[] streamBuffer = new byte[length];
                stream.Read(streamBuffer, 0, (int)length);

                Stream str = new MemoryStream(streamBuffer);
                var imageSource = ImageSource.FromStream(() => str);*/
                imagenes.Add(imageSource);

          


        }

		//Sobreescribe para que al volver hacia atrás no cierre la aplicación Y Borra la prenda insertada
        protected override Boolean OnBackButtonPressed()
        {

            Application.Current.MainPage = new MasterMenu(3, null);
            return true;
        }
    }
}
