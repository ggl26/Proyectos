﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

        public enum CATEGORY
        {
            Abrigo, Chaqueta, Americana, Camisa, Jersey, Pantalon, Zapatos,
            Bermuda, Vaquero, Chandal,  Camiseta, Polo, Sudadera, Vestido, Falda, Blusa, Sueter
        };


