﻿using System.IO;
using System.Net;
using System.Net.Cache;
using System.Text;
using System.Web;
using System.Drawing;
using System;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Collections.Generic;
using System.Linq;

namespace PruebaAPI
{
    public class Clasificador
    {

        public static Dictionary<CATEGORY, CATEGORY[]> categoriasCompatibles = new Dictionary<CATEGORY, CATEGORY[]>
        {
            {CATEGORY.Abrigo, new CATEGORY[] {CATEGORY.Camisa, CATEGORY.Jersey, CATEGORY.Pantalon, CATEGORY.Zapatos, CATEGORY.Bermuda, CATEGORY.Vaquero, CATEGORY.Chandal, CATEGORY.Camiseta, CATEGORY.Polo, CATEGORY.Sudadera, CATEGORY.Vestido, CATEGORY.Falda, CATEGORY.Blusa, CATEGORY.Sueter} },
            {CATEGORY.Chaqueta, new CATEGORY[] {CATEGORY.Americana, CATEGORY.Camisa, CATEGORY.Jersey, CATEGORY.Pantalon, CATEGORY.Zapatos, CATEGORY.Bermuda, CATEGORY.Vaquero, CATEGORY.Chandal, CATEGORY.Camiseta, CATEGORY.Polo, CATEGORY.Sudadera, CATEGORY.Vestido, CATEGORY.Falda, CATEGORY.Blusa, CATEGORY.Sueter} },
            {CATEGORY.Americana, new CATEGORY[] {CATEGORY.Chaqueta, CATEGORY.Camisa, CATEGORY.Jersey, CATEGORY.Pantalon, CATEGORY.Zapatos, CATEGORY.Bermuda, CATEGORY.Vaquero, CATEGORY.Chandal, CATEGORY.Camiseta, CATEGORY.Polo, CATEGORY.Sudadera, CATEGORY.Vestido, CATEGORY.Falda, CATEGORY.Blusa, CATEGORY.Sueter} },
            {CATEGORY.Camisa, new CATEGORY[] {CATEGORY.Camiseta, CATEGORY.Abrigo, CATEGORY.Americana, CATEGORY.Chaqueta, CATEGORY.Jersey, CATEGORY.Pantalon, CATEGORY.Zapatos, CATEGORY.Bermuda, CATEGORY.Vaquero, CATEGORY.Chandal, CATEGORY.Sudadera, CATEGORY.Falda, CATEGORY.Sueter} },
            {CATEGORY.Jersey, new CATEGORY[] {CATEGORY.Americana, CATEGORY.Abrigo, CATEGORY.Chaqueta, CATEGORY.Camisa, CATEGORY.Pantalon, CATEGORY.Zapatos, CATEGORY.Bermuda, CATEGORY.Vaquero, CATEGORY.Chandal, CATEGORY.Camiseta, CATEGORY.Polo, CATEGORY.Falda, CATEGORY.Blusa} },
            {CATEGORY.Pantalon, new CATEGORY[] { CATEGORY.Abrigo, CATEGORY.Americana, CATEGORY.Chaqueta, CATEGORY.Camisa, CATEGORY.Jersey, CATEGORY.Zapatos, CATEGORY.Chandal, CATEGORY.Camiseta, CATEGORY.Polo, CATEGORY.Sudadera, CATEGORY.Blusa, CATEGORY.Sueter} },
            {CATEGORY.Zapatos, new CATEGORY[] {CATEGORY.Abrigo, CATEGORY.Chaqueta, CATEGORY.Americana, CATEGORY.Camisa, CATEGORY.Jersey, CATEGORY.Pantalon, CATEGORY.Bermuda, CATEGORY.Vaquero, CATEGORY.Chandal, CATEGORY.Camiseta, CATEGORY.Polo, CATEGORY.Sudadera, CATEGORY.Vestido, CATEGORY.Falda, CATEGORY.Blusa, CATEGORY.Sueter } },
            {CATEGORY.Bermuda, new CATEGORY[] {CATEGORY.Abrigo, CATEGORY.Chaqueta, CATEGORY.Americana, CATEGORY.Zapatos, CATEGORY.Camisa, CATEGORY.Jersey, CATEGORY.Chandal, CATEGORY.Camiseta, CATEGORY.Polo, CATEGORY.Sudadera, CATEGORY.Blusa, CATEGORY.Sueter } },
            {CATEGORY.Vaquero, new CATEGORY[] {CATEGORY.Abrigo, CATEGORY.Chaqueta, CATEGORY.Americana, CATEGORY.Zapatos, CATEGORY.Camisa, CATEGORY.Jersey, CATEGORY.Chandal, CATEGORY.Camiseta, CATEGORY.Polo, CATEGORY.Sudadera, CATEGORY.Blusa, CATEGORY.Sueter } },
            {CATEGORY.Chandal, new CATEGORY[] {CATEGORY.Abrigo, CATEGORY.Chaqueta, CATEGORY.Americana, CATEGORY.Camisa, CATEGORY.Jersey, CATEGORY.Pantalon, CATEGORY.Bermuda, CATEGORY.Vaquero, CATEGORY.Chandal, CATEGORY.Camiseta, CATEGORY.Polo, CATEGORY.Sudadera, CATEGORY.Vestido, CATEGORY.Falda, CATEGORY.Blusa, CATEGORY.Sueter } },
            {CATEGORY.Camiseta, new CATEGORY[] {CATEGORY.Camisa, CATEGORY.Abrigo, CATEGORY.Chaqueta, CATEGORY.Americana, CATEGORY.Zapatos, CATEGORY.Jersey, CATEGORY.Pantalon, CATEGORY.Bermuda, CATEGORY.Vaquero, CATEGORY.Chandal, CATEGORY.Sudadera, CATEGORY.Falda, CATEGORY.Sueter } },
            {CATEGORY.Polo, new CATEGORY[] {CATEGORY.Abrigo, CATEGORY.Chaqueta, CATEGORY.Americana, CATEGORY.Zapatos, CATEGORY.Jersey, CATEGORY.Pantalon, CATEGORY.Bermuda, CATEGORY.Vaquero, CATEGORY.Chandal, CATEGORY.Sudadera, CATEGORY.Falda, CATEGORY.Sueter } },
            {CATEGORY.Sudadera, new CATEGORY[] {CATEGORY.Abrigo, CATEGORY.Chaqueta, CATEGORY.Americana, CATEGORY.Zapatos, CATEGORY.Camisa, CATEGORY.Pantalon, CATEGORY.Bermuda, CATEGORY.Vaquero, CATEGORY.Chandal, CATEGORY.Camiseta, CATEGORY.Polo, CATEGORY.Vestido, CATEGORY.Falda, CATEGORY.Blusa} },
            {CATEGORY.Vestido, new CATEGORY[] {CATEGORY.Abrigo, CATEGORY.Chaqueta, CATEGORY.Americana, CATEGORY.Zapatos, CATEGORY.Jersey,  CATEGORY.Chandal, CATEGORY.Sudadera, CATEGORY.Sueter } },
            {CATEGORY.Falda, new CATEGORY[] {CATEGORY.Abrigo, CATEGORY.Chaqueta, CATEGORY.Americana, CATEGORY.Camisa, CATEGORY.Zapatos, CATEGORY.Jersey, CATEGORY.Chandal, CATEGORY.Camiseta, CATEGORY.Polo, CATEGORY.Sudadera, CATEGORY.Blusa, CATEGORY.Sueter } },
            {CATEGORY.Blusa, new CATEGORY[] {CATEGORY.Abrigo, CATEGORY.Chaqueta, CATEGORY.Americana, CATEGORY.Zapatos, CATEGORY.Jersey, CATEGORY.Pantalon, CATEGORY.Bermuda, CATEGORY.Vaquero, CATEGORY.Chandal, CATEGORY.Sudadera, CATEGORY.Falda, CATEGORY.Blusa, CATEGORY.Sueter } },
            {CATEGORY.Sueter, new CATEGORY[] {CATEGORY.Abrigo, CATEGORY.Chaqueta, CATEGORY.Americana, CATEGORY.Camisa, CATEGORY.Zapatos, CATEGORY.Pantalon, CATEGORY.Bermuda, CATEGORY.Vaquero, CATEGORY.Chandal, CATEGORY.Camiseta, CATEGORY.Polo, CATEGORY.Vestido, CATEGORY.Falda, CATEGORY.Blusa} }
        };

        public static Dictionary<TIEMPO, CATEGORY[]> categoriasTiempo = new Dictionary<TIEMPO, CATEGORY[]>
        {
            {TIEMPO.Frio, new CATEGORY[] {CATEGORY.Abrigo, CATEGORY.Chaqueta, CATEGORY.Americana, CATEGORY.Camisa, CATEGORY.Jersey, CATEGORY.Zapatos, CATEGORY.Pantalon, CATEGORY.Vaquero, CATEGORY.Chandal, CATEGORY.Camiseta, CATEGORY.Polo, CATEGORY.Sudadera, CATEGORY.Sueter } },
            {TIEMPO.Normal, new CATEGORY[] {CATEGORY.Chaqueta, CATEGORY.Americana, CATEGORY.Camisa, CATEGORY.Jersey, CATEGORY.Pantalon, CATEGORY.Bermuda, CATEGORY.Vaquero, CATEGORY.Chandal, CATEGORY.Camiseta, CATEGORY.Polo, CATEGORY.Sudadera, CATEGORY.Vestido, CATEGORY.Falda, CATEGORY.Blusa, CATEGORY.Sueter, CATEGORY.Zapatos } },
            {TIEMPO.Calor, new CATEGORY[] {CATEGORY.Americana, CATEGORY.Camisa, CATEGORY.Pantalon, CATEGORY.Bermuda, CATEGORY.Vaquero, CATEGORY.Chandal, CATEGORY.Camiseta, CATEGORY.Polo, CATEGORY.Vestido, CATEGORY.Falda, CATEGORY.Blusa} }
        };

        //Dictionary with key color, and combinations for this key
        private static Dictionary<COLOR, COLOR[]> combinacionComplementaria = new Dictionary<COLOR, COLOR[]>
        {
            {COLOR.Blanco, new COLOR[] { COLOR.Blanco, COLOR.Naranja, COLOR.Verde, COLOR.Amarillo, COLOR.Rojo, COLOR.Rosa, COLOR.Violeta, COLOR.Azul, COLOR.Negro, COLOR.Marron, COLOR.Gris, COLOR.Purpura } },
            {COLOR.Negro, new COLOR[] { COLOR.Blanco, COLOR.Naranja, COLOR.Verde, COLOR.Amarillo, COLOR.Rojo, COLOR.Rosa, COLOR.Violeta, COLOR.Azul, COLOR.Negro, COLOR.Marron, COLOR.Gris, COLOR.Purpura } },
            {COLOR.Verde, new COLOR[] {COLOR.Rojo,COLOR.Purpura,COLOR.Negro, COLOR.Blanco, COLOR.Gris } },
            {COLOR.Naranja, new COLOR[] {COLOR.Azul, COLOR.Negro, COLOR.Blanco, COLOR.Gris } },
            {COLOR.Amarillo, new COLOR[] {COLOR.Violeta, COLOR.Negro, COLOR.Blanco, COLOR.Gris } },
            {COLOR.Rojo, new COLOR[] {COLOR.Verde, COLOR.Negro, COLOR.Blanco, COLOR.Gris } },
            {COLOR.Rosa, new COLOR[] {COLOR.Azul, COLOR.Negro, COLOR.Blanco, COLOR.Gris } },
            {COLOR.Violeta, new COLOR[] {COLOR.Amarillo, COLOR.Negro, COLOR.Blanco, COLOR.Gris } },
            {COLOR.Azul, new COLOR[] {COLOR.Naranja, COLOR.Marron, COLOR.Negro, COLOR.Blanco, COLOR.Gris } },
            {COLOR.Marron, new COLOR[] {COLOR.Azul, COLOR.Negro, COLOR.Blanco, COLOR.Gris } },
            {COLOR.Gris, new COLOR[] { COLOR.Blanco, COLOR.Naranja, COLOR.Verde, COLOR.Amarillo, COLOR.Rojo, COLOR.Rosa, COLOR.Violeta, COLOR.Azul, COLOR.Negro, COLOR.Marron, COLOR.Gris, COLOR.Purpura } },
            {COLOR.Purpura, new COLOR[] {COLOR.Verde, COLOR.Negro, COLOR.Blanco, COLOR.Gris } }
        };

        private static Dictionary<COLOR, COLOR[]> combinacionTriada = new Dictionary<COLOR, COLOR[]>
        {
            {COLOR.Blanco, new COLOR[] { COLOR.Blanco, COLOR.Naranja, COLOR.Verde, COLOR.Amarillo, COLOR.Rojo, COLOR.Rosa, COLOR.Violeta, COLOR.Azul, COLOR.Negro, COLOR.Marron, COLOR.Gris, COLOR.Purpura } },
            {COLOR.Negro, new COLOR[] { COLOR.Blanco, COLOR.Naranja, COLOR.Verde, COLOR.Amarillo, COLOR.Rojo, COLOR.Rosa, COLOR.Violeta, COLOR.Azul, COLOR.Negro, COLOR.Marron, COLOR.Gris, COLOR.Purpura } },
            {COLOR.Verde, new COLOR[] {COLOR.Naranja,COLOR.Violeta, COLOR.Marron, COLOR.Negro, COLOR.Blanco, COLOR.Gris } },
            {COLOR.Naranja, new COLOR[] {COLOR.Violeta,COLOR.Verde, COLOR.Negro, COLOR.Blanco, COLOR.Gris } },
            {COLOR.Amarillo, new COLOR[] {COLOR.Rojo, COLOR.Azul, COLOR.Purpura, COLOR.Rosa, COLOR.Negro, COLOR.Blanco, COLOR.Gris } },
            {COLOR.Rojo, new COLOR[] {COLOR.Amarillo, COLOR.Azul, COLOR.Negro, COLOR.Blanco, COLOR.Gris } },
            {COLOR.Rosa, new COLOR[] { COLOR.Amarillo, COLOR.Azul, COLOR.Negro, COLOR.Blanco, COLOR.Gris } },
            {COLOR.Violeta, new COLOR[] {COLOR.Verde, COLOR.Naranja, COLOR.Marron, COLOR.Negro, COLOR.Blanco, COLOR.Gris } },
            {COLOR.Azul, new COLOR[] {COLOR.Amarillo, COLOR.Rojo, COLOR.Purpura, COLOR.Rosa, COLOR.Negro, COLOR.Blanco, COLOR.Gris } },
            {COLOR.Marron, new COLOR[] {COLOR.Verde, COLOR.Violeta, COLOR.Negro, COLOR.Blanco, COLOR.Gris } },
            {COLOR.Gris, new COLOR[] { COLOR.Blanco, COLOR.Naranja, COLOR.Verde, COLOR.Amarillo, COLOR.Rojo, COLOR.Rosa, COLOR.Violeta, COLOR.Azul, COLOR.Negro, COLOR.Marron, COLOR.Gris, COLOR.Purpura } },
            {COLOR.Purpura, new COLOR[] {COLOR.Azul, COLOR.Amarillo, COLOR.Negro, COLOR.Blanco, COLOR.Gris } }

        };

        private static Dictionary<COLOR, COLOR[]> combinacionTetrada = new Dictionary<COLOR, COLOR[]>
        {
            {COLOR.Blanco, new COLOR[] { COLOR.Blanco, COLOR.Naranja, COLOR.Verde, COLOR.Amarillo, COLOR.Rojo, COLOR.Rosa, COLOR.Violeta, COLOR.Azul, COLOR.Negro, COLOR.Marron, COLOR.Gris, COLOR.Purpura } },
            {COLOR.Negro,new COLOR[] { COLOR.Blanco, COLOR.Naranja, COLOR.Verde, COLOR.Amarillo, COLOR.Rojo, COLOR.Rosa, COLOR.Violeta, COLOR.Azul, COLOR.Negro, COLOR.Marron, COLOR.Gris, COLOR.Purpura } },
            {COLOR.Verde, new COLOR[] {COLOR.Amarillo,COLOR.Rojo, COLOR.Marron,COLOR.Azul, COLOR.Negro, COLOR.Blanco, COLOR.Gris } },
            {COLOR.Naranja, new COLOR[] {COLOR.Purpura,COLOR.Azul,COLOR.Verde,COLOR.Rosa, COLOR.Negro, COLOR.Blanco, COLOR.Gris } },
            {COLOR.Amarillo, new COLOR[] {COLOR.Rojo, COLOR.Violeta, COLOR.Azul, COLOR.Negro, COLOR.Blanco, COLOR.Gris } },
            {COLOR.Rojo, new COLOR[] {COLOR.Verde, COLOR.Azul, COLOR.Amarillo, COLOR.Negro, COLOR.Blanco, COLOR.Gris } },
            {COLOR.Rosa, new COLOR[] { COLOR.Azul, COLOR.Verde, COLOR.Naranja, COLOR.Marron, COLOR.Negro, COLOR.Blanco, COLOR.Gris } },
            {COLOR.Violeta, new COLOR[] {COLOR.Azul, COLOR.Amarillo, COLOR.Rojo, COLOR.Negro, COLOR.Blanco, COLOR.Gris } },
            {COLOR.Azul, new COLOR[] {COLOR.Purpura, COLOR.Naranja, COLOR.Marron, COLOR.Verde, COLOR.Rosa, COLOR.Negro, COLOR.Blanco, COLOR.Gris } },
            {COLOR.Marron, new COLOR[] { COLOR.Purpura, COLOR.Azul, COLOR.Verde, COLOR.Rosa, COLOR.Negro, COLOR.Blanco, COLOR.Gris } },
            {COLOR.Gris, new COLOR[] { COLOR.Blanco, COLOR.Naranja, COLOR.Verde, COLOR.Amarillo, COLOR.Rojo, COLOR.Rosa, COLOR.Violeta, COLOR.Azul, COLOR.Negro, COLOR.Marron, COLOR.Gris, COLOR.Purpura }  },
            {COLOR.Purpura, new COLOR[] {COLOR.Azul, COLOR.Verde, COLOR.Naranja, COLOR.Marron, COLOR.Negro, COLOR.Blanco, COLOR.Gris } }
        };

        private static COLOR[] coloresDisponibles = new COLOR[] { COLOR.Blanco, COLOR.Naranja, COLOR.Verde, COLOR.Amarillo, COLOR.Rojo, COLOR.Rosa, COLOR.Violeta, COLOR.Azul, COLOR.Negro, COLOR.Marron, COLOR.Gris, COLOR.Purpura };

        private static string[] categoriasDisponibles = {"outerwear", "jacket", "blazer", "shirt", "knitwear", "trousers", "shoes",
            "shorts", "jeans", "jogging", "t-shirt", "polo", "sweatshirt", "dress", "skirt", "blouse", "sweater" };

        private static string[] coloresToken = { "black", "white", "orange", "green", "yellow", "red","pink", "violet","blue", "brown", "gray", "purple"  };

        private static async Task<string> getApi(string token)
        {
            var client = new HttpClient();
            //Authorization
            client.DefaultRequestHeaders.Add("Authorization", "CloudSight XshBGCQs_3sx-90FhlLxbg");
            //Http request
            var result =  client.GetAsync("https://api.cloudsight.ai/v1/images/" + token).Result;
            //Http response
            var respuesta = await result.Content.ReadAsStringAsync();
            return respuesta;
        }
        private static async Task<string> comunicacionApi(string urlFile)
        {
            var client = new HttpClient();
            var content = new MultipartFormDataContent();
            //Authorization
            client.DefaultRequestHeaders.Add("Authorization", "CloudSight XshBGCQs_3sx-90FhlLxbg");
            //Fill content
            FileStream file = File.OpenRead(urlFile);
            content.Add(new StreamContent(file), "image", Path.GetFileName(urlFile));
            //content.Add(new StreamContent(file), "image", "pruebacamiseta.jpg");

            content.Add(new StringContent("en_US"), "locale");
            //Http request
            var result = client.PostAsync("https://api.cloudsight.ai/v1/images",content).Result;

            //Http response
            var respuesta = await result.Content.ReadAsStringAsync();
            
            file.Close();
            return respuesta;
        }
        
        private static Dictionary<CATEGORY,COLOR[]> obtainColors(string descripcion)
        {
            string[] tokens = descripcion.Split(',', ' ');
            List<string> colores = new List<string>();
            //Transform enum
            Dictionary<CATEGORY,COLOR[]> colorEnum = new Dictionary<CATEGORY, COLOR[]>();
            List<COLOR> colorRopa = new List<COLOR>();
            //Obtain string colors form descripcion
            foreach (string token in tokens)
            {
                if (token == "shirt" && colorEnum.ContainsKey(CATEGORY.Polo))
                    continue;
                if (Array.IndexOf(coloresToken, token) >= 0)
                    colorRopa.Add((COLOR)Array.IndexOf(coloresToken, token));
                if(Array.IndexOf(categoriasDisponibles, token) >= 0)
                {
                    colorEnum[(CATEGORY)Array.IndexOf(categoriasDisponibles, token)] = colorRopa.ToArray();
                    colorRopa.Clear();
                }
                if(token == "pants")
                {
                    colorEnum[CATEGORY.Pantalon] = colorRopa.ToArray();
                    colorRopa.Clear();
                }
            }
            if(colorEnum.Count == 0)
                throw new LibraryException("ERROR: No detecto ninguna prenda");
            foreach(var prenda in colorEnum)
            {
                if (prenda.Value.Length == 0)
                    throw new LibraryException("ERROR: No detecto ningún color");
            }
            return colorEnum;
        }

        private static bool combinateColors(List<COLOR> colores)
        {
            int cantidadColores = colores.Count;
            //Un unico color siempre combina
            if (cantidadColores == 1)
                return true;
            //Combinación de 2 colores
            else if (cantidadColores == 2)
            {
                foreach (COLOR color in combinacionComplementaria[colores[0]])
                {
                    if (colores[1] == color)
                        return true;
                }
                return false;
            }
            //Combinación de 3 colores
            else if (cantidadColores == 3)
            {
                bool segundaPrenda = false;
                bool terceraPrenda = false;
                foreach (COLOR color in combinacionTriada[colores[0]])
                {
                    if (colores[1] == color)
                        segundaPrenda = true;
                    if (colores[2] == color)
                        terceraPrenda = true;
                }
                return segundaPrenda && terceraPrenda;
            }
            //Combinación de 4 colores
            else
            {
                bool segundaPrenda = false;
                bool terceraPrenda = false;
                bool cuartaPrenda = false;
                foreach (COLOR color in combinacionTetrada[colores[0]])
                {
                    if (colores[1] == color)
                        segundaPrenda = true;
                    if (colores[2] == color)
                        terceraPrenda = true;
                    if (colores[3] == color)
                        cuartaPrenda = true;
                }
                return segundaPrenda && terceraPrenda && cuartaPrenda;
            }

        }
        private static string processJson(string respuesta, string value)
        {
            JObject json = JObject.Parse(respuesta);
            var prueba = json.GetValue(value);
            return prueba.ToString();
        }

        private static string processJsonArray(string respuesta)
        {
            JObject json = JObject.Parse(respuesta);
            var prueba = json.GetValue("main").FirstOrDefault().First();
            return prueba.ToString();

        }
        private static Dictionary<CATEGORY,COLOR[]> peticionAPI(string urlFile)
        {
            string respString = "not completed";
            string token = "";
            int i = 0;
            while (respString.Contains("not completed"))
            {
                if (i == 0)
                {
                    respString = comunicacionApi(urlFile).Result;
                    token = processJson(respString,"token");
                }
                else
                    respString = getApi(token).Result;
                if (respString.Contains("error"))
                    throw new LibraryException("ERROR: Comunicación con Cloud Sight");
                ++i;
            }
            string descriptionImage = processJson(respString,"name");
            Dictionary<CATEGORY,COLOR[]> colors = obtainColors(descriptionImage);
            return colors;
        }

        public static List<COLOR> coloresCombinan(string urlFile, int numPrendas=1)
        {
            Dictionary<CATEGORY,COLOR[]> prendas = peticionAPI(urlFile);
            List <COLOR> respuesta = new List<COLOR>();
            foreach (var prenda in prendas)
            {
                COLOR[] colores = prenda.Value;
                foreach (var color in colores)
                {
                    respuesta.AddRange(combinacionComplementaria[color]);
                }
            }
            respuesta = respuesta.Distinct().ToList();
            return respuesta;
        }
        private async static Task<double> peticionTemperatura(double latitud, double longitud)
        {
            var client = new HttpClient();
            //Http request
            var result = await client.GetAsync("http://api.openweathermap.org/data/2.5/weather?lat=" + latitud + "&lon=" + longitud + "&appid=97ed48dfd04396208723ed8bb1904b28&units=metric");
            //Http response
            string respuesta = await result.Content.ReadAsStringAsync();
            string temperatura = processJsonArray(respuesta);
            double temp = Convert.ToDouble(temperatura.Replace('.', ','));
            return temp;
        }
        public static TIEMPO temperaturaActual(double latitud, double longitud)
        {
            double temperatura = peticionTemperatura(latitud, longitud).Result;
            if (temperatura <= 10)
                return TIEMPO.Frio;
            else if (temperatura >= 22)
                return TIEMPO.Calor;
            else
                return TIEMPO.Normal;
        }
        public static List<COLOR> coloresCombinan(List<COLOR> colores, int numPrendas=1)
        {
            List<COLOR> respuesta = new List<COLOR>();
            foreach (COLOR color in colores)
            {
                COLOR[] combinan = combinacionComplementaria[color];
                respuesta.AddRange(combinan);
            }
            respuesta = respuesta.Distinct().ToList();
            return respuesta;
        }

        public static bool combina(string urlFile)
        {
            List<COLOR> respuesta = new List<COLOR>();
            Dictionary<CATEGORY,COLOR[]> prendas = peticionAPI(urlFile);
            foreach (var prenda in prendas)
            {
                respuesta.AddRange(prenda.Value);
            }
            return combinateColors(respuesta);
        }

        public static KeyValuePair<CATEGORY, COLOR[]> clasifica(string urlFile)
        {
            Dictionary<CATEGORY,COLOR[]> prendas = peticionAPI(urlFile);
            if (prendas.Count > 1)
                throw new LibraryException("ERROR: Se ha detectado más de una prenda en la imagen");
            return prendas.First();
        }

    }
}

