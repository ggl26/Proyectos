﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

        public enum COLOR { Negro, Blanco, Naranja, Verde, Amarillo, Rojo,
                            Rosa, Violeta, Azul, Marron, Gris, Purpura 
                            };
