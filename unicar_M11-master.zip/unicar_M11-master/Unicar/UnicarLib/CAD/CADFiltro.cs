﻿using System;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;

namespace CAD
{
    public class CADFiltro : CADBase
    {
        public CADFiltro() : base()
        {
            /*Abrir la base de datos*/
            con = new SqlConnection(conString);
        }

        public void create(EN.Filtro en)
        {
            try
            {
                if (en.Equals(read(en)))
                    throw new Exception("Ya existe este filtro.");
                else
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        // CREATE
                        cmd.Connection = con;
                        cmd.Connection.Open();

                        cmd.CommandText = @"INSERT INTO Filtros VALUES ('@id', @nombre, @desc, @icono)";

                        cmd.Parameters.AddWithValue("@id", en.id);
                        cmd.Parameters.AddWithValue("@nombre", en.nombre);
                        cmd.Parameters.AddWithValue("@desc", en.desc);
                        cmd.Parameters.AddWithValue("@icono", en.icono);
                        cmd.ExecuteNonQuery();
                    }
                }

            }
            catch (SqlException ex)
            {
                Console.WriteLine("Filtro create failed.");
                Console.WriteLine("Error: {0}", ex.ToString());
            }
            catch (Exception ex)
            {
                Console.WriteLine("Filtro create failed.");
                Console.WriteLine("Error: {0}", ex.ToString());
            }
        }


        public void anyadeFiltroAViaje(EN.Filtro en,int id)
        {
            try
            {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        // CREATE
                        cmd.Connection = con;
                        cmd.Connection.Open();

                        cmd.CommandText = @"INSERT INTO Filtros_Viaje VALUES (@id_filtro,@id_viaje)";

                        cmd.Parameters.AddWithValue("@id_filtro", en.id);
                        cmd.Parameters.AddWithValue("@id_viaje", id);
                        cmd.ExecuteNonQuery();
                    }
                }

            
            catch (Exception ex)
            {
                Console.WriteLine("Filtro create failed.");
                Console.WriteLine("Error: {0}", ex.ToString());
            }
        }



        public EN.Filtro read(EN.Filtro en)
        {

            EN.Filtro cl = null;
            try
            {

                string stm = "SELECT * FROM Filtros WHERE id = '" + en.id + "'";

                using (SqlCommand cmd = new SqlCommand(stm))
                {
                    cmd.Connection = con;
                    cmd.Connection.Open();

                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        //READING
                        while (dr.Read())
                        {
                            cl = new EN.Filtro(int.Parse(dr["id"].ToString()), dr["nombre"].ToString(), dr["desc"].ToString(), dr["icono"].ToString());
                        }
                    }

                    cmd.ExecuteNonQuery();
                }

            }
            catch (SqlException ex)
            {
                Console.WriteLine("Filtro read failed.");
                Console.WriteLine("Error: {0}", ex.ToString());
            }
            return cl;
        }

        public void update(EN.Filtro en)
        {

            /*  try
              {

                  using (SqlCommand cmd = new SqlCommand())
                  {
                      // UPDATE
                      cmd.Connection = con;
                      cmd.Connection.Open();

                      cmd.CommandText = @"UPDATE Coche SET values correo = '@user', password='@password', nombre='@nombre', apellidos='@apellidos', 
                  edad='@edad', localidad='@localidad', sexo='@sexo', carrera='@carrera' where correo=@correo";

                      cmd.Parameters.AddWithValue("@user", en.correo);
                      cmd.Parameters.AddWithValue("@correo", en.correo);
                      cmd.Parameters.AddWithValue("@password", en.password);
                      cmd.Parameters.AddWithValue("@nombre", en.nombre);
                      cmd.Parameters.AddWithValue("@apellidos", en.apellidos);
                      cmd.Parameters.AddWithValue("@edad", en.edad.ToString());
                      cmd.Parameters.AddWithValue("@localidad", en.localidad);
                      cmd.Parameters.AddWithValue("@sexo", en.sexo.ToString());
                      cmd.Parameters.AddWithValue("@carrera", en.carrera);

                      cmd.ExecuteNonQuery();
                  }

              }
              catch (SqlException ex)
              {
                  Console.WriteLine("Usuario update failed.");
                  Console.WriteLine("Error: {0}", ex.ToString());

              }
              */

        }

        public void delete(EN.Filtro en)
        {
            try
            {

                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = con;
                    cmd.Connection.Open();

                    // CREATE
                    cmd.CommandText = @"DELETE FROM Filtros WHERE id = '@id' ";

                    cmd.Parameters.AddWithValue("@id", en.id);
                    cmd.ExecuteNonQuery();

                }

            }
            catch (SqlException ex)
            {
                Console.WriteLine("Coche delete failed.");
                Console.WriteLine("Error: {0}", ex.ToString());

            }

        }


    }
}