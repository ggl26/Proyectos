﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace CAD
{
    class CADConductor:CADBase
    {
        public CADConductor()
        {
            /*Abrir la base de datos*/
            con = new SqlConnection(conString);
        }
        public void save(EN.Conductor conductor, EN.Coche coche, string correo_usuario)
        {

            try
            {


                using (SqlCommand cmd = new SqlCommand())
                {
                    // CREATE
                    cmd.Connection = con;
                    cmd.Connection.Open();

                    cmd.CommandText = @"INSERT INTO conductor VALUES (@correo, @carnet,Convert(datetime,@fechacad,103),@coche_matric)";

                    cmd.Parameters.AddWithValue("@correo", correo_usuario);
                    cmd.Parameters.AddWithValue("@carnet", conductor.carnet);
                    cmd.Parameters.AddWithValue("@fechacad", conductor.fechaCaducidad.ToString()+" 23:59:59");
                    cmd.Parameters.AddWithValue("@coche_matric", coche.matricula);

                    cmd.ExecuteNonQuery();
                }


            }
            catch (Exception ex)
            {
                Console.WriteLine("Usuario create failed.");
                Console.WriteLine("Error: {0}", ex.ToString());
            }

        }
        public EN.Conductor read(EN.Conductor cond)
        {
            return null;
        }
        public EN.Conductor read(EN.Usuario user)
        {
            EN.Conductor cond = null;
            try
            {

                string stm = "SELECT * FROM Conductor WHERE correo = '" + user.correo + "'";

                using (SqlCommand cmd = new SqlCommand(stm))
                {
                    cmd.Connection = con;
                    cmd.Connection.Open();

                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        //READING
                        while (dr.Read())
                        {
                            EN.Coche coche = new EN.Coche(dr["coche"].ToString());
                            coche = (EN.Coche) coche.read(); //necesitamos método read en coche que reciba matricula
                            cond = new EN.Conductor(user , dr["carnet"].ToString(), DateTime.Parse(dr["f_caducidad"].ToString()).Day.ToString()+"/"+ DateTime.Parse(dr["f_caducidad"].ToString()).Month.ToString()+"/"+ DateTime.Parse(dr["f_caducidad"].ToString()).Year.ToString(), coche);
                        }
                    }

                    cmd.ExecuteNonQuery();
                }

            }
            catch (SqlException ex)
            {
                Console.WriteLine("Usuario read failed.");
                Console.WriteLine("Error: {0}", ex.ToString());
            }
            return cond;
        }
        public void update(EN.Conductor conductor)
        {
            try
            {

                using (SqlCommand cmd = new SqlCommand())
                {
                    // UPDATE
                    cmd.Connection = con;
                    cmd.Connection.Open();

                    cmd.CommandText = @"UPDATE conductor SET  correo= @correo, f_caducidad=Convert(datetime,@caducidad,103), coche= @coche where carnet=@carnet";

                    cmd.Parameters.AddWithValue("@correo", conductor.user.correo);
                    cmd.Parameters.AddWithValue("@caducidad", conductor.fechaCaducidad.ToString() + " 23:59:59");
                    cmd.Parameters.AddWithValue("@coche", conductor.car.matricula);
                    cmd.Parameters.AddWithValue("@carnet", conductor.carnet);

                    cmd.ExecuteNonQuery();
                }

            }
            catch (SqlException ex)
            {
                Console.WriteLine("Conductor update failed.");
                Console.WriteLine("Error: {0}", ex.ToString());

            }
        }
        public void delete(EN.Conductor conductor)
        {

        }
        public DataTable listaMedallas(string correo)
        {
            DataTable dt = new DataTable();
            string consulta = "SELECT Medallas_Cond.nombre, Medallas_Cond.[desc], Medallas_Cond.icono FROM Medallas_Cond INNER JOIN Cond_Med ON Medallas_Cond.Id = Cond_Med.idMedalla WHERE Cond_Med.correo = '" + correo + "'";
            SqlDataAdapter da = new SqlDataAdapter(consulta, conString);
            da.Fill(dt);
            return dt;
        }
        public int viajesRealizados(string correo)
        {
            int viajes = 0;
            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.Connection = con;
                cmd.Connection.Open();

                // cantidad de viajes
                cmd.CommandText = "select count(*) viajes from Viaje where conductor = @correo and fecha < convert(date,GETDATE())";
                cmd.Parameters.AddWithValue("@correo", correo);
                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    dr.Read();
                    viajes = Convert.ToInt32(dr["viajes"]);
                }
            }
            return viajes;
        }
    }
}
