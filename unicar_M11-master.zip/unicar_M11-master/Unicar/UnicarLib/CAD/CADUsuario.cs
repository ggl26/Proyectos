﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;

namespace CAD
{
    class CADUsuario : CADBase
    {

        public CADUsuario() : base()
        {
            /*Abrir la base de datos*/
            //con = new SqlConnection(conString);
        }

        public void create(EN.Usuario en)
        {

            try
            {


                using (SqlCommand cmd = new SqlCommand())
                {
                    // CREATE
                    cmd.Connection = con;
                    cmd.Connection.Open();

                    cmd.CommandText = @"INSERT INTO usuario VALUES (@user, @password, @nombre, @apellidos, @edad, @localidad, @sexo, @carrera)";

                    cmd.Parameters.AddWithValue("@user", en.correo);
                    cmd.Parameters.AddWithValue("@password", en.password);
                    cmd.Parameters.AddWithValue("@nombre", en.nombre);
                    cmd.Parameters.AddWithValue("@apellidos", en.apellidos);
                    cmd.Parameters.AddWithValue("@edad", en.edad.ToString());
                    cmd.Parameters.AddWithValue("@localidad", en.localidad);
                    cmd.Parameters.AddWithValue("@sexo", en.sexo.ToString());
                    cmd.Parameters.AddWithValue("@carrera", en.carrera);

                    cmd.ExecuteNonQuery();
                }


            }
            catch (Exception ex)
            {
                Console.WriteLine("Usuario create failed.");
                Console.WriteLine("Error: {0}", ex.ToString());
            }


        }
        public EN.Usuario read(string correo)
        {
            EN.Usuario user = new EN.Usuario(correo, "", "", "", 0, "");
            return read(user);
        }
        public EN.Usuario read(EN.Usuario en)
        {
            EN.Usuario cl = null;
            try
            {

                string stm = "SELECT * FROM usuario WHERE correo = '" + en.correo + "'";

                using (SqlCommand cmd = new SqlCommand(stm))
                {
                    cmd.Connection = con;
                    cmd.Connection.Open();

                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        //READING
                        while (dr.Read())
                        {
                            cl = new EN.Usuario(dr["correo"].ToString(), dr["contraseña"].ToString(), dr["nombre"].ToString(), dr["apellidos"].ToString(), int.Parse(dr["edad"].ToString()), dr["localidad"].ToString());
                            cl.sexo = (dr["sexo"]).ToString();
                            cl.carrera = dr["carrera"].ToString();
                        }
                    }

                    cmd.ExecuteNonQuery();
                }

            }
            catch (SqlException ex)
            {
                Console.WriteLine("Usuario read failed.");
                Console.WriteLine("Error: {0}", ex.ToString());
            }
            return cl;
        }

        public void update(EN.Usuario en)
        {
            try
            {

                using (SqlCommand cmd = new SqlCommand())
                {
                    // UPDATE
                    cmd.Connection = con;
                    cmd.Connection.Open();

                    cmd.CommandText = @"UPDATE usuario SET  contraseña= @password, nombre= @nombre, apellidos= @apellidos, 
                edad=@edad, localidad=@localidad, sexo=@sexo, carrera=@carrera where correo=@correo";

                    cmd.Parameters.AddWithValue("@correo", en.correo);
                    cmd.Parameters.AddWithValue("@password", en.password);
                    cmd.Parameters.AddWithValue("@nombre", en.nombre);
                    cmd.Parameters.AddWithValue("@apellidos", en.apellidos);
                    cmd.Parameters.AddWithValue("@edad", en.edad.ToString());
                    cmd.Parameters.AddWithValue("@localidad", en.localidad);
                    cmd.Parameters.AddWithValue("@sexo", en.sexo.ToString());
                    cmd.Parameters.AddWithValue("@carrera", en.carrera);

                    cmd.ExecuteNonQuery();
                }

            }
            catch (SqlException ex)
            {
                Console.WriteLine("Usuario update failed.");
                Console.WriteLine("Error: {0}", ex.ToString());

            }

        }

        public void delete(EN.Usuario en)
        {
            try
            {

                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = con;
                    cmd.Connection.Open();

                    // CREATE
                    cmd.CommandText = @"DELETE FROM usuario WHERE correo = '@user1' ";

                    cmd.Parameters.AddWithValue("@user1", en.correo);
                    cmd.ExecuteNonQuery();

                }

            }
            catch (SqlException ex)
            {
                Console.WriteLine("Usuario delete failed.");
                Console.WriteLine("Error: {0}", ex.ToString());

            }
        }
        public DataTable reservas(EN.Usuario en)
        {
            string consulta = "select v.* from viaje v, usuario u, reserva r where v.id = r.idviaje and r.correo ='" + en.correo + "'";
            // Crea un DataAdapter que será el encargado de ejecutar la consulta
            // y Posteriormente ingresar los datos a un DataSet
            SqlDataAdapter daAutores = new SqlDataAdapter(consulta, conString);
            // Crea el DataSet
            DataTable dsAutores = new DataTable();
            // Llena el DataSet con la información de la base de datos
            daAutores.Fill(dsAutores);
            // Pone el DataTable Authors como fuente de datos para el DropDownList

            return dsAutores;

        }
        public DataTable listaMedallas(string correo)
        {
            DataTable dt = new DataTable();
            string consulta = "SELECT Medallas_Usu.nombre, Medallas_Usu.[desc], Medallas_Usu.icono FROM Medallas_Usu INNER JOIN Usu_Med ON Medallas_Usu.Id = Usu_Med.idMedalla WHERE Usu_Med.correo = '" + correo + "'";
            SqlDataAdapter da = new SqlDataAdapter(consulta, conString);
            da.Fill(dt);
            return dt;
        }
        public int viajesRealizados(string correo)
        {
            int viajes = 0;
            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.Connection = con;
                cmd.Connection.Open();

                // cantidad de viajes
                cmd.CommandText = "select count(*) viajes from Reserva, Viaje where  id=idViaje and correo = @correo and fecha < convert(date,GETDATE())";
                cmd.Parameters.AddWithValue("@correo", correo);
                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    dr.Read();
                    viajes = Convert.ToInt32(dr["viajes"]);
                }    
            }
            return viajes;
        }
    }
}
