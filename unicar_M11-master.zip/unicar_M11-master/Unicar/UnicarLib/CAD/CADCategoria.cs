﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EN;

namespace CAD
{
    class CADCategoria:CADBase
    {
      public CADCategoria():base()
        {

        }
        public void create(EN.Categoria cat)
        {

        }
        public void update(EN.Categoria cat)
        {

        }
        public void delete(EN.Categoria cat)
        {

        }

        public Base read(Categoria categoria)
        {
            return categoria;
        }
    }
}
