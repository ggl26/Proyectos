﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EN;
using System.Data.SqlClient;
namespace CAD
{
    class CADCoche:CADBase
    {
        public CADCoche():base()
        {
            /*Abrir la base de datos*/
            con = new SqlConnection(conString);
        }

        public void create(EN.Coche en)
        {
            try
            {
             
                
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        // CREATE
                        cmd.Connection = con;
                        cmd.Connection.Open();

                        cmd.CommandText = @"INSERT INTO Coche VALUES (@matricula, @modelo, @max_plazas, @foto)";

                        cmd.Parameters.AddWithValue("@matricula", en.matricula);
                        cmd.Parameters.AddWithValue("@modelo", en.modelo);
                        cmd.Parameters.AddWithValue("@max_plazas", en.nMaxPasajeros);
                        cmd.Parameters.AddWithValue("@foto", en.foto);


                        cmd.ExecuteNonQuery();
                    }
                

            }
            catch (Exception ex)
            {
                Console.WriteLine("Coche create failed.");
                Console.WriteLine("Error: {0}", ex.ToString());
            }
          
        }

        public EN.Coche read(EN.Coche en)
        {
            EN.Coche cl = null;
            try
            {

                string stm = "SELECT * FROM Coche WHERE matricula = '" + en.matricula +"'";

                using (SqlCommand cmd = new SqlCommand(stm))
                {
                    cmd.Connection = con;
                    cmd.Connection.Open();

                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        //READING
                        while (dr.Read())
                        {
                            cl = new EN.Coche(dr["matricula"].ToString(), dr["modelo"].ToString(), dr["foto"].ToString(), int.Parse(dr["max_pasajeros"].ToString()));
                        }
                    }

                    cmd.ExecuteNonQuery();
                }

            }
            catch (SqlException ex)
            {
                Console.WriteLine("Coche read failed.");
                Console.WriteLine("Error: {0}", ex.ToString());
            }
            return cl;
        }

        public void update(EN.Coche en)
        {
            try
            {

                using (SqlCommand cmd = new SqlCommand())
                {
                    // UPDATE
                    cmd.Connection = con;
                    cmd.Connection.Open();

                    cmd.CommandText = @"UPDATE Coche SET modelo = @modelo , max_pasajeros=@pasajeros , foto=@foto where matricula=@matricula";

                    cmd.Parameters.AddWithValue("@modelo", en.modelo);
                    cmd.Parameters.AddWithValue("@pasajeros", en.nMaxPasajeros);
                    cmd.Parameters.AddWithValue("@foto", en.foto);
                    cmd.Parameters.AddWithValue("@matricula", en.matricula);

                    cmd.ExecuteNonQuery();
                }

            }
            catch (SqlException ex)
            {
                Console.WriteLine("Usuario update failed.");
                Console.WriteLine("Error: {0}", ex.ToString());

            }
            
        }



        public void delete(EN.Coche en)
        {
            try
            {

                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = con;
                    cmd.Connection.Open();

                    // CREATE
                    cmd.CommandText = @"DELETE FROM Coche WHERE matricula = @matricula ";

                    cmd.Parameters.AddWithValue("@matricula", en.matricula);
                    cmd.ExecuteNonQuery();

                }

            }
            catch (SqlException ex)
            {
                Console.WriteLine("Coche delete failed.");
                Console.WriteLine("Error: {0}", ex.ToString());

            }
        }
    }
}