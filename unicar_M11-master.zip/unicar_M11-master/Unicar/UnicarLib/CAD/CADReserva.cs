﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;

namespace CAD
{
    class CADReserva : CADBase
    {

        public CADReserva() : base()
        {
            /*Abrir la base de datos*/
            con = new SqlConnection(conString);
        }

        public bool consulta(EN.Reserva en)
        {
            bool reservado = false;
            try
            {

                string stm = "SELECT COUNT(*) CONTADOR FROM reserva WHERE correo = '" + en.user.correo + "' and idviaje =" + en.travel.idViaje.ToString();

                using (SqlCommand cmd = new SqlCommand(stm))
                {
                    cmd.Connection = con;
                    cmd.Connection.Open();

                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        //READING
                        while (dr.Read())
                        {
                            if (dr["contador"].ToString() != "0")
                                reservado = true;

                        }
                    }

                    cmd.ExecuteNonQuery();
                }

            }
            catch (SqlException ex)
            {
                Console.WriteLine("reservado read failed.");
                Console.WriteLine("Error: {0}", ex.ToString());
            }

            return reservado;
        }

        public void create(EN.Reserva en)
        {


            try
            {


                using (SqlCommand cmd = new SqlCommand())
                {
                    // CREATE
                    cmd.Connection = con;
                    cmd.Connection.Open();

                    cmd.CommandText = @"INSERT INTO reserva VALUES (@user, @viaje)";

                    cmd.Parameters.AddWithValue("@user", en.user.correo);
                    cmd.Parameters.AddWithValue("@viaje", en.travel.idViaje.ToString());

                    cmd.ExecuteNonQuery();
                }


            }
            catch (SqlException ex)
            {
                Console.WriteLine("Reserva create failed.");
                Console.WriteLine("Error: {0}", ex.ToString());
            }


        }
        public EN.Reserva read(EN.Reserva en)
        {
            EN.Reserva cl = null;
            try
            {

                string stm = "SELECT * FROM reserva WHERE correo = '" + en.user.correo + "'and idViaje =" + en.travel.idViaje.ToString();

                using (SqlCommand cmd = new SqlCommand(stm))
                {
                    cmd.Connection = con;
                    cmd.Connection.Open();

                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        //READING
                        while (dr.Read())
                        {
                            EN.Usuario cll = new EN.Usuario(dr["correo"].ToString());

                            cll = (EN.Usuario)cll.read();

                            EN.Viaje v = new EN.Viaje(int.Parse(dr["idViaje"].ToString()));

                            v = (EN.Viaje)v.read();

                            cl = new EN.Reserva(cll, v);

                        }
                    }

                    cmd.ExecuteNonQuery();
                }

            }
            catch (SqlException ex)
            {
                Console.WriteLine("Reserva read failed.");
                Console.WriteLine("Error: {0}", ex.ToString());
            }
            return cl;
        }

      
        public void update(EN.Reserva en)
        {
            try
            {

                using (SqlCommand cmd = new SqlCommand())
                {
                    // UPDATE
                    cmd.Connection = con;
                    cmd.Connection.Open();

                    cmd.CommandText = @"UPDATE reserva SET values correo = '@user', idviaje='@viaje'where correo=@correo and idViaje=@viaje";

                    cmd.Parameters.AddWithValue("@user", en.user.correo);
                    cmd.Parameters.AddWithValue("@correo", en.user.correo);
                    cmd.Parameters.AddWithValue("@viaje", en.travel.idViaje.ToString());

                    cmd.ExecuteNonQuery();
                }

            }
            catch (SqlException ex)
            {
                Console.WriteLine("Reserva update failed.");
                Console.WriteLine("Error: {0}", ex.ToString());

            }

        }



        public void delete(EN.Reserva en)
        {
            try
            {

                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = con;
                    cmd.Connection.Open();

                    // CREATE
                    cmd.CommandText = @"DELETE FROM reserva WHERE correo = @correo and idviaje=@viaje";

                    cmd.Parameters.AddWithValue("@correo", en.user.correo);
                    cmd.Parameters.AddWithValue("@viaje", en.travel.idViaje.ToString());
                    cmd.ExecuteNonQuery();

                }

            }
            catch (SqlException ex)
            {
                Console.WriteLine("Reserva delete failed.");
                Console.WriteLine("Error: {0}", ex.ToString());

            }
        }

       
    }
}
