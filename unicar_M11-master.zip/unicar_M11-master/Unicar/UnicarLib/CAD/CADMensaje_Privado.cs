﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;

namespace CAD
{
    public class CADMensaje_Privado: CADBase
    {
        public CADMensaje_Privado() : base()
        {
            /*Abrir la base de datos*/
            con = new SqlConnection(conString);
        }


        public void create(EN.Mensaje_Privado en)
        {

            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    //ARREGLAR ESTO
                    // CREATE
                    cmd.Connection = con;
                    cmd.Connection.Open();

                    cmd.CommandText = @"INSERT INTO Mensajes_Privados VALUES (@emisor, @receptor,@cuerpo,@fecha)";
                    
                    cmd.Parameters.AddWithValue("@cuerpo", en.cuerpo);
                    cmd.Parameters.AddWithValue("@emisor", en.emisor.correo);
                    cmd.Parameters.AddWithValue("@receptor", en.receptor.correo);
                    cmd.Parameters.AddWithValue("@fecha",en.fecha);
                    cmd.ExecuteNonQuery();
                }
            }
                
            catch (SqlException ex)
            {
                Console.WriteLine("Mensaje_Privado create failed.");
                Console.WriteLine("Error: {0}", ex.ToString());
            }
        }

        public EN.Mensaje_Privado read(EN.Mensaje_Privado en)
        {
            EN.Mensaje_Privado mensaje = null;
            EN.Usuario emisor = null;
            EN.Usuario receptor = null;

            try
            {

                string stm = @"SELECT * FROM Mensajes_Privados WHERE emisor = '" + en.emisor.correo.ToString() + "' and receptor = '" + en.receptor.correo.ToString() + "' and cuerpo = '" + en.cuerpo.ToString() + "' and fecha = '" + en.fecha.ToString() + "'";

                using (SqlCommand cmd = new SqlCommand(stm))
                {
                    cmd.Connection = con;
                    cmd.Connection.Open();

                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        //READING
                        while (dr.Read())
                        {
                            emisor = new EN.Usuario(dr["emisor"].ToString());
                            receptor = new EN.Usuario(dr["receptor"].ToString());

                            mensaje = new EN.Mensaje_Privado(dr["cuerpo"].ToString(), (EN.Usuario)emisor.read(), (EN.Usuario)receptor.read(),DateTime.Parse(dr["fecha"].ToString()));
                        }
                    }

                    cmd.ExecuteNonQuery();
                }

            }
            catch (SqlException ex)
            {
                Console.WriteLine("Mensaje_Privado read failed.");
                Console.WriteLine("Error: {0}", ex.ToString());
            }

            return mensaje;
        }

        public List<EN.Mensaje_Privado> all(EN.Usuario en,EN.Usuario en2)
        {
            EN.Usuario emisor = null;
            EN.Usuario receptor = null;

            List<EN.Mensaje_Privado> msgs = new List<EN.Mensaje_Privado>();

            try
            {
                
                string stm = @"SELECT * FROM Mensajes_Privados WHERE (emisor = '" + en.correo.ToString() + "' and receptor = '" + en2.correo.ToString() + "') or (emisor='"+en2.correo.ToString()+"' and receptor='"+en.correo.ToString()+"')";

                using (SqlCommand cmd = new SqlCommand(stm))
                {
                    cmd.Connection = con;
                    cmd.Connection.Open();

                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        //READING
                        while (dr.Read())
                        {

                            emisor = (EN.Usuario)(new EN.Usuario(dr["emisor"].ToString()).read());
                            receptor = (EN.Usuario)(new EN.Usuario(dr["receptor"].ToString()).read());

                            msgs.Add(new EN.Mensaje_Privado(dr["cuerpo"].ToString(), emisor, receptor, DateTime.Parse(dr["fecha"].ToString())));
                        }
                    }

                    cmd.ExecuteNonQuery();
                }

            }
            catch (SqlException ex)
            {
                Console.WriteLine("Mensaje_Privado read failed.");
                Console.WriteLine("Error: {0}", ex.ToString());
            }

            return msgs;
        }


        public void update(EN.Mensaje_Privado en)
        {
            /*
            try
            {

                using (SqlCommand cmd = new SqlCommand())
                {
                    // UPDATE
                    cmd.Connection = con;
                    cmd.Connection.Open();

                    cmd.CommandText = @"UPDATE Mensaje_Privado SET cuerpo=@cuerpo, emisor=@emisor, receptor=@receptor WHERE id='" + en.idMensaje +"'";

                    cmd.Parameters.AddWithValue("@cuerpo", en.cuerpo);
                    cmd.Parameters.AddWithValue("@emisor", en.emisor.correo);
                    cmd.Parameters.AddWithValue("@receptor", en.receptor.correo);
                    cmd.ExecuteNonQuery();
                }

            }
            catch (SqlException ex)
            {
                Console.WriteLine("Mensaje_Privado update failed.");
                Console.WriteLine("Error: {0}", ex.ToString());

            }
        */
            throw new Exception("¡UN MENSAJE NO SE PUEDE EDITAR!");

        }

        public void delete(EN.Mensaje_Privado en)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = con;
                    cmd.Connection.Open();

                    // DELETE
                    cmd.CommandText = @"DELETE FROM Mensajes_Privados WHERE emisor = '" + en.emisor.correo.ToString() + "' and receptor = '" + en.receptor.correo.ToString() + "' and cuerpo = '" + en.cuerpo.ToString() + "' and fecha = '" + en.fecha.ToString() + "'";
                    cmd.ExecuteNonQuery();
                }

            }
            catch (SqlException ex)
            {
                Console.WriteLine("Mensaje_Privado delete failed.");
                Console.WriteLine("Error: {0}", ex.ToString());

            }
        }




    }
}
