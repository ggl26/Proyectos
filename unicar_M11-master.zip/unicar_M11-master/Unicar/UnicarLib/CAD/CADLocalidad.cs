﻿using System;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;

namespace CAD
{
    public class CADLocalidad : CADBase
    {
        public CADLocalidad() : base()
        {
            /*Abrir la base de datos*/
            con = new SqlConnection(conString);
        }

        public void create(EN.Localidad en)
        {
            try
            {


                using (SqlCommand cmd = new SqlCommand())
                {
                    // CREATE
                    cmd.Connection = con;
                    cmd.Connection.Open();

                    cmd.CommandText = @"INSERT INTO Localidad_Precio VALUES ('@Localidad', @precio)";

                    cmd.Parameters.AddWithValue("@Localidad", en.nombre);
                    cmd.Parameters.AddWithValue("@precio", en.precio.ToString());

                    cmd.ExecuteNonQuery();
                }


            }
            catch (SqlException ex)
            {
                Console.WriteLine("Loacalidad create failed.");
                Console.WriteLine("Error: {0}", ex.ToString());
            }

        }

        public EN.Localidad read(EN.Localidad en)
        {

            EN.Localidad cl = null;
            try
            {

                string stm = "SELECT * FROM Localidad_Precio WHERE Localidad = '" + en.nombre + "'";

                using (SqlCommand cmd = new SqlCommand(stm))
                {
                    cmd.Connection = con;
                    cmd.Connection.Open();

                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        //READING
                        while (dr.Read())
                        {
                            cl = new EN.Localidad(dr["Localidad"].ToString(), (float)Convert.ToDouble(dr["Precio"].ToString()));
                        }
                    }

                    cmd.ExecuteNonQuery();
                }

            }
            catch (SqlException ex)
            {
                Console.WriteLine("Coche read failed.");
                Console.WriteLine("Error: {0}", ex.ToString());
            }
            return cl;
        }
        public EN.Localidad read(string en)
        {

            EN.Localidad cl = null;
            try
            {

                string stm = "SELECT * FROM Localidad WHERE localidad = '" + en + "'";

                using (SqlCommand cmd = new SqlCommand(stm))
                {
                    cmd.Connection = con;
                    cmd.Connection.Open();

                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        //READING
                        while (dr.Read())
                        {
                            cl = new EN.Localidad(dr["Localidad"].ToString(), (float)Convert.ToDouble(dr["Precio"].ToString()));
                        }
                    }

                    cmd.ExecuteNonQuery();
                }

            }
            catch (SqlException ex)
            {
                Console.WriteLine("Coche read failed.");
                Console.WriteLine("Error: {0}", ex.ToString());
            }
            return cl;
        }

        public void update(EN.Localidad en)
        {

            /*  try
              {

                  using (SqlCommand cmd = new SqlCommand())
                  {
                      // UPDATE
                      cmd.Connection = con;
                      cmd.Connection.Open();

                      cmd.CommandText = @"UPDATE Coche SET values correo = '@user', password='@password', nombre='@nombre', apellidos='@apellidos', 
                  edad='@edad', localidad='@localidad', sexo='@sexo', carrera='@carrera' where correo=@correo";

                      cmd.Parameters.AddWithValue("@user", en.correo);
                      cmd.Parameters.AddWithValue("@correo", en.correo);
                      cmd.Parameters.AddWithValue("@password", en.password);
                      cmd.Parameters.AddWithValue("@nombre", en.nombre);
                      cmd.Parameters.AddWithValue("@apellidos", en.apellidos);
                      cmd.Parameters.AddWithValue("@edad", en.edad.ToString());
                      cmd.Parameters.AddWithValue("@localidad", en.localidad);
                      cmd.Parameters.AddWithValue("@sexo", en.sexo.ToString());
                      cmd.Parameters.AddWithValue("@carrera", en.carrera);

                      cmd.ExecuteNonQuery();
                  }

              }
              catch (SqlException ex)
              {
                  Console.WriteLine("Usuario update failed.");
                  Console.WriteLine("Error: {0}", ex.ToString());

              }
              */

        }

        public void delete(EN.Localidad en)
        {
            try
            {

                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = con;
                    cmd.Connection.Open();

                    // CREATE
                    cmd.CommandText = @"DELETE FROM Localidad_Precio WHERE Localidad = '@Localidad' ";

                    cmd.Parameters.AddWithValue("@Localidad", en.nombre);
                    cmd.ExecuteNonQuery();

                }

            }
            catch (SqlException ex)
            {
                Console.WriteLine("Coche delete failed.");
                Console.WriteLine("Error: {0}", ex.ToString());

            }

        }
        public DataSet tabla()
        {
            string consulta = "SELECT * FROM Localidad_Precio Where Localidad='Universidad Alicante' Union SELECT * FROM Localidad_Precio where Localidad not in ('Universidad Alicante')";
            // Crea un DataAdapter que será el encargado de ejecutar la consulta
            // y Posteriormente ingresar los datos a un DataSet
            SqlDataAdapter daAutores = new SqlDataAdapter(consulta, conString);
            // Crea el DataSet
            DataSet dsAutores = new DataSet();
            // Llena el DataSet con la información de la base de datos
            daAutores.Fill(dsAutores, "Localidad");
            // Pone el DataTable Authors como fuente de datos para el DropDownList

            return dsAutores;

        }
    }
}

