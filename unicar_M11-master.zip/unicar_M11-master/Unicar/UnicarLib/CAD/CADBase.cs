﻿using System;
using System.Configuration;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using System.IO;

namespace CAD
{
    public abstract class CADBase
    {
        //public string conString = "data source = .\\SQLEXPRESS; Integrated Security = SSPI; AttachDBFilename = |DataDirectory|\\DataBase.mdf; User Instance = true";
        public string conString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\\UnicarDataBase.mdf;Integrated Security=True";
        public SqlConnection con;

        public CADBase()
        {
            /*Abrir la base de datos*/
            con = new SqlConnection(conString);
        }
    }
}

