﻿using System;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;

namespace CAD
{
    public class CADValoracion : CADBase
    {

        public CADValoracion() : base()
        {
            con = new SqlConnection(conString);
        }
        public void create(EN.Valoracion en)
        {

            try
            {


                using (SqlCommand cmd = new SqlCommand())
                {
                    // CREATE
                    cmd.Connection = con;
                    cmd.Connection.Open();

                    cmd.CommandText = @"INSERT INTO valoracion VALUES (@user1, @user2,@travel,@stars,@comment)";

                    cmd.Parameters.AddWithValue("@user1", en.user1.correo);
                    cmd.Parameters.AddWithValue("@user2", en.user2.correo);
                    cmd.Parameters.AddWithValue("@travel", en.viaje.idViaje);
                    cmd.Parameters.AddWithValue("@stars", en.stars);
                    cmd.Parameters.AddWithValue("@comment", en.comment);

                    cmd.ExecuteNonQuery();
                }

            }
            catch (SqlException ex)
            {
                Console.WriteLine("Valoracion create failed.");
                Console.WriteLine("Error: {0}", ex.ToString());
            }

        }

        public EN.Valoracion read(EN.Valoracion en)
        {
            EN.Valoracion cl = null;
            try
            {

                string stm = "SELECT * FROM valoracion WHERE us_valora = '" + en.user1.correo + "' and us_valorado = '" + en.user2.correo + "' and viaje=" + en.viaje.idViaje.ToString();

                using (SqlCommand cmd = new SqlCommand(stm))
                {
                    cmd.Connection = con;
                    cmd.Connection.Open();

                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        //READING
                        while (dr.Read())
                        {
                            EN.Usuario aux1 = new EN.Usuario(dr["us_valora"].ToString());
                            aux1 = (EN.Usuario)aux1.read();
                            EN.Usuario aux2 = new EN.Usuario(dr["us_valorado"].ToString());
                            aux2 = (EN.Usuario)aux2.read();
                            EN.Viaje travel = new EN.Viaje(int.Parse(dr["viaje"].ToString()));
                            travel = (EN.Viaje)travel.read();
                            int stars = int.Parse(dr["estrellas"].ToString());
                            string comentario = dr["comentario"].ToString();
                            if (aux1 == null || aux2 == null || travel == null)
                                throw new Exception("SQL FAIL");
                            cl = new EN.Valoracion(aux1, aux2, travel, stars, comentario);
                        }
                    }

                    cmd.ExecuteNonQuery();
                }

            }
            catch (SqlException ex)
            {
                Console.WriteLine("Valoracion read failed.");
                Console.WriteLine("Error: {0}", ex.ToString());
            }
            return cl;
        }

        public void update(EN.Valoracion en)
        {
            try
            {

                using (SqlCommand cmd = new SqlCommand())
                {
                    // UPDATE
                    cmd.Connection = con;
                    cmd.Connection.Open();

                    cmd.CommandText = @"UPDATE valoracion SET values (us_valora,us_valorado,viaje,estrellas,comentario) = ('@user1','@user2',@travel,@stars,'@comment') WHERE user1='@user1' && user2='@user2' && travel=@travel";

                    cmd.Parameters.AddWithValue("@user1", en.user1.correo);
                    cmd.Parameters.AddWithValue("@user2", en.user2.correo);
                    cmd.Parameters.AddWithValue("@travel", en.viaje.idViaje.ToString());
                    cmd.Parameters.AddWithValue("@stars", en.stars.ToString());
                    cmd.Parameters.AddWithValue("@comment", en.comment);
                    cmd.ExecuteNonQuery();
                }

            }
            catch (SqlException ex)
            {
                Console.WriteLine("Valoracion update failed.");
                Console.WriteLine("Error: {0}", ex.ToString());

            }

        }

        public void delete(EN.Valoracion en)
        {
            try
            {

                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = con;
                    cmd.Connection.Open();

                    // CREATE
                    cmd.CommandText = @"DELETE FROM valoracion WHERE us_valora = '@user1' and us_valorado = '@user2' and viaje = @travel";

                    cmd.Parameters.AddWithValue("@user1", en.user1.correo);
                    cmd.Parameters.AddWithValue("@user2", en.user2.correo);
                    cmd.Parameters.AddWithValue("@travel", en.viaje.idViaje.ToString());
                    cmd.Parameters.AddWithValue("@stars", en.stars.ToString());
                    cmd.Parameters.AddWithValue("@comment", en.comment);

                    cmd.ExecuteNonQuery();

                }

            }
            catch (SqlException ex)
            {
                Console.WriteLine("Valoracion update failed.");
                Console.WriteLine("Error: {0}", ex.ToString());

            }
        }

        public int valmedia(EN.Usuario en)
        {
            int i = 0;
            try
            {

                string stm = "SELECT round(avg(estrellas),0) ess, count(*) contador FROM valoracion WHERE us_valorado = '" + en.correo + "'";

                using (SqlCommand cmd = new SqlCommand(stm))
                {
                    cmd.Connection = con;
                    cmd.Connection.Open();

                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        //READING
                        while (dr.Read())
                        {
                            if (dr["contador"].ToString() != "0")
                                i = Int32.Parse(dr["ess"].ToString());
                        }
                    }

                    cmd.ExecuteNonQuery();
                }

            }
            catch (SqlException ex)
            {
                Console.WriteLine("Valoracion read failed.");
                Console.WriteLine("Error: {0}", ex.ToString());
            }
            return i;
        }
        public DataTable ListaValoraciones(string correo)
        {
            DataTable dt = new DataTable();
            string consulta = "SELECT [us_valora], [comentario], [estrellas] FROM [Valoracion] WHERE [us_valorado] = '" + correo + "'";
            SqlDataAdapter da = new SqlDataAdapter(consulta, conString);
            da.Fill(dt);
            return dt;
        }

    }
}

