﻿using System;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;

namespace CAD
{
    public class CADViaje : CADBase
    {
        public CADViaje() : base()
        {
            /*Abrir la base de datos*/
            con = new SqlConnection(conString);
        }

        public void create(EN.Viaje en)
        {
            try
            {
              
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        // CREATE
                        cmd.Connection = con;
                        cmd.Connection.Open();

                        cmd.CommandText = @"INSERT INTO Viaje VALUES (@conductor, @origen, @destino, @plazas, @precio,Convert(datetime,@fecha,103), @foto)";

                        cmd.Parameters.AddWithValue("@conductor", en.conductor.user.correo);
                        cmd.Parameters.AddWithValue("@origen", en.origen);
                        cmd.Parameters.AddWithValue("@destino", en.destino);
                        cmd.Parameters.AddWithValue("@plazas", en.plazas);
                        cmd.Parameters.AddWithValue("@precio", en.precio);
                        cmd.Parameters.AddWithValue("@fecha", en.fecha.ToString());
                        cmd.Parameters.AddWithValue("@foto", en.coche.foto);

                    cmd.ExecuteNonQuery();
                    }
                }

            catch (Exception ex)
            {
                Console.WriteLine("Localidad create failed.");
                Console.WriteLine("Error: {0}", ex.ToString());
            }
        }



        public EN.Viaje read(EN.Viaje en)
        {

            EN.Viaje cl = null;
            try
            {

                string stm = "SELECT * FROM Viaje WHERE id = '" + en.idViaje + "'";

                using (SqlCommand cmd = new SqlCommand(stm))
                {
                    cmd.Connection = con;
                    cmd.Connection.Open();

                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        //READING
                        while (dr.Read())
                        {
                            CAD.CADUsuario user = new CAD.CADUsuario();
                            EN.Usuario usuario = user.read(dr["conductor"].ToString());
                            CAD.CADConductor cadcon = new CAD.CADConductor();
                            EN.Conductor cond = cadcon.read(usuario);

                            cl = new EN.Viaje(Int32.Parse(dr["id"].ToString()), cond, dr["origen"].ToString(), dr["destino"].ToString(), Int32.Parse(dr["plazas"].ToString()));
                            cl.fecha = dr["fecha"].ToString();
                            cl.precio = (float)Convert.ToDouble(dr["precio"].ToString());
                            cl.coche = cond.car;

                        }
                    }

                    cmd.ExecuteNonQuery();
                }

            }
            catch (SqlException ex)
            {
                Console.WriteLine("Viaje read failed.");
                Console.WriteLine("Error: {0}", ex.ToString());
            }
            return cl;
        }

        public EN.Viaje read(int en)
        {
            EN.Viaje cl = null;
            try
            {

                string stm = "SELECT * FROM Viaje WHERE id = '" + en.ToString() + "'";

                using (SqlCommand cmd = new SqlCommand(stm))
                {
                    cmd.Connection = con;
                    cmd.Connection.Open();

                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        //READING
                        while (dr.Read())
                        {
                            CAD.CADUsuario user = new CAD.CADUsuario();
                            EN.Usuario usuario = user.read(dr["conductor"].ToString());
                            CAD.CADConductor cadcon = new CAD.CADConductor();
                            EN.Conductor cond = cadcon.read(usuario);

                            cl = new EN.Viaje(Int32.Parse(dr["id"].ToString()), cond, dr["origen"].ToString(), dr["destino"].ToString(), Int32.Parse(dr["plazas"].ToString()));
                            cl.fecha = dr["fecha"].ToString();
                            cl.precio = (float)Convert.ToDouble(dr["precio"].ToString());
                            cl.coche = cond.car;

                        }
                    }

                    cmd.ExecuteNonQuery();
                }

            }
            catch (SqlException ex)
            {
                Console.WriteLine("Viaje read failed.");
                Console.WriteLine("Error: {0}", ex.ToString());
            }
            return cl;
        }

        public void update(EN.Viaje en)
        {

            /*  try
              {

                  using (SqlCommand cmd = new SqlCommand())
                  {
                      // UPDATE
                      cmd.Connection = con;
                      cmd.Connection.Open();

                      cmd.CommandText = @"UPDATE Coche SET values correo = '@user', password='@password', nombre='@nombre', apellidos='@apellidos', 
                  edad='@edad', localidad='@localidad', sexo='@sexo', carrera='@carrera' where correo=@correo";

                      cmd.Parameters.AddWithValue("@user", en.correo);
                      cmd.Parameters.AddWithValue("@correo", en.correo);
                      cmd.Parameters.AddWithValue("@password", en.password);
                      cmd.Parameters.AddWithValue("@nombre", en.nombre);
                      cmd.Parameters.AddWithValue("@apellidos", en.apellidos);
                      cmd.Parameters.AddWithValue("@edad", en.edad.ToString());
                      cmd.Parameters.AddWithValue("@localidad", en.localidad);
                      cmd.Parameters.AddWithValue("@sexo", en.sexo.ToString());
                      cmd.Parameters.AddWithValue("@carrera", en.carrera);

                      cmd.ExecuteNonQuery();
                  }

              }
              catch (SqlException ex)
              {
                  Console.WriteLine("Usuario update failed.");
                  Console.WriteLine("Error: {0}", ex.ToString());

              }
              */

        }

        public void delete(EN.Viaje en)
        {
            try
            {

                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = con;
                    cmd.Connection.Open();

                    // CREATE


                    cmd.CommandText = @"DELETE FROM Reserva WHERE idViaje = @idViaje_reserva ";
                    cmd.Parameters.AddWithValue("@idViaje_reserva", en.idViaje);
                    cmd.ExecuteNonQuery();

                    cmd.CommandText = @"DELETE FROM Filtros_Viaje WHERE id_viaje = @idViaje_filtro ";
                    cmd.Parameters.AddWithValue("@idViaje_filtro", en.idViaje);
                    cmd.ExecuteNonQuery();

                    cmd.CommandText = @"DELETE FROM Viaje WHERE id = @idViaje ";
                    
                    cmd.Parameters.AddWithValue("@idViaje", en.idViaje);
                    cmd.ExecuteNonQuery();

                }

            }
            catch (SqlException ex)
            {
                Console.WriteLine("Viaje delete failed.");
                Console.WriteLine("Error: {0}", ex.ToString());

            }

        }
        public DataTable tablasugerencias(EN.Viaje en)
        {
            string consulta = "select TOP 4 * from Viaje where Id not in ('" + en.idViaje + "') and fecha>=convert(datetime,'"+ en.fecha + "',103) and (origen='" + en.origen + "' and destino='" + en.destino + "') or (destino='" + en.origen + "' and origen='" + en.destino + "') order by NEWID()";

            //select v.*, f.id, f.icono
            //from filtros f
            //join filtros_viaje on id_filtro = f.id
            //join viaje v on v.id = id_viaje
            // Crea un DataAdapter que será el encargado de ejecutar la consulta
            // y Posteriormente ingresar los datos a un DataSet
            SqlDataAdapter daAutores = new SqlDataAdapter(consulta, conString);
            // Crea el DataSet
            DataTable dsAutores = new DataTable();
            // Llena el DataSet con la información de la base de datos
            daAutores.Fill(dsAutores);
            // Pone el DataTable Authors como fuente de datos para el DropDownList

            return dsAutores;

        }

        public DataTable filtros(EN.Viaje en)
        {
            string consulta = "select f.* from filtros_viaje, filtros f where id_filtro=f.id and id_viaje='" + en.idViaje.ToString() + "' order by id_filtro";
            // Crea un DataAdapter que será el encargado de ejecutar la consulta
            // y Posteriormente ingresar los datos a un DataSet
            SqlDataAdapter daAutores = new SqlDataAdapter(consulta, conString);
            // Crea el DataSet
            DataTable dsAutores = new DataTable();
            // Llena el DataSet con la información de la base de datos
            daAutores.Fill(dsAutores);
            // Pone el DataTable Authors como fuente de datos para el DropDownList

            return dsAutores;

        }
        public int ocupa(EN.Viaje en)
        {
            int total = 0;
            try
            {

                string stm = "SELECT count(*) total FROM reserva WHERE idViaje ='" + en.idViaje + "'";

                using (SqlCommand cmd = new SqlCommand(stm))
                {
                    cmd.Connection = con;
                    cmd.Connection.Open();

                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        //READING
                        while (dr.Read())
                        {
                            total = Int32.Parse(dr["total"].ToString());

                        }
                    }

                    cmd.ExecuteNonQuery();
                }

            }
            catch (SqlException ex)
            {
                Console.WriteLine("Reserva read failed.");
                Console.WriteLine("Error: {0}", ex.ToString());
            }
            return total;

        }
        public DataTable listadoViajes()
        {
            DataTable dt = new DataTable();
            string consulta = "SELECT [Id], [conductor], [origen], [destino], [precio], [fecha], [foto]  FROM [Viaje], [Conductor], [Coche] WHERE(conductor = correo AND coche = matricula)";
            SqlDataAdapter da = new SqlDataAdapter(consulta, conString);
            da.Fill(dt);
            return dt;
        }

        public int nuevoID()
        {
            int total = 0;

            try
            {

                string stm = "SELECT max(id) total FROM viaje";

                using (SqlCommand cmd = new SqlCommand(stm))
                {
                    cmd.Connection = con;
                    cmd.Connection.Open();

                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        //READING
                        while (dr.Read())
                        {
                            total = Int32.Parse(dr["total"].ToString());

                        }
                    }

                    cmd.ExecuteNonQuery();
                }

            }
            catch (SqlException ex)
            {
                Console.WriteLine("MaxID read failed.");
                Console.WriteLine("Error: {0}", ex.ToString());
            }
            return (total + 1);
        }
    }
}
