﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;

namespace CAD
{
    public class CADMensaje_Chat:CADBase
    {
        public CADMensaje_Chat() : base()
        {
            /*Abrir la base de datos*/
            con = new SqlConnection(conString);
        }

        public void create(EN.Mensaje_Chat en)
        {

            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    // CREATE
                    cmd.Connection = con;
                    cmd.Connection.Open();

                    cmd.CommandText = @"INSERT INTO mensajechat VALUES (@id, @cuerpo, @emisor)";

                    cmd.Parameters.AddWithValue("@id", en.idMensaje);
                    cmd.Parameters.AddWithValue("@cuerpo", en.cuerpo);
                    cmd.Parameters.AddWithValue("@emisor", en.emisor.correo);
                    cmd.ExecuteNonQuery();
                }
            }

            catch (SqlException ex)
            {
                Console.WriteLine("Mensaje_Chat create failed.");
                Console.WriteLine("Error: {0}", ex.ToString());
            }
        }


        public EN.Mensaje_Chat read(EN.Mensaje_Chat en)
        {
            EN.Mensaje_Chat mensaje = null;
            EN.Usuario emisor = null;

            try
            {
                string stm = @"SELECT * FROM mensajechat WHERE id = '" + en.idMensaje + "'";

                using (SqlCommand cmd = new SqlCommand(stm))
                {
                    cmd.Connection = con;
                    cmd.Connection.Open();

                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        //READING
                        while (dr.Read())
                        {
                            emisor = new EN.Usuario(dr["emisor"].ToString());
                            mensaje = new EN.Mensaje_Chat(int.Parse(dr["id"].ToString()), dr["cuerpo"].ToString(), (EN.Usuario)emisor.read());
                        }
                    }
                    cmd.ExecuteNonQuery();
                }

            }
            catch (SqlException ex)
            {
                Console.WriteLine("Mensaje_Chat read failed.");
                Console.WriteLine("Error: {0}", ex.ToString());
            }

            return mensaje;
        }



        public void update(EN.Mensaje_Chat en)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    // UPDATE
                    cmd.Connection = con;
                    cmd.Connection.Open();

                    cmd.CommandText = @"UPDATE mensajechat SET cuerpo=@cuerpo, emisor=@emisor WHERE id='" + en.idMensaje + "'";

                    cmd.Parameters.AddWithValue("@cuerpo", en.cuerpo);
                    cmd.Parameters.AddWithValue("@emisor", en.emisor.correo);
                    cmd.ExecuteNonQuery();
                }

            }
            catch (SqlException ex)
            {
                Console.WriteLine("Mensaje_Chat update failed.");
                Console.WriteLine("Error: {0}", ex.ToString());
            }
        }

        public void delete(EN.Mensaje_Chat en)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = con;
                    cmd.Connection.Open();

                    // DELETE
                    cmd.CommandText = @"DELETE FROM mensajechat WHERE id='" + en.idMensaje + "'";
                    cmd.ExecuteNonQuery();
                }

            }
            catch (SqlException ex)
            {
                Console.WriteLine("Mensaje_Chat delete failed.");
                Console.WriteLine("Error: {0}", ex.ToString());

            }
        }
  
    }
}
