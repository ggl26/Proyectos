﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Data;

namespace EN
{
    public class Localidad : Base
    {
        public Localidad(string name, float precio)
        {
            this.nombre = name;
            this.precio = precio;

        }


        public Localidad(string name)
        {
            this.nombre = name;
        }

        public string nombre { get; }
        public float precio { get; }
        
        /* private Conductor[2] conductores; // no sé si no sería mejor dejarlo en un conductor y au o como mucho conductor y suplente para evitar rollos. conductores[0] es el principal
         public Conductor getConductor()
         {
             return this.conductores[0];
         }*/
        public void create()
        {
            CAD.CADLocalidad aux = new CAD.CADLocalidad();
            aux.create(this);
        }
        public void save()
        {
            CAD.CADLocalidad aux = new CAD.CADLocalidad();
            // aux.save(this);
        }
        public Base read()
        {
            CAD.CADLocalidad aux = new CAD.CADLocalidad();
            return aux.read(this);
        }
        public void update()
        {
            CAD.CADLocalidad aux = new CAD.CADLocalidad();
            aux.update(this);
        }
        public void delete()
        {
            CAD.CADLocalidad aux = new CAD.CADLocalidad();
            aux.delete(this);
        }
        public DataSet data()
        {
            CAD.CADLocalidad aux = new CAD.CADLocalidad();
            return aux.tabla();
        }
    }
}