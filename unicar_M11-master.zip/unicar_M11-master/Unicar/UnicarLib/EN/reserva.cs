using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EN
{
    public class Reserva : Base
    {
        public Reserva(EN.Usuario usuario, EN.Viaje viaje)
        {
            user = usuario;
            travel = viaje;
        }

        public Reserva(EN.Viaje viaje)
        {
            travel = viaje;
        }

        public EN.Usuario user { get; set; }
        public EN.Viaje travel { get; set; }

        public bool consulta()
        {
            CAD.CADReserva aux = new CAD.CADReserva();
            return aux.consulta(this);
        }

        public void create()
        {
            CAD.CADReserva aux = new CAD.CADReserva();
            aux.create(this);
        }


        public Base read()
        {
            CAD.CADReserva aux = new CAD.CADReserva();
            return aux.read(this);
        }

        public void update()
        {
            CAD.CADReserva aux = new CAD.CADReserva();
            aux.update(this);
        }

        public void delete()
        {
            CAD.CADReserva aux = new CAD.CADReserva();
            aux.delete(this);
        }

    }
}
