﻿using System;
using System.Data;

namespace EN
{
    public class Valoracion:Base
	{
        public string textError { get; set; }
		public Valoracion (Usuario user1, Usuario user2, Viaje viaje, int stars, string comment){
            //EXCEPCIONES
            try
            {
                if (user1== null) {
                    throw new Exception("Nombre de usuario " + user1 + " erroneo");
                } if (user2 == null) {
                    throw new Exception("Nombre de usuario valorado " + user2 + " erroneo");
                } if (viaje==null) {
                    throw new Exception("Nombre(IDENTIFICADOR) del viaje  " + viaje + " erroneo");
                } if (comment == null) {
                    throw new Exception("Comentario \"" + comment + "\" inexistente o erroneo");
                } if (stars < 1 || stars > 5) {
                    throw new Exception("Número de estellas " + stars.ToString() + " erroneo");
                } else {
                    this.user1 = user1;
                    this.user2 = user2;
                    this.viaje = viaje;
                    this.comment = comment;
                    this.stars = stars;
                }
            }
            catch (Exception ex)
            {
                textError = ex.Message;
            }
		}
        public Usuario user1 { get; set; }
        public Usuario user2 { get; set; }
        public Viaje viaje{ get; set; }
        public int stars { get; set; }
        public string comment { get; set; }
        public void create()
        {
            CAD.CADValoracion aux = new CAD.CADValoracion();
            aux.create(this);
        }
        public EN.Base read()
        {
            CAD.CADValoracion aux = new CAD.CADValoracion();
            return aux.read(this);
        }
        public void update()
        {
            CAD.CADValoracion aux = new CAD.CADValoracion();
            aux.update(this);
        }
        public void delete()
        {
            CAD.CADValoracion aux = new CAD.CADValoracion();
            aux.delete(this);
        }
        public bool Equals (Valoracion va)
        {
            if (va.user1.Equals(user1) && va.user2.Equals(user2) && va.viaje.idViaje == viaje.idViaje)
                return true;
            return false;
        }
        override public string ToString(){
            return user1.nombre + " ha valorado a " + user2.nombre + " con " + stars.ToString() + " estrellas y con el comentario: " + comment;
		}
        public static DataTable listarValoracionesUsuario(string correo)
        {
            CAD.CADValoracion aux = new CAD.CADValoracion();
            return aux.ListaValoraciones(correo);
        }
	}
}

