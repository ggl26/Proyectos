﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EN
{
    public class Usuario:Base
    {

        public Usuario(string email, string password, string nombre, string apellidos, int edad, string localidad)
        {
            this.correo = email;           
            this.password = password;         
            this.nombre = nombre;
            this.apellidos = apellidos;
            this.edad = edad;
            this.localidad = localidad;
         
        }
        public Usuario(string email)
        {
            this.correo = email;
        }

        public string correo{get;set;}
        public string password { get; set; }
        public string nombre { get; set; }
        public string apellidos { get; set; }
        public int edad { get; set; }
        public string localidad { get; set; }
        public string sexo { get; set; }
        public string carrera { get; set; }

       

        public void create()
        {

            CAD.CADUsuario aux = new CAD.CADUsuario();
            aux.create(this);
        }
        public Base read()
        {
            CAD.CADUsuario aux = new CAD.CADUsuario();
           return aux.read(this);
        }
        static public Base read(string correo)
        {
            CAD.CADUsuario aux = new CAD.CADUsuario();
            return aux.read(correo);
        }

        public void update()
        {
            CAD.CADUsuario aux = new CAD.CADUsuario();
            aux.update(this);
        }
         
        public void delete()
        {
            CAD.CADUsuario aux = new CAD.CADUsuario();
            aux.delete(this);
        }
        public bool isConductor(ref EN.Conductor conductor)
        {
            CAD.CADConductor aux = new CAD.CADConductor();
            conductor = aux.read(this);
            if (conductor != null)
                return true;
            else
                return false;
        }

        public List<Mensaje_Privado> leerMensajes(Usuario user)
        {
            CAD.CADMensaje_Privado aux = new CAD.CADMensaje_Privado();
            return aux.all(this, user);
        }

        public DataTable reservados()
        {
            CAD.CADUsuario aux = new CAD.CADUsuario();
            return aux.reservas(this);
        }

        public int valmedia()
        {
            CAD.CADValoracion val = new CAD.CADValoracion();
            return val.valmedia(this);
        }
        public static DataTable listarMedallas(string correo)
        {
            CAD.CADUsuario aux = new CAD.CADUsuario();
            return aux.listaMedallas(correo);
        }
        public int viajes(string correo)
        {
            CAD.CADUsuario aux = new CAD.CADUsuario();
            return aux.viajesRealizados(correo);
        }
    }
}
