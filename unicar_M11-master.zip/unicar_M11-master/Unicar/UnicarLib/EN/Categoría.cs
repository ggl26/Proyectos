﻿using System;
using System.Drawing;

namespace EN
{
    public class Categoria:Base
    {
        public Categoria(int id, string tipo, string desc, Bitmap icono)
        {
            this.id = id;
            this.tipo = tipo;
            this.descripcion = desc;
            this.icono = icono;
        }
        private int id;
        private string tipo;
        private string descripcion;
        public Bitmap icono;

        public void create()
        {
            CAD.CADCategoria aux = new CAD.CADCategoria();
            aux.create(this);
        }
        public void update()
        {
            CAD.CADCategoria aux = new CAD.CADCategoria();
            aux.update(this);
        }
        public Base read()
        {
            CAD.CADCategoria aux = new CAD.CADCategoria();
            return aux.read(this);
        }
        public void delete()
        {
            CAD.CADCategoria aux = new CAD.CADCategoria();
            aux.delete(this);
        }
    }
}

