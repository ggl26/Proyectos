﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EN
{
    public class Conductor:Base
    {
        public Conductor(EN.Usuario user, string carnet, string fechaCaducidad, EN.Coche car)
        {
            this.user = user;
            this.carnet = carnet;
            this.fechaCaducidad = fechaCaducidad;
            this.car = car;
        }
        public Conductor(EN.Usuario user)
        {
            this.user = user;

        }
        public EN.Usuario user { get; set; }
        public string carnet { get; set; }
        public string fechaCaducidad { get; set; }
        public object[] medallas { get; set; }
        public EN.Coche car { get; set; }
        public void create()
        {
            CAD.CADConductor aux = new CAD.CADConductor();
            aux.save(this,car,user.correo);
        }
        public void update()
        {
            CAD.CADConductor aux = new CAD.CADConductor();
            aux.update(this);
        }
        public Base read()
        {
            CAD.CADConductor aux = new CAD.CADConductor();
            return aux.read(this);
        }
        public void delete()
        {
            CAD.CADConductor aux = new CAD.CADConductor();
            aux.delete(this);
        }
        public static DataTable listarMedallas(string correo)
        {
            CAD.CADConductor aux = new CAD.CADConductor();
            return aux.listaMedallas(correo);
        }
        public int viajes(string correo)
        {
            CAD.CADConductor aux = new CAD.CADConductor();
            return aux.viajesRealizados(correo);
        }
    }
}
