﻿using System;
using System.Drawing;

namespace EN
{
    public class Coche : Base
    {

        public Coche(string matricula)
        {
            this.matricula = matricula;
        }
        public Coche(string matricula, string modelo, string foto, int nMaxPasajeros)
        {
            this.matricula = matricula;
            this.modelo = modelo;
            this.foto = foto;
            this.nMaxPasajeros = nMaxPasajeros;
        }
        public string matricula { get; set; }
        public string modelo { get; set; }
        public string foto { get; set; }
        public int nMaxPasajeros { get; set; }
        /* private Conductor[2] conductores; // no sé si no sería mejor dejarlo en un conductor y au o como mucho conductor y suplente para evitar rollos. conductores[0] es el principal
         public Conductor getConductor()
         {
             return this.conductores[0];
         }*/
        public void create()
        {
            CAD.CADCoche aux = new CAD.CADCoche();
            aux.create(this);
        }
        public void save()
        {
            CAD.CADCoche aux = new CAD.CADCoche();
            // aux.save(this);
        }
        public Base read()
        {
            CAD.CADCoche aux = new CAD.CADCoche();
            return aux.read(this);
        }
        public Base readMatricula(string matricula)
        {
            EN.Coche coche = new EN.Coche(matricula);
            CAD.CADCoche aux = new CAD.CADCoche();
            return aux.read(coche);
        }

        public void update()
        {
            CAD.CADCoche aux = new CAD.CADCoche();
            aux.update(this);
        }
        public void delete()
        {
            CAD.CADCoche aux = new CAD.CADCoche();
            aux.delete(this);
        }
    }
}

