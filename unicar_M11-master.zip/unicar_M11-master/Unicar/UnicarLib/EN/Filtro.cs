﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace EN
{
    public class Filtro : Base
    {
        public Filtro(int id, string nombre, string descripcion, string icono)
        {
            this.id = id;
            this.nombre = nombre;
            this.desc = descripcion;
            this.icono = icono;
        }
        public int id { get; set; }
        public string nombre { get; set; }
        public string desc { get; set; }
        public string icono { get; set; }

        public Filtro(int id)
        {
            this.id = id;
        }

        public void anyadeFiltroAViaje(int id)
        {
            CAD.CADFiltro aux = new CAD.CADFiltro();
            aux.anyadeFiltroAViaje(this,id);
        }
        /* private Conductor[2] conductores; // no sé si no sería mejor dejarlo en un conductor y au o como mucho conductor y suplente para evitar rollos. conductores[0] es el principal
         public Conductor getConductor()
         {
             return this.conductores[0];
         }*/
        public void create()
        {
            CAD.CADFiltro aux = new CAD.CADFiltro();
            aux.create(this);
        }
        public void save()
        {
            CAD.CADFiltro aux = new CAD.CADFiltro();
            // aux.save(this);
        }
        public Base read()
        {
            CAD.CADFiltro aux = new CAD.CADFiltro();
            return aux.read(this);
        }
        public void update()
        {
            CAD.CADFiltro aux = new CAD.CADFiltro();
            aux.update(this);
        }
        public void delete()
        {
            CAD.CADFiltro aux = new CAD.CADFiltro();
            aux.delete(this);
        }
    }
}