﻿using System;

namespace EN
{
    public class Mensaje_Chat : Base
    {
        public string textError { get; set; }
        public Mensaje_Chat(int idMensaje, string cuerpo, EN.Usuario emisor)
        {
            try
            {
                if (emisor == null)
                {
                    throw new Exception("No se ha identificado el emisor del mensaje");
                }
                if (idMensaje < 1)
                {
                    throw new Exception("Nombre(IDENTIFICADOR) del mensaje  " + idMensaje + " erroneo");
                }
                if (cuerpo == null)
                {
                    throw new Exception("Cuerpo del mensaje inexistente o erroneo");
                }
                else
                {
                    this.emisor = emisor;
                    this.idMensaje = idMensaje;
                    this.cuerpo = cuerpo;
                }
            }
            catch (Exception ex)
            {
                textError = ex.Message;
            }
        }

        public int idMensaje { get; set; }
        public string cuerpo { get; set; }
        public EN.Usuario emisor { get; set; }

        public void create()
        {
            CAD.CADMensaje_Chat aux = new CAD.CADMensaje_Chat();
            aux.create(this);
        }
        public EN.Base read()
        {
            CAD.CADMensaje_Chat aux = new CAD.CADMensaje_Chat();
            return aux.read(this);
        }
        public void update()
        {
            CAD.CADMensaje_Chat aux = new CAD.CADMensaje_Chat();
            aux.update(this);
        }
        public void delete()
        {
            CAD.CADMensaje_Chat aux = new CAD.CADMensaje_Chat();
            aux.delete(this);
        }
    }
}
