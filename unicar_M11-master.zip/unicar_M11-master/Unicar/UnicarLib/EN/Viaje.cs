﻿using System;
using System.Data;

namespace EN
{
    public class Viaje : Base
    {
        public string textError { get; set; }
        public Viaje(int idViaje, EN.Conductor conductor, string origen, string destino, int plazas)
        {
            this.idViaje = idViaje;
            this.conductor = conductor;
            this.origen = origen;
            this.destino = destino;
            this.plazas = plazas;
        }

        public Viaje(int idViaje)
        {
            this.idViaje = idViaje;
        }
        public Viaje()
        {
            CAD.CADViaje nuevo = new CAD.CADViaje();
            this.idViaje = nuevo.nuevoID();
        }

        //DATOS CONDUCTOR
        public EN.Conductor conductor { get; set; }

        public EN.Usuario usuario()
        {
            return conductor.user;
        }

        public string correo()
        {
            return usuario().correo;
        }

        //DATOS VIAJE
        public int idViaje { get; set; }
        public string origen { get; set; }
        public string destino { get; set; }
        public int plazas { get; set; }
        public string fecha { get; set; }
        public EN.Coche coche { get; set; }
        public float precio { get; set; }

        public void create()
        {
            CAD.CADViaje aux = new CAD.CADViaje();
            aux.create(this);
        }
        public EN.Base read()
        {
            CAD.CADViaje aux = new CAD.CADViaje();
            return aux.read(this);
        }

        public void update()
        {
            CAD.CADViaje aux = new CAD.CADViaje();
            aux.update(this);
        }
        public void delete()
        {
            CAD.CADViaje aux = new CAD.CADViaje();
            aux.delete(this);
        }
        public bool Equals(Viaje va)
        {
            if (va.idViaje == idViaje && va.origen == origen && va.destino == destino)
                return true;
            return false;
        }
        override public string ToString()
        {
            return idViaje.ToString() + " con origen " + origen + " y destino " + destino + ".";
        }
        public DataTable sugerencia()
        {
            CAD.CADViaje aux = new CAD.CADViaje();
            return aux.tablasugerencias(this);
        }
        public DataTable filtro()
        {
            CAD.CADViaje aux = new CAD.CADViaje();
            return aux.filtros(this);

        }

        public int ocupadas()
        {
            CAD.CADViaje aux = new CAD.CADViaje();
            return aux.ocupa(this);
        }
        public static DataTable listarViajes()
        {
            CAD.CADViaje aux = new CAD.CADViaje();
            return aux.listadoViajes();
        }
    }
}

