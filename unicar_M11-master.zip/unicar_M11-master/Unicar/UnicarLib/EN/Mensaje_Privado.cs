﻿using System;


namespace EN
{
    public class Mensaje_Privado:Base
    {
        public string textError { get; set; }
        public Mensaje_Privado(string cuerpo, EN.Usuario emisor, EN.Usuario receptor, DateTime fecha) {

            try{
                if (emisor == null) {
                    throw new Exception("No se ha identificado el emisor del mensaje");
                }
                if (receptor == null) {
                    throw new Exception("No se ha identificado elreceptor del mensaje");
                }
                if (cuerpo == null) {
                    throw new Exception("Cuerpo del mensaje inexistente o erroneo");
                }
                if (fecha == null)
                {
                    throw new Exception("Fecha del mensaje inexistente o erronea");
                }
                else{
                    this.emisor = emisor;
                    this.receptor = receptor;
                    this.cuerpo = cuerpo;
                    this.fecha = fecha;
                }
            }
            catch (Exception ex) {
                textError = ex.Message;
            }
        }
        
        public string cuerpo { get; set; }
        public EN.Usuario emisor { get; set; }
        public EN.Usuario receptor { get; set; }
        public DateTime fecha { get; set; }

        public void create()
        {
            CAD.CADMensaje_Privado aux = new CAD.CADMensaje_Privado();
            aux.create(this);
        }
        public EN.Base read()
        {
            CAD.CADMensaje_Privado aux = new CAD.CADMensaje_Privado();
            return aux.read(this);
        }
        public void update()
        {
            CAD.CADMensaje_Privado aux = new CAD.CADMensaje_Privado();
            aux.update(this);
        }
        public void delete()
        {
            CAD.CADMensaje_Privado aux = new CAD.CADMensaje_Privado();
            aux.delete(this);
        }
    }
}