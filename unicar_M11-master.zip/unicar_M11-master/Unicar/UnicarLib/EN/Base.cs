﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EN
{
    public interface Base
    {
        void create();
        Base read();
        void update();
        void delete();
    }
}
