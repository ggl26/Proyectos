﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using EN;

namespace UnicarWeb.PaginasContenido
{
    public partial class Mensajes : System.Web.UI.Page
    {
        Usuario usuario;
        Usuario contacto;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Session["username"] == null)
                    Response.Redirect("Inicio.aspx");

                usuario = (Usuario)Session["username"];
                Session["emisorChat"] = usuario.correo;

                if (Session["receptorChat"] == null) 
                    Session["receptorChat"] = "";
            }

            usuario = (Usuario)(new Usuario(Session["emisorChat"].ToString()).read());
            contacto = (Usuario)(new Usuario(Session["receptorChat"].ToString()).read());

            if (contacto != null && contacto.correo != null)
            {
                LbTituloChat.Text = "Hablando con: " + contacto.nombre + " " + contacto.apellidos;
                PanelChat.Visible = campo_mensaje.Visible = btEnviar.Visible = true;
            }
            else
            {
                LbTituloChat.Text = "No estás hablando con nadie";
                PanelChat.Visible = campo_mensaje.Visible = btEnviar.Visible = false;
            }
        }
        


        protected void btEnviar_Click(object sender, EventArgs e)
        {
            //ARREGLAR INSERTAR!
            Mensaje_Privado aux = new Mensaje_Privado(campo_mensaje.Text, usuario, contacto, DateTime.Now);
            aux.create();
            campo_mensaje.Text = "";
            /*Actualizaremos DataList1(Mensajes)*/
            DataList1.DataBind();
            /*Actualizaremos DataList2(Contactos) por si se hablase a un nuevo contacto*/
            DataList2.DataBind();
        }
        public void contactClicked(string receptor)
        {
            contacto = (Usuario)(new Usuario(receptor)).read();
            Session["receptorChat"] = receptor;

            if (contacto != null && contacto.correo != null)
            {
                LbTituloChat.Text = "Hablando con: " + contacto.nombre + " " + contacto.apellidos;
                PanelChat.Visible = campo_mensaje.Visible = btEnviar.Visible = true;
            }
            else
            {
                LbTituloChat.Text = "No estás hablando con nadie";
                PanelChat.Visible = campo_mensaje.Visible = btEnviar.Visible = false;
            }

            DataList1.DataBind();
            DataList2.DataBind();
        }
        
    }
}