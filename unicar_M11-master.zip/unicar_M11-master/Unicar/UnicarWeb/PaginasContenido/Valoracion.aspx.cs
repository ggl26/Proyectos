﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace UnicarWeb.PaginasContenido
{
    public partial class Valoracion : System.Web.UI.Page
    {
        private EN.Viaje elviaje;
        private EN.Usuario valorador;
        private EN.Usuario valorado;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Request.QueryString["id"] != "")
            {
                EN.Viaje en = new EN.Viaje(Int32.Parse(Request.QueryString["id"].ToString()));
                elviaje = (EN.Viaje)en.read();
                if (Session["username"] == null)
                {
                    //No se puede entrar a valoraciones si no eres un usuario registrado.
                    Response.Redirect("~/PaginasContenido/IniciarSesion.aspx");
                }
                else
                {
                    valorador = (EN.Usuario)Session["username"];
                    valorador.read();
                    valorado = new EN.Usuario(elviaje.conductor.user.correo);
                    valorado.read();


                    LinkButton clickedbutton = sender as LinkButton;

                }
            }

            if (!Page.IsPostBack)
            {

                //Carga el dropDownList Satisfaccion de 1 a 5
                for (int i = 1; i <= 5; i++)
                {
                    ddValoracion.Items.Add("" + i);
                }

                CargaData();

                string correo = elviaje.correo();
                int unicode = 0;
                foreach (char c in correo)
                {
                    unicode = unicode + c;
                }

                datalbconductor.PostBackUrl = "InfoUsuario.aspx?user=" + Server.UrlEncode(correo);// unicode.ToString());


            }

            btEnviar.Click += new EventHandler(btEnviar_Click); 
            
            
        }

        protected void datalbconductor_Click(object sender, EventArgs e)
        {
            LinkButton boton = sender as LinkButton;
            EN.Usuario usuario = elviaje.usuario();

            string correo = elviaje.usuario().correo;

            boton.PostBackUrl = "InfoUsuario.aspx?id=" + Server.UrlEncode(correo);
        }

        protected void btEnviar_Click(object sender, EventArgs e)
        {
            EN.Valoracion valoracionUsuario = new EN.Valoracion(valorador, valorado, elviaje, Convert.ToInt32(ddValoracion.SelectedValue), tbComentario.Text);

            valoracionUsuario.create();
            Response.Redirect("~/PaginasContenido/MiCuenta.aspx");
        }

        private void CargaData()
        {
            if (lblDestino.Text != "")
            {
                datalbl_destino.Text = elviaje.destino;
                datalbl_origen.Text = elviaje.origen;
                datalbl_plazas.Text = elviaje.plazas.ToString();
                datalbl_precio.Text = elviaje.precio.ToString();
                for (int i = 0; i < elviaje.fecha.Length - 3; i++)
                {
                    if (i < 10)
                        datalbl_fecha.Text = datalbl_fecha.Text + elviaje.fecha[i];
                    else if (i > 10)
                        datalbl_hora.Text = datalbl_hora.Text + elviaje.fecha[i];
                }
                datalbconductor.Text = elviaje.usuario().nombre.ToString() + " " + elviaje.usuario().apellidos.ToString();
                datalbl_precio.Text = elviaje.precio.ToString();
                datalblCoche.Text = elviaje.coche.modelo;
                valoracionm();
            }

        }

        private void valoracionm()
        {
            string imagen1 = "~/Recursos/1estrella.png";
            string imagen2 = "~/Recursos/2estrella.png";
            string imagen3 = "~/Recursos/3estrella.png";
            string imagen4 = "~/Recursos/4estrella.png";
            string imagen5 = "~/Recursos/5estrella.png";
            string imagenu = "~/Recursos/birreteu.png";


            int i = elviaje.usuario().valmedia();
            if (i == 1)
            {
                dataValoracion.ImageUrl = imagen1;
            }
            else if (i == 2)
            {
                dataValoracion.ImageUrl = imagen2;

            }
            else if (i == 3)
            {
                dataValoracion.ImageUrl = imagen3;

            }
            else if (i == 4)
            {
                dataValoracion.ImageUrl = imagen4;

            }
            else if (i == 5)
            {
                dataValoracion.ImageUrl = imagen5;

            }
            else
            {
                dataValoracion.ImageUrl = imagenu;
            }

        }
    }
}