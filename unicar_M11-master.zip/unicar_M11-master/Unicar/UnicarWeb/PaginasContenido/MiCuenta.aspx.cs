﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data;
using System.Configuration;
using System.Data.SqlClient;



namespace UnicarWeb.PaginasContenido
{
    public partial class MiCuenta : System.Web.UI.Page
    {
        string[] TituloContenido = { "MENSAJES", "VALORACIONES", "MEDALLAS" };
        string[] FichaConductor = { "SOY CONDUCTOR", "HAZTE CONDUCTOR" };
        string correo_micuenta;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["username"] == null)
            {
                /*Evita que se pueda acceder desde el buscador a mi cuenta*/
                Response.Redirect("~/PaginasContenido/Inicio.aspx");
            }
            else if (!IsPostBack)
            {
                EN.Usuario user = (EN.Usuario)Session["username"];
                campo_correo.Text = user.correo;
                campo_nombre.Text = user.nombre;
                campo_apellidos.Text = user.apellidos;
                campo_edad.Text = Convert.ToString(user.edad);
                campo_carrera.Text = user.carrera;
                campo_localidad.Text = user.localidad;
                FichaConductorMulti.ActiveViewIndex = 0;
                EN.Conductor cond = null;

                //EL USUARIO ES CONDUCTOR
                if (user.isConductor(ref cond))
                {
                    FichaConductorMulti.ActiveViewIndex = 0;
                    cond.read();
                    EN.Coche coche = (EN.Coche)cond.car.read();
                    campo_carnet.Text = cond.carnet;
                    campo_fcaducidad.Text = cond.fechaCaducidad;
                    campo_matricula.Text = coche.matricula;
                    campo_pasajeros.Text = coche.nMaxPasajeros.ToString();
                    campo_modelo.Text = coche.modelo;
                    if(coche.foto != "")
                        Image.ImageUrl = coche.foto;



                }
                //EL USUARIO NO ES CONDUCTOR
                else { FichaConductorMulti.ActiveViewIndex = 1; }
                BotonMedalla.CssClass = "btSeleccionado";
                ContenidoAcerca.ActiveViewIndex = 2;
                btViRealizados.CssClass = "btSeleccionado";
                MultiViewViajes.ActiveViewIndex = 0;
                
            }

            rellenaViajes();
            rellenaMensajes();
            rellenaValoraciones();

        }

        protected void rellenaViajes() {
            EN.Usuario user = (EN.Usuario)Session["username"];
            correo_micuenta = user.correo;

            ViajesPreviewRealizados.SelectCommand = "SELECT [Id], [conductor], [origen], [destino], [precio], [fecha], [foto], [coche], c.correo, [matricula], r.correo, [idViaje], [Id], [fecha] FROM [Viaje] v, [Coche], [Conductor] c, [Reserva] r WHERE fecha<convert(datetime,'" + System.DateTime.Now + "',103) and Id=idViaje and conductor=c.correo and coche=matricula and r.correo='" + correo_micuenta + "' and Id not in (select viaje from Valoracion where us_valora = '"+ correo_micuenta +"') order by v.fecha DESC";
            ViajesPreviewProximos.SelectCommand = "SELECT [Id], [conductor], [origen], [destino], [precio], [fecha], [foto], [coche], c.correo, [matricula], r.correo, [idViaje], [Id], [fecha] FROM [Viaje] v, [Coche], [Conductor] c, [Reserva] r WHERE fecha>=convert(datetime,'" + System.DateTime.Now + "',103) and Id=idViaje and conductor=c.correo and coche=matricula and r.correo='" + correo_micuenta + "' order by v.fecha ASC";
            ViajesPreviewPublicados.SelectCommand = "SELECT [Id], [conductor], [origen], [destino], [precio], [fecha], [foto], [coche], [correo], [matricula] FROM [Viaje] v, [Coche], [Conductor] WHERE fecha>=convert(datetime,'" + System.DateTime.Now + "',103) and conductor=correo and coche=matricula and conductor='" + correo_micuenta + "' order by v.fecha ASC";
        }

        protected void rellenaMensajes()
        {
            EN.Usuario user = (EN.Usuario)Session["username"];
            correo_micuenta = user.correo;
            previewMensajes.SelectCommand= "SELECT [emisor], [cuerpo] FROM [Mensajes_Privados] WHERE receptor='"+ user.correo + "' order by fecha DESC";
        }

        protected void rellenaValoraciones()
        {
            EN.Usuario user = (EN.Usuario)Session["username"];
            correo_micuenta = user.correo;
            ViewValoraciones.SelectCommand = "SELECT [us_valora], [comentario], [estrellas] FROM [Valoracion] WHERE us_valorado='" + user.correo + "' order by estrellas DESC";
        }

        protected void Button1_Click(object sender, EventArgs e)
        {

        }

        protected void Button2_Click(object sender, EventArgs e)
        {

        }


        protected void MultiView1_ActiveViewChanged(object sender, EventArgs e)
        {

        }

        protected void BotonUnirse1_Click(object sender, EventArgs e)
        {

        }

        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {

        }

        protected void FichaConductorMulti_ActiveViewChanged(object sender, EventArgs e)
        {

        }


        protected void btHazteCond_Click(object sender, EventArgs e)
        {
            FichaConductorMulti.ActiveViewIndex = 2;
        }

        protected void ButtonEditar_Click(object sender, EventArgs e)
        {
            bool registroHecho = false;
            EN.Usuario user = (EN.Usuario)Session["username"];
            user.nombre = campo_nombre.Text;
            user.apellidos = campo_apellidos.Text;
            user.edad = Convert.ToInt32(campo_edad.Text);
            user.carrera = campo_carrera.Text;
            user.localidad = campo_localidad.Text;
            user.update();

            EN.Conductor cond = null;


            //EL USUARIO SE ESTÁ REGISTRANDO COMO CONDUCTOR
            if (FichaConductorMulti.ActiveViewIndex == 2)
            {
                string fileName = String.Empty;
                if (FileUpload2.HasFile)
                {
                    fileName = "~/Data/FotosCoche/" + Registro_MATRICULA.Text + FileUpload2.FileName;
                    string imagePath = Server.MapPath(fileName);
                    FileUpload2.SaveAs(imagePath);
                }

                EN.Coche coche = new EN.Coche(Registro_MATRICULA.Text, Registro_MODELO.Text, fileName, Convert.ToInt32(Registro_PASAJEROS.Text));
                coche.create();
                EN.Conductor conductor = new EN.Conductor(user, Registro_DNI.Text, Registro_CADUCIDAD.Text, coche);
                conductor.create();
                registroHecho = true;
                Response.Redirect("Inicio.aspx");

            }



            //EL USUARIO ES CONDUCTOR Y VA A MODIFICAR SUS DATOS
            if (user.isConductor(ref cond) && registroHecho == false)
            {
                cond.read();
                EN.Coche coche = (EN.Coche)cond.car.read();

                cond.fechaCaducidad = campo_fcaducidad.Text;
                coche.modelo = campo_modelo.Text;
                coche.nMaxPasajeros = Convert.ToInt32(campo_pasajeros.Text);
                string fileName = String.Empty;
                if (FileUpload1.HasFile)
                {
                    fileName = "~/Data/FotosCoche/" + campo_matricula.Text + FileUpload1.FileName;
                    string imagePath = Server.MapPath(fileName);
                    FileUpload1.SaveAs(imagePath);
                    coche.foto = fileName;
                }
                cond.car = coche;
                cond.car.update();
                cond.update();
            }
        }


        protected void BotonMedalla_Click(object sender, EventArgs e)
        {
            ContenidoAcerca.ActiveViewIndex = 2;
            BotonMedalla.CssClass = "btSeleccionado";
            BotonMensajes.CssClass = "btCabecera";
            BotonValoraciones.CssClass = "btCabecera";
        }

        protected void BotonValoraciones_Click(object sender, EventArgs e)
        {
            ContenidoAcerca.ActiveViewIndex = 1;
            BotonMedalla.CssClass = "btCabecera";
            BotonMensajes.CssClass = "btCabecera";
            BotonValoraciones.CssClass = "btSeleccionado";
        }

        protected void BotonMensajes_Click(object sender, EventArgs e)
        {
            ContenidoAcerca.ActiveViewIndex = 0;
            BotonMedalla.CssClass = "btCabecera";
            BotonMensajes.CssClass = "btSeleccionado";
            BotonValoraciones.CssClass = "btCabecera";
        }

        protected void ListView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void UnicarDataBase_Selecting(object sender, SqlDataSourceSelectingEventArgs e)
        {

        }


             protected void BorroViaje_Click(Object sender, EventArgs e)
        {

            LinkButton clickedbutton = sender as LinkButton;
            EN.Viaje viaje = new EN.Viaje(Int32.Parse(clickedbutton.CommandName));
            EN.Viaje rviaje = (EN.Viaje)viaje.read();
            rviaje.delete();
            Response.Redirect("~/PaginasContenido/MiCuenta.aspx");

        }


        protected void Valora_Click(Object sender, EventArgs e)
        {
        
            LinkButton boton = sender as LinkButton;
            Response.Redirect("Valoracion.aspx?id=" + Server.UrlEncode(boton.CommandName));
        }

        protected void CancelaReserva_Click(Object sender, EventArgs e)
        {
            EN.Usuario aux = (EN.Usuario)Session["username"];
            LinkButton clickedbutton = sender as LinkButton;

            EN.Viaje viaje = new EN.Viaje(Int32.Parse(clickedbutton.CommandName));
            EN.Viaje rviaje = (EN.Viaje)viaje.read();

            EN.Reserva reserva = new EN.Reserva(aux, rviaje);
            EN.Reserva cancela = (EN.Reserva)reserva.read();
            cancela.delete();
        }

       
        protected void informacion(object sender, EventArgs e)
        {
            LinkButton boton = sender as LinkButton;
            Response.Redirect("InfoViaje.aspx?id=" + Server.UrlEncode(boton.CommandName));
        }

        protected void ListView1_SelectedIndexChanged1(object sender, EventArgs e)
        {

        }

        protected void btViRealizados_Click(object sender, EventArgs e)
        {
            MultiViewViajes.ActiveViewIndex = 0;
            btViRealizados.CssClass = "btSeleccionado";
            btViProximos.CssClass = "btCabecera";
            btViPublicados.CssClass = "btCabecera";
        }

        protected void btViProximos_Click(object sender, EventArgs e)
        {
            MultiViewViajes.ActiveViewIndex = 1;
            btViRealizados.CssClass = "btCabecera";
            btViProximos.CssClass = "btSeleccionado";
            btViPublicados.CssClass = "btCabecera";
        }

        protected void btViPublicados_Click(object sender, EventArgs e)
        {
            MultiViewViajes.ActiveViewIndex = 2;
            btViRealizados.CssClass = "btCabecera";
            btViProximos.CssClass = "btCabecera";
            btViPublicados.CssClass = "btSeleccionado";
        }
    }
    }
