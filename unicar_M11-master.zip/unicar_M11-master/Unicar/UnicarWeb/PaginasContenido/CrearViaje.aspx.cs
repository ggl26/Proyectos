﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace UnicarWeb.PaginasContenido
{
    public partial class CrearViaje : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["username"] == null)
            {
                /*Evita que se pueda acceder desde el buscador a mi cuenta*/
                Response.Redirect("~/PaginasContenido/Inicio.aspx");
            }
            else
            {


                if (!Page.IsPostBack)
                {
                    DataSet dsAutores = new DataSet();
                    EN.Localidad aux = new EN.Localidad("Universidad Alicante");
                    dsAutores = aux.data();

                    ddOrigen.DataSource = dsAutores.Tables["Localidad"].DefaultView;
                    // Asigna el valor a mostrar en el DropDownList
                    ddOrigen.DataTextField = "Localidad";
                    // Asigna el valor del value en el DropDownList
                    ddOrigen.DataValueField = "Localidad";
                    // Llena el DropDownList con los datos
                    ddOrigen.DataBind();

                    ddDestino.DataSource = dsAutores.Tables["Localidad"].DefaultView;
                    // Asigna el valor a mostrar en el DropDownList
                    ddDestino.DataTextField = "Localidad";
                    // Asigna el valor del value en el DropDownList
                    ddDestino.DataValueField = "Localidad";
                    // Llena el DropDownList con los datos
                    ddDestino.DataBind();
                    //tbFecha.Text = "DD/MM/AAAA";
                    CalendarExtender1.StartDate = System.DateTime.Now.Date;
                    CalendarExtender1.SelectedDate = System.DateTime.Now.Date;


                    CargarCombosHoras();
                    ddDestino.SelectedIndex = 1;



                }

                btNoFumador.Click += new ImageClickEventHandler(FiltroBtn_Click);
                btNoHablador.Click += new ImageClickEventHandler(FiltroBtn_Click);
                btMusica.Click += new ImageClickEventHandler(FiltroBtn_Click);
                btEquipajePesado.Click += new ImageClickEventHandler(FiltroBtn_Click);
                btDiscapacidad.Click += new ImageClickEventHandler(FiltroBtn_Click);
                btWifi.Click += new ImageClickEventHandler(FiltroBtn_Click);



                ddDestino.SelectedIndexChanged += new EventHandler(Origen_Destino_Changed);
                ddOrigen.SelectedIndexChanged += new EventHandler(Origen_Destino_Changed);
                cbSoloIda.CheckedChanged += new EventHandler(IdaBtn_Click);
                cbIdaVuelta.CheckedChanged += new EventHandler(IdaBtn_Click);

                btBuscar.Click += new EventHandler(CreaViaje);


            }
        }

        private void CargarCombosHoras()
        {
            for (var i = 0; i < 24; i++)
            {
                if (i < 10)
                    cmbHora.Items.Add(new ListItem("0" + i.ToString(), "0" + i.ToString()));
                else
                    cmbHora.Items.Add(new ListItem(i.ToString(), i.ToString()));

            }

            for (var i = 0; i < 60; i++)
            {
                if (i < 10)
                    cmbMin.Items.Add(new ListItem("0" + i.ToString(), "0" + i.ToString()));
                else
                    cmbMin.Items.Add(new ListItem(i.ToString(), i.ToString()));
            }

            for (var i = 1; i < 5; i++)
            {
                ddPlazas.Items.Add(new ListItem(i.ToString(), i.ToString()));
            }


        }

        void FiltroBtn_Click(Object sender, EventArgs e)
        {
            ImageButton clickedButton = (ImageButton)sender;

            if (clickedButton.BorderWidth == 0)
            {
                clickedButton.BorderWidth = 2;
                clickedButton.Height = 26;
                clickedButton.Width = 26;
            }
            else
            {
                clickedButton.BorderWidth = 0;
                clickedButton.Height = 30;
                clickedButton.Width = 30;
            }
        }

        void IdaBtn_Click(Object sender, EventArgs e)
        {

            CheckBox clickedButton = sender as CheckBox;

            if (clickedButton == cbIdaVuelta)
            {
                cbSoloIda.Checked = !cbIdaVuelta.Checked;
            }
            else
            {
                cbIdaVuelta.Checked = !cbSoloIda.Checked;

            }

        }

        void Origen_Destino_Changed(Object sender, EventArgs e)
        {
            DropDownList clickedButton = sender as DropDownList;
            if (clickedButton.SelectedIndex != 0)
            {
                if (clickedButton == ddDestino)
                    ddOrigen.SelectedIndex = 0;
                else
                    ddDestino.SelectedIndex = 0;
            }
            else
            {
                if (ddOrigen.SelectedIndex == ddDestino.SelectedIndex)

                {
                    ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('" + "Por favor indica un origen diferente al destino" + "');", true);
                    ddDestino.SelectedIndex = 1;
                }
            }
        }



        void CreaViaje(object sender, EventArgs e)
        {

            EN.Viaje en;
            EN.Usuario usuario = (EN.Usuario)Session["username"];


            EN.Conductor cond = null;
           
            if (usuario.isConductor(ref cond))
            {
                en = new EN.Viaje();
                en.origen = ddOrigen.SelectedValue.ToString();
                en.destino = ddDestino.SelectedValue.ToString();
                en.plazas = Int32.Parse(ddPlazas.SelectedValue.ToString());
                en.fecha = tbFecha.Text + " "+cmbHora.Text+":"+ cmbMin.Text +":00";
                en.conductor = cond;
                en.coche = cond.car;

                EN.Localidad localidad, loc;

                if (en.origen == "Universidad Alicante")
                    localidad = new EN.Localidad(en.destino);
                else
                    localidad = new EN.Localidad(en.origen);

                loc = (EN.Localidad)localidad.read();

                en.precio = loc.precio;


                en.create();

                if (btNoFumador.BorderWidth == 2)
                {
                    EN.Filtro filtro = new EN.Filtro(4);
                    filtro.read();
                    filtro.anyadeFiltroAViaje(en.idViaje);
                }
                if (btNoHablador.BorderWidth == 2)
                {
                    EN.Filtro filtro = new EN.Filtro(5);
                    filtro.read();
                    filtro.anyadeFiltroAViaje(en.idViaje);
                }
                if (btMusica.BorderWidth == 2)
                {
                    EN.Filtro filtro = new EN.Filtro(3);
                    filtro.read();
                    filtro.anyadeFiltroAViaje(en.idViaje);
                }
                if (btEquipajePesado.BorderWidth == 2)
                {
                    EN.Filtro filtro = new EN.Filtro(2);
                    filtro.read();
                    filtro.anyadeFiltroAViaje(en.idViaje);
                }
                if (btDiscapacidad.BorderWidth == 2)
                {
                    EN.Filtro filtro = new EN.Filtro(1);
                    filtro.read();
                    filtro.anyadeFiltroAViaje(en.idViaje);
                }
                if (btWifi.BorderWidth == 2)
                {
                    EN.Filtro filtro = new EN.Filtro(6);
                    filtro.read();
                    filtro.anyadeFiltroAViaje(en.idViaje);
                }

                Response.Redirect("~/PaginasContenido/MiCuenta.aspx");



            }
            else
            {
                //CONTROLAR ERROR SI NO ES CONDUCTOR
                Response.Redirect("~/PaginasContenido/MiCuenta.aspx");
            }
        }

    }
}
