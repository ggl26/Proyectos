﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace UnicarWeb.PaginasContenido
{
    public partial class IniciarSesion : System.Web.UI.Page
    {

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void RegistrarUsuario_Click(object sender, EventArgs e)
        {
            string usuario, contraseña;
            usuario = TextBoxUsuario.Text;
            contraseña = TextBoxConstraseña.Text;
            EN.Usuario user = (EN.Usuario)EN.Usuario.read(usuario);
            if (user != null && user.password == contraseña)
            {
                Session["username"] = user;
                Response.Redirect("Inicio.aspx");
            }
            else {
                lblError.Visible = true;
            }
        }

        protected void Registrarme(object sender, EventArgs e)
        {
            LinkButton boton = sender as LinkButton;
            Response.Redirect("~/PaginasContenido/Registrarme.aspx");
        }
    }
}