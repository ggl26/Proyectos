﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using System.IO;
using EN;

namespace UnicarWeb.PaginasContenido
{
    public partial class InfoViaje : System.Web.UI.Page
    {
        private EN.Viaje elviaje;

        protected void Page_Load(object sender, EventArgs e)
        {

            if (Request.QueryString["id"] != "")
            {
                EN.Viaje en = new EN.Viaje(Int32.Parse(Request.QueryString["id"].ToString()));
                elviaje = (EN.Viaje)en.read();
                if (Session["username"] == null)
                {
                    //Response.Redirect("~/PaginasContenido/IniciarSesion.aspx");
                }
                else
                {
                    EN.Usuario aux = (EN.Usuario)Session["username"];


                    LinkButton clickedbutton = sender as LinkButton;


                    EN.Reserva reserva = new Reserva(aux, elviaje);

                    bool reservado = reserva.consulta();

                    if (reservado)
                    {
                        btApuntar.Text = "Anular";
                    }

                    if (elviaje.conductor.user.correo == aux.correo)
                    {
                        btApuntar.Text = "Anular";
                    }
                }
            }

            if (!Page.IsPostBack)
            {




                CargaData();
                DataTable dt = elviaje.sugerencia();
                DataTable df = elviaje.filtro();

                repeater1.DataSource = dt;
                repeater1.DataBind();

                repeaterfiltro.DataSource = df;
                repeaterfiltro.DataBind();
                datalblLibres.Text = (Int32.Parse(datalbl_plazas.Text) - elviaje.ocupadas()).ToString();
                imagen();



                string correo = elviaje.correo();
                int unicode = 0;
                foreach (char c in correo)
                {
                    unicode = unicode + c;
                }

                datalbconductor.PostBackUrl = "InfoUsuario.aspx?user=" + Server.UrlEncode(correo);// unicode.ToString());

                if (lblLibres.Text == "0")
                    btApuntar.Enabled = false;


            }
            btApuntar.Click += new EventHandler(MeApunto_Click);



        }

        protected void MeApunto_Click(Object sender, EventArgs e)
        {

            if (Session["username"] == null)
            {
                Response.Redirect("~/PaginasContenido/IniciarSesion.aspx");
            }
            else
            {
                //tring usuario = ;
                EN.Usuario aux = (EN.Usuario)Session["username"];


                LinkButton clickedbutton = sender as LinkButton;

               
                EN.Reserva reserva = new Reserva(aux, elviaje);

                bool reservado = reserva.consulta();

                if (elviaje.conductor.user.correo == aux.correo)
                {
                    elviaje.delete();
                    Response.Redirect("~/PaginasContenido/MiCuenta.aspx");
                }

                if (reservado)
                {
                    if (btApuntar.Text == "Anular")
                    {
                        reserva.delete();
                        reservado = reserva.consulta();
                        Response.Redirect("~/PaginasContenido/MiCuenta.aspx");

                        if (reservado)
                        {
                            btApuntar.Text ="Apuntado";
                        }
                        else
                        {
                            btApuntar.Text = "Me Apunto!";

                        }
                    }
                    else
                        btApuntar.Text = "Apuntado";
                }
                else
                {
                    reserva.create();
                    reservado = reserva.consulta();

                    if (!reservado)
                    {
                        btApuntar.Text = "Error";
                    }
                    else
                    {
                        btApuntar.Text = "Reservado!";

                    }
                }

            }
        }
        protected void rdatabound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)

            {
                Repeater orepeater = (Repeater)sender;

                Label conten = (Label)e.Item.FindControl("LabelPrecio3");

                EN.Viaje list = new EN.Viaje(Int32.Parse(conten.AccessKey));

                DataTable dt = list.filtro();

                Repeater srepeater = new Repeater();

                srepeater = (Repeater)e.Item.FindControl("repeaterfiltros");

                srepeater.DataSource = dt;
                srepeater.DataBind();

                Panel control = e.Item.FindControl("contenedor_sugerencias") as Panel;
                if (control != null)
                    control.Attributes.Add("onclick", "location.href='InfoViaje.aspx?id=" + Server.UrlEncode(conten.AccessKey) + "'");
            }


        }

        protected void Repeater_ItemCommand(Object sender, RepeaterCommandEventArgs e)
        {
            if (e.CommandName == "btnHidden_OnClick")
            {
                Repeater orepeater = (Repeater)sender;

                Label conten = (Label)e.Item.FindControl("LabelPrecio3");

                Response.Redirect("InfoViaje.aspx?id=" + Server.UrlEncode(conten.AccessKey));
            }
        }
        private void CargaData()
        {
            if (lblDestino.Text != "")
            {
                datalbl_destino.Text = elviaje.destino;
                datalbl_origen.Text = elviaje.origen;
                datalbl_plazas.Text = elviaje.plazas.ToString();
                datalbl_precio.Text = elviaje.precio.ToString();
                for (int i = 0; i < elviaje.fecha.Length - 3; i++)
                {
                    if (i < 10)
                        datalbl_fecha.Text = datalbl_fecha.Text + elviaje.fecha[i];
                    else if (i > 10)
                        datalbl_hora.Text = datalbl_hora.Text + elviaje.fecha[i];
                }
                datalbconductor.Text = elviaje.usuario().nombre.ToString() + " " + elviaje.usuario().apellidos.ToString();
                datalbl_precio.Text = elviaje.precio.ToString();
                datalblCoche.Text = elviaje.coche.modelo;
                Image1.ImageUrl = elviaje.conductor.car.foto;
                valoracionm();
            }

        }

        private void valoracionm()
        {
            string imagen1 = "~/Recursos/1estrella.png";
            string imagen2 = "~/Recursos/2estrella.png";
            string imagen3 = "~/Recursos/3estrella.png";
            string imagen4 = "~/Recursos/4estrella.png";
            string imagen5 = "~/Recursos/5estrella.png";
            string imagenu = "~/Recursos/birreteu.png";


            int i = elviaje.usuario().valmedia();
            if (i == 1)
            {
                dataValoracion.ImageUrl = imagen1;
            }
            else if (i == 2)
            {
                dataValoracion.ImageUrl = imagen2;

            }
            else if (i == 3)
            {
                dataValoracion.ImageUrl = imagen3;

            }
            else if (i == 4)
            {
                dataValoracion.ImageUrl = imagen4;

            }
            else if (i == 5)
            {
                dataValoracion.ImageUrl = imagen5;

            }
            else
            {
                dataValoracion.ImageUrl = imagenu;
            }

        }

        private void imagen()
        {
            string imagen1 = "~/Recursos/birrete1a.png";
            string imagen2 = "~/Recursos/birrete2a.png";
            string imagen3 = "~/Recursos/birrete3a.png";
            string imagen4 = "~/Recursos/birrete4a.png";
            string imagen5 = "~/Recursos/birrete5a.png";
            string imagenu = "~/Recursos/birreteu.png";

            int i = Int32.Parse(datalblLibres.Text);
            if (i == 1)
            {
                ImagenBirrete.ImageUrl = imagen1;
            }
            else if (i == 2)
            {
                ImagenBirrete.ImageUrl = imagen2;

            }
            else if (i == 3)
            {
                ImagenBirrete.ImageUrl = imagen3;

            }
            else if (i == 4)
            {
                ImagenBirrete.ImageUrl = imagen4;

            }
            else if (i == 5)
            {
                ImagenBirrete.ImageUrl = imagen5;

            }
            else
            {
                ImagenBirrete.ImageUrl = imagenu;
            }
        }



        protected void informacion(object sender, EventArgs e)
        {
            LinkButton boton = sender as LinkButton;
            EN.Usuario usuario = elviaje.usuario();

            string correo = elviaje.usuario().correo;
            /*int unicode = 0;
            foreach(char c in correo)
            {
                unicode = unicode + c;
            }*/

            boton.PostBackUrl = "InfoUsuario.aspx?id=" + Server.UrlEncode(correo);
        }

        protected void datalbconductor_Click(object sender, EventArgs e)
        {
            LinkButton boton = sender as LinkButton;
            EN.Usuario usuario = elviaje.usuario();

            string correo = elviaje.usuario().correo;
            /*int unicode = 0;
            foreach(char c in correo)
            {
                unicode = unicode + c;
            }*/

            boton.PostBackUrl = "InfoUsuario.aspx?id=" + Server.UrlEncode(correo);
        }
        
        protected void contactarClicked()
        {
            Session["receptorChat"] = elviaje.conductor.user.correo.ToString();
            Response.Redirect("Mensajes.aspx");
        }
    }
}