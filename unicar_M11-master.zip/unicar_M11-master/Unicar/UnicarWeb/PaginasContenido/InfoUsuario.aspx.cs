﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace UnicarWeb.PaginasContenido
{
    public partial class InfoUsuario : System.Web.UI.Page
    {
        string [] TituloContenido = { "VALORACIONES", "MEDALLAS" };
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {
                string email = Server.UrlDecode(Request.QueryString["user"]);
                ContenidoAcerca.ActiveViewIndex = 0;
                EN.Usuario usuario =(EN.Usuario) EN.Usuario.read(email);
                EN.Conductor  cond = null;
                
                CorreoText.Text = usuario.correo;
                NombreText.Text = usuario.nombre;
                ApellidosText.Text = usuario.apellidos;
                EdadText.Text = usuario.edad.ToString();
                LocalidadText.Text = usuario.localidad;
                valoracionm(usuario);
                ViajesPasText.Text = usuario.viajes(usuario.correo).ToString();   //falta por añadir

                DataTable viajes = EN.Viaje.listarViajes();
                ListadoViajes.DataSource = viajes;
                ListadoViajes.DataBind();
                DataTable valoraciones = EN.Valoracion.listarValoracionesUsuario(usuario.correo);
                ListViewValoracion.DataSource = valoraciones;
                ListViewValoracion.DataBind();
                DataTable medallas_usu = EN.Usuario.listarMedallas(usuario.correo);
                ListViewMedallas.DataSource = medallas_usu;
                ListViewMedallas.DataBind();
                if (usuario.isConductor(ref cond))//si el usuario es conductor mostramos dicho panel con sus datos
                {
                    Conductor.Visible = true;
                    
                    Coche.ImageUrl = cond.car.foto;
                    CocheText.Text = cond.car.modelo;
                    PlazasText.Text = cond.car.nMaxPasajeros.ToString();
                    ViajesCondText.Text = cond.viajes(usuario.correo).ToString(); // falta por añadir
                    DataTable medallas_cond = EN.Conductor.listarMedallas(usuario.correo);
                    LVMedallas_Cond.DataSource = medallas_cond;
                    LVMedallas_Cond.DataBind();
                }
                Session["email"] = CorreoText.ToString();
            }
        }

        protected void informacion(object sender, EventArgs e)
        {
            LinkButton boton = sender as LinkButton;
            Response.Redirect("InfoViaje.aspx?id=" + Server.UrlEncode(boton.CommandName));
        }

        protected void FlechaDer_Click(object sender, ImageClickEventArgs e)
        {
            if (ContenidoAcerca.ActiveViewIndex < 1)
            {
                ContenidoAcerca.ActiveViewIndex++;
            }
            else
            {
                ContenidoAcerca.ActiveViewIndex = 0;
            }
            ContenidoLabel.Text = TituloContenido[ContenidoAcerca.ActiveViewIndex];
        }

        protected void FlechaIzq_Click(object sender, ImageClickEventArgs e)
        {
            if (ContenidoAcerca.ActiveViewIndex > 0)
                ContenidoAcerca.ActiveViewIndex--;  
            else
                ContenidoAcerca.ActiveViewIndex = 1;
            ContenidoLabel.Text = TituloContenido[ContenidoAcerca.ActiveViewIndex];
        }

        protected void ContactarButton_Click(object sender, ImageClickEventArgs e)
        {
            Response.Redirect("Mensajes.aspx");
        }

        private void valoracionm(EN.Usuario usuario)
        {
            string imagen1 = "~/Recursos/1estrella.png";
            string imagen2 = "~/Recursos/2estrella.png";
            string imagen3 = "~/Recursos/3estrella.png";
            string imagen4 = "~/Recursos/4estrella.png";
            string imagen5 = "~/Recursos/5estrella.png";
            string imagenu = "~/Recursos/birreteu.png";


            int i = usuario.valmedia();
            if (i == 1)
            {
                ValMediaImagen.ImageUrl = imagen1;
            }
            else if (i == 2)
            {
                ValMediaImagen.ImageUrl = imagen2;

            }
            else if (i == 3)
            {
                ValMediaImagen.ImageUrl = imagen3;

            }
            else if (i == 4)
            {
                ValMediaImagen.ImageUrl = imagen4;

            }
            else if (i == 5)
            {
                ValMediaImagen.ImageUrl = imagen5;

            }
            else
            {
                ValMediaImagen.ImageUrl = imagenu;
            }

        }
        protected void MeApunto_Click(Object sender, EventArgs e)
        {

            if (Session["username"] == null)
            {
                Response.Redirect("IniciarSesion.aspx");
            }
            else
            {
                //tring usuario = ;
                EN.Usuario aux = (EN.Usuario)Session["username"];


                LinkButton clickedbutton = sender as LinkButton;

                EN.Viaje viaje = new EN.Viaje(Int32.Parse(clickedbutton.CommandName));
                EN.Viaje rviaje = (EN.Viaje)viaje.read();

                EN.Reserva reserva = new EN.Reserva(aux, rviaje);

                bool reservado = reserva.consulta();

                if (reservado)
                {
                    //Mensaje error
                }
                else
                {
                    reserva.create();
                    reservado = reserva.consulta();

                    if (!reservado)
                    {
                        //Error
                    }
                }

            }
        }
    }
}