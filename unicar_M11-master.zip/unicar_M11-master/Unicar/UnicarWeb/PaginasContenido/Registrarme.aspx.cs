﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace UnicarWeb.PaginasContenido
{
    public partial class Registrarme : System.Web.UI.Page
    {


        protected void Page_Load(object sender, EventArgs e)
        {
            // Panel1.Visible = false;
        
            CheckBox1.CheckedChanged += new EventHandler(CheckBox1_CheckedChanged);
        }

        protected void CheckBox1_CheckedChanged(object sender, EventArgs e)
        {
            CheckBox che = sender as CheckBox;

            if (che.Checked)
            {
                Panel1.Visible = true;
                RegistrarUsuario.Visible = false;
            }
            else
            {
                Panel1.Visible = false;
                RegistrarUsuario.Visible = true;
            }
        }

        protected void RegistrarUsuario_Click(object sender, EventArgs e)
        {

            if (campo_contrasena.Text == campo_contrasena_comprueba.Text)
            {
                EN.Usuario user = new EN.Usuario(campo_correo.Text, campo_contrasena.Text, campo_nombre.Text, campo_apellido.Text, Convert.ToInt32(campo_edad.Text), campo_localidad.Text);
                if (campo_carrera.Text != "") { user.carrera = campo_carrera.Text; user.sexo = "hombre"; }
                user.create();

                Session["username"] = user;
                Response.Redirect("Inicio.aspx");
            }
        }

        protected void REGISTRO_CONDUCTOR_Click(object sender, EventArgs e)
        {
            if (campo_contrasena.Text == campo_contrasena_comprueba.Text)
            {
                string fileName = String.Empty;
                if (FileUpload1.HasFile)
                {
                    fileName = "~/Data/FotosCoche/" + campo_matricula.Text + FileUpload1.FileName;
                    string imagePath = Server.MapPath(fileName);
                    FileUpload1.SaveAs(imagePath);
                }
                EN.Usuario user = new EN.Usuario(campo_correo.Text, campo_contrasena.Text, campo_nombre.Text, campo_apellido.Text, Convert.ToInt32(campo_edad.Text), campo_localidad.Text);
                if (campo_carrera.Text != "") { user.carrera = campo_carrera.Text; user.sexo = "hombre"; }
                user.create();

                EN.Coche coche = new EN.Coche(campo_matricula.Text,  campo_modelo.Text, fileName, Convert.ToInt32(campo_pasajero.Text));
                coche.create();
                EN.Conductor conductor = new EN.Conductor(user, campo_carnet.Text, campo_caducidad.Text, coche);
                conductor.create();
                Session["username"] = user;
                Response.Redirect("Inicio.aspx");
            }
        }
    }
       
}