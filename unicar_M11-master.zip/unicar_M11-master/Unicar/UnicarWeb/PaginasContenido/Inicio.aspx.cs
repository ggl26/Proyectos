﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using EN;

namespace UnicarWeb.PaginasContenido
{
    public partial class Inicio : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {


            if (!Page.IsPostBack)
            {
                DataSet dsAutores = new DataSet();
                EN.Localidad aux = new EN.Localidad("Universidad Alicante");
                dsAutores = aux.data(); 

                ddOrigen.DataSource = dsAutores.Tables["Localidad"].DefaultView;
                // Asigna el valor a mostrar en el DropDownList
                ddOrigen.DataTextField = "Localidad";
                // Asigna el valor del value en el DropDownList
                ddOrigen.DataValueField = "Localidad";
                // Llena el DropDownList con los datos
                ddOrigen.DataBind();

                ddDestino.DataSource = dsAutores.Tables["Localidad"].DefaultView;
                // Asigna el valor a mostrar en el DropDownList
                ddDestino.DataTextField = "Localidad";
                // Asigna el valor del value en el DropDownList
                ddDestino.DataValueField = "Localidad";
                // Llena el DropDownList con los datos
                ddDestino.DataBind();
                //tbFecha.Text = "DD/MM/AAAA";
                CalendarExtender1.StartDate = System.DateTime.Now.Date;
                CalendarExtender1.SelectedDate = System.DateTime.Now.Date;
                CargarCombosHoras();
                ddDestino.SelectedIndex = 1;
              


            }

            btNoFumador.Click += new ImageClickEventHandler(FiltroBtn_Click);
            btNoHablador.Click += new ImageClickEventHandler(FiltroBtn_Click);
            btMusica.Click += new ImageClickEventHandler(FiltroBtn_Click);
            btEquipajePesado.Click += new ImageClickEventHandler(FiltroBtn_Click);
            btDiscapacidad.Click += new ImageClickEventHandler(FiltroBtn_Click);
            btWifi.Click += new ImageClickEventHandler(FiltroBtn_Click);



            ddDestino.SelectedIndexChanged += new EventHandler(Origen_Destino_Changed);
            ddOrigen.SelectedIndexChanged += new EventHandler(Origen_Destino_Changed);
            cbSoloIda.CheckedChanged += new EventHandler(IdaBtn_Click);
            cbIdaVuelta.CheckedChanged += new EventHandler(IdaBtn_Click);

            btBuscar.Click += new EventHandler(BuscarBtn_Click);

           if (Session["username"] == null)
            {
                ViajesPreview.SelectCommand = "SELECT [Id], [conductor], [origen], [destino], [precio], [fecha], [foto] FROM [Viaje], [Conductor], [Coche] where fecha>=convert(datetime,'" + System.DateTime.Now + "',103) and conductor=correo and coche=matricula order by fecha ASC";
             }
              else
            {
            EN.Usuario user = (EN.Usuario)Session["username"];
              ViajesPreview.SelectCommand = "SELECT [Id], [conductor], [origen], [destino], [precio], [fecha], [foto] FROM [Viaje], [Conductor], [Coche] where fecha>=convert(datetime,'" + System.DateTime.Now + "',103) and conductor=correo and coche=matricula and Id not in (select idViaje from Reserva r where r.correo='"+ user.correo +"' ) and conductor not in ('"+ user.correo +"') order by fecha ASC";
             }
        }

        protected void informacion(object sender, EventArgs e)
        {
            LinkButton boton = sender as LinkButton;
            Response.Redirect("InfoViaje.aspx?id=" + Server.UrlEncode(boton.CommandName));
        }

        private void CargarCombosHoras()
        {
            for (var i = 0; i < 24; i++)
            {
                if (i < 10)
                    cmbHora.Items.Add(new ListItem("0" + i.ToString(), "0" + i.ToString()));
                else
                    cmbHora.Items.Add(new ListItem(i.ToString(), i.ToString()));

            }

            for (var i = 0; i < 60; i++)
            {
                if (i < 10)
                    cmbMin.Items.Add(new ListItem("0" + i.ToString(), "0" + i.ToString()));
                else
                    cmbMin.Items.Add(new ListItem(i.ToString(), i.ToString()));
            }


        }


        void Add(object sender, EventArgs e)
        {
            TextBox clickedbutton = sender as TextBox;
            if (String.IsNullOrWhiteSpace(tbFecha.Text))
                clickedbutton.Text = System.DateTime.Now.Day.ToString() + "/" + System.DateTime.Now.Month.ToString() + "/" + System.DateTime.Now.Year.ToString();

        }

        void FiltroBtn_Click(Object sender, EventArgs e)
        {
            ImageButton clickedButton = (ImageButton)sender;

            if (clickedButton.BorderWidth == 0)
            {
                clickedButton.BorderWidth = 2;
                clickedButton.Height = 26;
                clickedButton.Width = 26;
            }
            else
            {
                clickedButton.BorderWidth = 0;
                clickedButton.Height = 30;
                clickedButton.Width = 30;
            }
        }

        void IdaBtn_Click(Object sender, EventArgs e)
        {

            CheckBox clickedButton = sender as CheckBox;

            if (clickedButton == cbIdaVuelta)
            {
                cbSoloIda.Checked = !cbIdaVuelta.Checked;
            }
            else
            {
                cbIdaVuelta.Checked = !cbSoloIda.Checked;

            }

        }

        void Origen_Destino_Changed(Object sender, EventArgs e)
        {
            DropDownList clickedButton = sender as DropDownList;
            if (clickedButton.SelectedIndex != 0)
            {
                if (clickedButton == ddDestino)
                    ddOrigen.SelectedIndex = 0;
                else
                    ddDestino.SelectedIndex = 0;
            }
            else
            {
                if (ddOrigen.SelectedIndex == ddDestino.SelectedIndex)

                {
                    ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('" + "Por favor indica un origen diferente al destino" + "');", true);
                    ddDestino.SelectedIndex = 1;
                }
            }
        }

        void BuscarBtn_Click(Object sender, EventArgs e)
        {

            int[] i = new int[6];


            if (btWifi.BorderWidth != 0)
            {
                i[5] = 1;

            }
            if (btNoHablador.BorderWidth != 0)
            {
                i[4] = 5;

            }
            if (btNoFumador.BorderWidth != 0)
            {
                i[3] = 4;
            }
            if (btMusica.BorderWidth != 0)
            {
                i[2] = 3;

            }
            if (btEquipajePesado.BorderWidth != 0)
            {
                i[1] = 2;

            }
            if (btDiscapacidad.BorderWidth != 0)
            {
                i[0] = 1;

            }

            string numeros = "";
            string filter = "";
            string filtros_viaje = "";
            string id_filt = "";
            string order = ""; string add = "";
            for (int j = 0; j < i.Length; j++)
            {
                if (i[j] != 0)
                {
                    numeros = numeros + "'" + i[j].ToString() + "',";
                }
            }
            if (numeros != "")
            {
                add = " and id=id_viaje and id_filtro in (";

                for (int j = 0; j < numeros.Length - 1; j++)
                {
                    add = add + numeros[j].ToString();
                }
                add = add + " ) ";
                id_filt = " , count(id_filtro) contador ";
                filtros_viaje = ", filtros_viaje ";
                filter = "select distinct v.*, count(id_filtro) contador from viaje v, filtros_viaje where id = id_viaje" +
               "group by v.id, v.conductor,v.origen,v.destino, v.plazas, v.precio,v.fecha,v.fotocoche ";
                order = " order by contador desc ";
            }






            ViajesPreview.SelectCommand = "SELECT distinct [Id], [conductor] , [origen] , [destino] , [precio] , [fecha], v.fotocoche foto" + id_filt + " FROM [Viaje] v " + filtros_viaje + " WHERE origen='" + ddOrigen.SelectedValue + "' and destino='" + ddDestino.SelectedValue + "'" +
            "and convert(date,fecha)>=convert(date,convert(datetime, '" + tbFecha.Text + " " + cmbHora.SelectedValue + ":" + cmbMin.SelectedValue + ":00',103))" +
            "and not (fecha in (select fecha from viaje where datepart(hh,fecha)<" + cmbHora.SelectedValue + ")" +
            "or fecha  in (select fecha from viaje where datepart(hh, fecha)= " + cmbHora.SelectedValue + " and datepart(mi,fecha)<" + cmbMin.SelectedValue + ")) " + add +
            " group by v.id, v.conductor,v.origen,v.destino, v.plazas, v.precio,v.fecha, v.fotocoche " + order;

            CalendarExtender1.SelectedDate = DateTime.Parse(tbFecha.Text);





        }

        protected void MeApunto_Click(Object sender, EventArgs e) {

            if (Session["username"] == null)
            {
                Response.Redirect("~/PaginasContenido/IniciarSesion.aspx");
            }
            else {
                //tring usuario = ;
                EN.Usuario aux = (EN.Usuario)Session["username"];


                LinkButton clickedbutton = sender as LinkButton;

                EN.Viaje viaje = new EN.Viaje(Int32.Parse(clickedbutton.CommandName));
                EN.Viaje rviaje = (EN.Viaje)viaje.read();

                EN.Reserva reserva = new Reserva(aux, rviaje);

                bool reservado = reserva.consulta();

                if (reservado)
                {
                    //Mensaje error
                }
                else
                {
                     reserva.create();
                    reservado = reserva.consulta();

                    if (!reservado)
                    {
                        //Error
                    }
                }

            }
        }

    }
}