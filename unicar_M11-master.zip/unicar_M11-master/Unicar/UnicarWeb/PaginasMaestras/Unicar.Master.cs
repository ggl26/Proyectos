﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace UnicarWeb
{
    public partial class Unicar : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack) {
                generaMenu();
            }
            
        }

        private void generaMenu() {
            ControlMenu.Items[0].Selectable = false;
            if (Session.IsNewSession || Session["username"]==null)
            {
                ControlMenu.Items[0].Text = "Usuario no validado";
                ControlMenu.Items[0].ChildItems.Add(new MenuItem { Text = "Iniciar sesión", Value = "IniciarSesion", NavigateUrl = "~/PaginasContenido/IniciarSesion.aspx" });
                ControlMenu.Items[0].ChildItems.Add(new MenuItem { Text = "Registrarme", Value = "Registrarme", NavigateUrl = "~/PaginasContenido/Registrarme.aspx" });
            }
            else
            {
                EN.Usuario user = (EN.Usuario)Session["username"];
                ControlMenu.Items[0].Text = user.nombre + " " + user.apellidos;
                ControlMenu.Items[0].ChildItems.Add(new MenuItem { Text = "Mi cuenta", Value = "MiCuenta", NavigateUrl = "~/PaginasContenido/MiCuenta.aspx" });
                ControlMenu.Items[0].ChildItems.Add(new MenuItem { Text = "Mensajes", Value = "Mensajes", NavigateUrl = "~/PaginasContenido/Mensajes.aspx" });
                ControlMenu.Items[0].ChildItems.Add(new MenuItem { Text = "Crear viaje", Value = "CrearViaje", NavigateUrl = "~/PaginasContenido/CrearViaje.aspx" });
                ControlMenu.Items[0].ChildItems.Add(new MenuItem { Text = "Buscar viaje", Value = "BuscarViaje", NavigateUrl = "~/PaginasContenido/Inicio.aspx" });
                ControlMenu.Items[0].ChildItems.Add(new MenuItem { Text = "Cerrar sesión", Value = "CerrarSesion", NavigateUrl = "~/PaginasContenido/CerrarSesion.aspx" });
            }
        }

    }
}
