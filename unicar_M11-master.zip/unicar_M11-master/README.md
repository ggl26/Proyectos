</head>
<body lang="en-US" dir="ltr">
<h1 class="western" align="center">HADA Práctica Grupal</h1>
<p align="center" style="margin-bottom: 0in; line-height: 100%"><br/>

</p>
<h2 class="western" align="center">PROYECTO UNICAR</h2>
<p style="margin-bottom: 0in; line-height: 100%"><br/>

</p>
<p style="margin-bottom: 0in; line-height: 100%"><br/>

</p>
<p style="margin-bottom: 0in; line-height: 100%"><b>DESCRIPCIÓN:</b></p>
<p style="margin-bottom: 0in; line-height: 100%"><br/>

</p>
<p style="margin-bottom: 0in; line-height: 100%">Desarrollamos una
aplicación web que pretende ser un nexo de unión entre
universitarios destinado a la compartición de vehículos en su
camino de ida y vuelta a casa. Constará de una parte PÚBLICA
accesible por todos los navegantes de internet y una parte PRIVADA
sólo accesible si el usuario está logeado/registrado. 
</p>
<p style="margin-bottom: 0in; line-height: 100%"><br/>

</p>
<p style="margin-bottom: 0in; line-height: 100%">En la parte PÚBLICA
el cliente (definimos cliente como persona no registrada/logeada en
la web) accede a una página principal donde se muestra un buscador
de viajes acotado por fechas, franja horaria, lugar de origen, lugar
de destino y preferencias. Además debajo del buscador se mostrarán
los últimos viajes publicados en la web a modo de sugerencias. Por
último, tendrá acceso a leer comentarios de otros usuarios y a la
página de FAQs y condiciones de uso.</p>
<p style="margin-bottom: 0in; line-height: 100%"><br/>

</p>
<p style="margin-bottom: 0in; line-height: 100%">El cliente tendrá
la opción de registrarse para tener acceso a las funcionalidades de
un usuario. Si es un nuevo cliente se mostrará un formulario de
registro con los datos personales, incluyendo su universidad, su
correo de la universidad y el password.</p>
<p style="margin-bottom: 0in; line-height: 100%"><br/>

</p>
<p style="margin-bottom: 0in; line-height: 100%">Registrándose,
parte PRIVADA, el usuario también podrá realizar las siguientes
acciones. Una vez accedido al detalle del viaje el usuario podrá
adjuntarse al viaje, no pudiéndose adjuntar a otros en una misma
franja horaria de duración de este. Además podrá evaluar a otros
usuarios, consultar sus viajes realizados y pendientes. También
podrá ofertar viajes dándose de alta como conductor. Por último
podrá editar su información personal.</p>
<p style="margin-bottom: 0in; line-height: 100%"><br/>

</p>
<p style="margin-bottom: 0in; line-height: 100%"><br/>

</p>
<p style="margin-bottom: 0in; line-height: 100%"><b>PARTE PÚBLICA:</b></p>
<p style="margin-bottom: 0in; line-height: 100%"><br/>

</p>
<p style="margin-bottom: 0in; line-height: 100%">Cuando el interesado
entre en la página sin logearse/registrarse se mostrará la página
principal de la web, que básicamente contiene un buscador para
buscar viajes acotados por una dirección de salida, dirección de
destino, franja horaria y fecha, (se presupone que cada usuario solo
reserva plaza para el mismo). El cliente no podrá reservar plaza si
no se registra.</p>
<p style="margin-bottom: 0in; line-height: 100%"><br/>

</p>
<ul>
	<li/>
<p style="margin-bottom: 0in; line-height: 100%">Listado de
	viajes: se mostraran viajes que todavía tengan huecos disponibles y
	que cumplan las condiciones del buscador. Si el buscador está vacío
	se mostrarán los últimos viajes publicados. Además, si no se
	encuentran viajes para esas restricciones no se mostrará ninguno y
	aparecerá un mensaje de “Viajes no disponibles”.</p>
	<li/>
<p style="margin-bottom: 0in; line-height: 100%">De cada viaje
	se mostrará una vista previa del mismo (hora, destino, precio) y
	haciendo click en él se podrá acceder a información más
	detallada.</p>
	<li/>
<p style="margin-bottom: 0in; line-height: 100%">Una vez
	accedido al detalle del viaje, se mostrará tanto la información
	del conductor y del coche como información del viaje en concreto.
	Recorrido (paradas), precio,  horario y fecha, etc. Además se verán
	los iconos de preferencia como: no fumador, capacidad de equipaje,
	coche silencioso, gusto musical, plaza de minusválido… etc. 
	</p>
	<li/>
<p style="margin-bottom: 0in; line-height: 100%">En el detalle
	del conductor/coche se mostrará la información que tenga
	habilitada como visible, así como sus gustos y medallas o los
	comentarios y valoraciones que otros usuarios han hecho a su perfil.
		</p>
</ul>
<p style="margin-bottom: 0in; line-height: 100%"><br/>

</p>
<p style="margin-bottom: 0in; line-height: 100%">El buscador tendrá
los siguientes campos:</p>
<p style="margin-bottom: 0in; line-height: 100%"><br/>

</p>
<ul>
	<li/>
<p style="margin-bottom: 0in; line-height: 100%">Obligatorios:</p>
	<ul>
		<li/>
<p style="margin-bottom: 0in; line-height: 100%">Origen</p>
		<li/>
<p style="margin-bottom: 0in; line-height: 100%">Destino</p>
		<li/>
<p style="margin-bottom: 0in; line-height: 100%">Fecha 
		</p>
		<li/>
<p style="margin-bottom: 0in; line-height: 100%">Hora</p>
	</ul>
	<p style="margin-bottom: 0in; line-height: 100%"></p>
	<li/>
<p style="margin-bottom: 0in; line-height: 100%">Opcionales:</p>
	<p style="margin-bottom: 0in; line-height: 100%"></p>
	<ul>
		<li/>
<p style="margin-bottom: 0in; line-height: 100%">Filtros:
		Teniendo una serie de filtros definidos (fumador, hablador, musical
		(posibilidad de aportar música), plaza de minusválido, maletas,
		comodidad…) crear iconos/botones que se podrán activar y
		aparecerán debajo de cada viaje según el usuario. Sirven para
		acotar la cantidad de viajes en los que estamos interesados.</p>
		<li/>
<p style="margin-bottom: 0in; line-height: 100%">Viaje
		directo o recorrido. 
		</p>
	</ul>
</ul>
<p style="margin-bottom: 0in; line-height: 100%">   
</p>
<p style="margin-bottom: 0in; line-height: 100%"><b>PARTE PRIVADA</b></p>
<p style="margin-bottom: 0in; line-height: 100%"><br/>

</p>
<p style="margin-bottom: 0in; line-height: 100%">Una vez registrado
el usuario, tendrá acceso a la parte privada de la web. El cliente
podrá realizar las siguientes acciones:</p>
<p style="margin-bottom: 0in; line-height: 100%"><br/>

</p>
<ul>
	<li/>
<p style="margin-bottom: 0in; line-height: 100%">Como usuario:
	(alias pasajero) 
	</p>
	<p style="margin-bottom: 0in; line-height: 100%"></p>
	<ul>
		<li/>
<p style="margin-bottom: 0in; line-height: 100%">Consultar y
		editar información relacionada con su cuenta.</p>
		<li/>
<p style="margin-bottom: 0in; line-height: 100%">Reservar
		asiento en un viaje publicado.</p>
		<li/>
<p style="margin-bottom: 0in; line-height: 100%">Podrá
		consultar y enviar mensajes a conductores. Sobre posibles viajes.</p>
		<li/>
<p style="margin-bottom: 0in; line-height: 100%">Tiene acceso
		a los viajes realizados y podrá evaluar al conductor (empleando un
		sistema de emoticonos que representan el grado            de
		satisfacción del cliente, como puede ser contento, enfadado,
		aburrido…).</p>
		<li/>
<p style="margin-bottom: 0in; line-height: 100%"> Ver
		próximos viajes a los que se ha apuntado, pendientes.</p>
		<li/>
<p style="margin-bottom: 0in; line-height: 100%">Podrá optar
		a registrarse (ampliar su perfil) como conductor, introduciendo
		además una foto de su carné de conducir y coche, matrícula del
		coche, número de pasajeros y una breve descripción del mismo. 
		</p>
		<li/>
<p style="margin-bottom: 0in; line-height: 100%">Podrá
		bloquear/deshacer y consultar la lista de bloqueados.</p>
		<li/>
<p style="margin-bottom: 0in; line-height: 100%">Notificaciones.
				</p>
		<li/>
<p style="margin-bottom: 0in; line-height: 100%">Podrá
		definir sus gustos como “hablador/callado”, “tipo de música”,
		“intereses”, “carrera”... etc.</p>
	</ul>
	<p style="margin-bottom: 0in; line-height: 100%"></p>
	<li/>
<p style="margin-bottom: 0in; line-height: 100%">Como
	conductor:  (amplía las acciones de usuario)</p>
	<p style="margin-bottom: 0in; line-height: 100%"></p>
	<ul>
		<li/>
<p style="margin-bottom: 0in; line-height: 100%">Podrá
		organizar su horario y automatizarlo. (Por ejemplo, publicar todos
		los Martes un viaje de X a Y a las n horas).</p>
		<li/>
<p style="margin-bottom: 0in; line-height: 100%">Proponer
		nuevos viajes.</p>
		<li/>
<p style="margin-bottom: 0in; line-height: 100%">Modificar
		todas las características de su vehículo asociadas a los
		diferentes filtros de búsqueda de la página.</p>
		<li/>
<p style="margin-bottom: 0in; line-height: 100%">Podrá
		consultar las diferentes evaluaciones que ha recibido en sus
		viajes.</p>
		<li/>
<p style="margin-bottom: 0in; line-height: 100%">Gestionar
		sus viajes publicados.</p>
	</ul>
</ul>
<p style="margin-bottom: 0in; line-height: 100%"><br/>

</p>
<p style="margin-bottom: 0in; line-height: 100%"><br/>

</p>
<p style="margin-bottom: 0in; line-height: 100%"><br/>

</p>
<p style="margin-bottom: 0in; line-height: 100%"><br/>

</p>
<p style="margin-bottom: 0in; line-height: 100%">Todos los usuarios
optarán a “Medallas” por sus méritos en la página (Algunas
solo para conductores). Por ejemplo:</p>
<p style="margin-bottom: 0in; line-height: 100%"><br/>

</p>
<ul>
	<li/>
<p style="margin-bottom: 0in; line-height: 100%">El Tardón:
	evaluado como tardón por más de 10 usuarios.</p>
	<li/>
<p style="margin-bottom: 0in; line-height: 100%">El
	Correcaminos: ha realizado más de 100 viajes.</p>
	<li/>
<p style="margin-bottom: 0in; line-height: 100%">El Chistoso:
	evaluado como divertido por más de 10 usuarios.</p>
	<li/>
<p style="margin-bottom: 0in; line-height: 100%">El Mangante:
	no se ha presentado a un viaje más de 3 veces.</p>
</ul>
<p style="margin-bottom: 0in; line-height: 100%">   
</p>
<p style="margin-bottom: 0in; line-height: 100%"><b>LISTADO ENTIDADES
DE NEGOCIO</b></p>
<p style="margin-bottom: 0in; line-height: 100%"><br/>

</p>
<ul>
	<li/>
<p style="margin-bottom: 0in; line-height: 100%">USUARIO:
	usuario registrado en la web.</p>
	<li/>
<p style="margin-bottom: 0in; line-height: 100%">CONDUCTOR:
	usuario registrado como conductor en la web.</p>
	<li/>
<p style="margin-bottom: 0in; line-height: 100%">COCHE: coche
	registrado por un conductor en la web.</p>
	<li/>
<p style="margin-bottom: 0in; line-height: 100%">FILTROS:
	para acotar la lista de viajes según determinadas caractersticas que nos interesen (fumador, mascotas, minusvalidos, equipaje voluminoso...)</p>
	<li/>
<p style="margin-bottom: 0in; line-height: 100%">RESERVA:
	reserva hecha por un usuario de la web.</p>
	<li/>
<p style="margin-bottom: 0in; line-height: 100%">HORARIO: horario de viajes programados o para programar</p>
	<li/>
<p style="margin-bottom: 0in; line-height: 100%">MENSAJE: mensajes entre usuarios para aclarar cosas sobre el viaje</p>
	<li/>
<p style="margin-bottom: 0in; line-height: 100%">VALORACION: valoración del usuario como conductor o pasajero</p>
	<li/>
<p style="margin-bottom: 0in; line-height: 100%">VIAJE_OFERTADO:creación de un viaje</p>
	<li/>
<p style="margin-bottom: 0in; line-height: 100%">MEDALLAS: premios para usuarios por un uso adecuado y continuo de la app</p>
</ul>
<p style="margin-bottom: 0in; line-height: 100%"><br/>

</p>
<p style="margin-bottom: 0in; line-height: 100%"><b>FUNCIONALIDADES</b></p>
<p style="margin-bottom: 0in; line-height: 100%"><br/>

</p>
<ul>
	<li/>
<p style="margin-bottom: 0in; line-height: 100%">Bloqueo de
	usuarios</p>
	<li/>
<p style="margin-bottom: 0in; line-height: 100%">Visibilidad
	de perfiles</p>
</ul>
<p style="margin-bottom: 0in; line-height: 100%"><br/>

</p>
<p style="margin-bottom: 0in; line-height: 100%"><b>POSIBLES MEJORAS</b></p>
<p style="margin-bottom: 0in; line-height: 100%"><br/>

</p>
<ul>
	<li/>
<p style="margin-bottom: 0in; line-height: 100%">Búsqueda de
	usuarios por proximidad.</p>
	<li/>
<p style="margin-bottom: 0in; line-height: 100%"> Algoritmo de
	posibles caminos a realizar para llegar al destino (incluyendo
	posibles paradas para los clientes).</p>
	<li/>
<p style="margin-bottom: 0in; line-height: 100%">Mapa
	orientativo para los usuarios.</p>
	<li/>
<p style="margin-bottom: 0in; line-height: 100%">Verificación
	de usuarios (TIU o DNI).</p>
	<li/>
<p style="margin-bottom: 0in; line-height: 100%">Seguimiento
	de conductores.</p>
	<li/>
<p style="margin-bottom: 0in; line-height: 100%">Los viajes
	ofertados por conductores con los que viajas frecuentemente aparecen
	al principio de la lista. 
	</p>
</ul>
<p style="margin-bottom: 0in; line-height: 100%"><br/>

</p>

<p style="margin-bottom: 0in; line-height: 100%"><b>TAREAS REALIZADAS POR CADA INTEGRANTE DEL GRUPO UNICAR</b></p>

<ul>
	<li>
<p style="margin-bottom: 0in; line-height: 100%">Gonzalo
	Gallego López</p>
	<ul>
		<li/> 
			<p style="margin-bottom: 0in; line-height: 100%"> Ayuda con el diseño de la BBDD. </p>
		<li/> 
			<p style="margin-bottom: 0in; line-height: 100%"> CAD y EN Filtro </p>
		<li/> 
			<p style="margin-bottom: 0in; line-height: 100%"> CAD Y EN Viaje </p>
		<li/>
			<p style="margin-bottom: 0in; line-height: 100%"> CAD y EN Usuario </p>
		<li/>
			<p style="margin-bottom: 0in; line-height: 100%"> CAD y EN Reserva </p>
		<li/>
			<p style="margin-bottom: 0in; line-height: 100%"> Interfaz e implementación de InfoViaje.aspx </p>
		<li/>
			<p style="margin-bottom: 0in; line-height: 100%"> Implementación del buscador </p>
		<li/>
			<p style="margin-bottom: 0in; line-height: 100%"> Implementacion CrearViaje.aspx </p>
		<li/> 
			<p style="margin-bottom: 0in; line-height: 100%"> Master3nidosV2.aspx.</p>
		<li/>
			<p style="margin-bottom: 0in; line-height: 100%"> Logos de UNICAR.</p>
		<li/>
			<p style="margin-bottom: 0in; line-height: 100%"> Presentador del proyecto. </p>
		<li/>
			<p style="margin-bottom: 0in; line-height: 100%"> Ayudas varias </p>
		</ul>
			<br/>
	<li/>
<p style="margin-bottom: 0in; line-height: 100%">Alejandro
	García Rico</p>
	<ul>	
		<li/> 
			<p style="margin-bottom: 0in; line-height: 100%"> Diseño de la base de datos EER </p>
		<li/>
			<p style="margin-bottom: 0in; line-height: 100%"> Bocetos de la Interfaz </p>
		<li/>
			<p style="margin-bottom: 0in; line-height: 100%"> CAD y EN de mensaje y mensaje privado </p>
		<li/>
			<p style="margin-bottom: 0in; line-height: 100%"> Implementación e interfaz de MiCuenta.aspx </p>
		<li/>
			<p style="margin-bottom: 0in; line-height: 100%"> Implementacion e interfaz de Registro.aspx </p>
		<li/>
			<p style="margin-bottom: 0in; line-height: 100%"> Implementación de CrearViaje.aspx </p>
		<li/>
			<p style="margin-bottom: 0in; line-height: 100%"> Interfaz de IniciarSesion.aspx </p>
		<li/>
			<p style="margin-bottom: 0in; line-height: 100%"> Ayuda con Valoración.aspx </p>
		<li/>
			<p style="margin-bottom: 0in; line-height: 100%"> Ayuda en Inicio.aspx.</p>
		<li/>
			<p style="margin-bottom: 0in; line-height: 100%"> CAD Coche.</p>
		<li/>
			<p style="margin-bottom: 0in; line-height: 100%"> Ayudas varias </p>
		</ul>
			<br/>
	<li/>
<p style="margin-bottom: 0in; line-height: 100%">Guillermo
	Serra Ruidíaz</p>
	<ul>
		<li/> 
			<p style="margin-bottom: 0in; line-height: 100%"> CAD y EN Conductor </p>
		<li/>
			<p style="margin-bottom: 0in; line-height: 100%"> CAD Y EN Coche </p>
		<li/>
			<p style="margin-bottom: 0in; line-height: 100%"> CAD y EN Categoria </p>
		<li/>
			<p style="margin-bottom: 0in; line-height: 100%"> Implementación e interfaz Infousuario.aspx </p>
		<li/> 
			<p style="margin-bottom: 0in; line-height: 100%"> Implementación de MR de la base de datos </p>
		<li/>
			<p style="margin-bottom: 0in; line-height: 100%"> Gestion de la base de datos </p>
		<li/>
			<p style="margin-bottom: 0in; line-height: 100%"> Ayudas CAD/EN Valoración, Viaje y Usuario </p>
		<li/>
			<p style="margin-bottom: 0in; line-height: 100%"> Ayudas varias </p>
		</ul>
			<br/>
	<li/>
<p style="margin-bottom: 0in; line-height: 100%">Jose Miguel
	Gómez Lozano</p>
	<ul>
		<li/> 
			<p style="margin-bottom: 0in; line-height: 100%"> CAD y EN Base </p>
		<li/>
			<p style="margin-bottom: 0in; line-height: 100%"> CAD Y EN Valoracion </p>
		<li/>
			<p style="margin-bottom: 0in; line-height: 100%"> Ayuda CAD y EN Viaje </p>
		<li/> 
			<p style="margin-bottom: 0in; line-height: 100%"> Interfaz de Mensajes.aspx </p>
		<li/>
			<p style="margin-bottom: 0in; line-height: 100%"> Implementación de Mensajes.aspx </p>
		<li/>
			<p style="margin-bottom: 0in; line-height: 100%"> Ayudas varias </p>
	</ul>
		<br/>
	<li/>
<p style="margin-bottom: 0in; line-height: 100%">Carlos Vélez
	García (Responsable) </p>
	<ul>
		<li/> 
			<p style="margin-bottom: 0in; line-height: 100%"> Redacción del Proyecto.
			</p>
		<li/>
			<p style="margin-bottom: 0in; line-height: 100%"> Redacción y especificaciones de la Base de Datos </p>
		<li/>
			<p style="margin-bottom: 0in; line-height: 100%"> Ayuda con el diseño EER de la base de datos </p>
		<li/> 
			<p style="margin-bottom: 0in; line-height: 100%"> Creación del esqueleto de la aplicación en VS </p>
		<li/>
			<p style="margin-bottom: 0in; line-height: 100%"> Interfaz e Implementación de Unicar.Master y herederas </p>
		<li/>
			<p style="margin-bottom: 0in; line-height: 100%"> Implementación hoja de estilo </p>
		<li/>
			<p style="margin-bottom: 0in; line-height: 100%"> Interfaz e implementación de Inicio.aspx </p>
		<li/>
			<p style="margin-bottom: 0in; line-height: 100%"> Interfaz e Implementación de Valoracion.aspx </p>
		<li/>
			<p style="margin-bottom: 0in; line-height: 100%"> CerrarSesión.aspx </p>
		<li/>
			<p style="margin-bottom: 0in; line-height: 100%"> Interfaz CrearViaje.aspx </p>
		<li/>
			<p style="margin-bottom: 0in; line-height: 100%"> Presentación y presentador del proyecto. </p>
		<li/>
			<p style="margin-bottom: 0in; line-height: 100%"> Ayudas varias </p>
		</ul>
</ul>
<p style="margin-bottom: 0in; line-height: 100%"><br/>

</p>

<p style="margin-bottom: 0in; line-height: 100%"><b>NOTAS IMPORTANTES</b></p>
<p style="margin-bottom: 0in; line-height: 100%">
</p>
<ul> 
	<li/> 
		<p style="margin-bottom: 0in; line-height: 100%"> La presentación se llama UNICAR.pptx y está ubicada en la carpeta raíz del proyecto.</p>
	<li/>
		<p style="margin-bottom: 0in; line-height: 100%"> Dos usuarios activos en la pagina UNICAR son(email/contraseña): gsr9@alu.ua.es/1234 y agr119@alu.ua.es/hola </p>
	<li/>
		<p style="margin-bottom: 0in; line-height: 100%"> En el tintero se ha quedado 3 cosas. Por una parte, la implementación de un sistema que otorgase medallas a los usuarios activos en la página dependiendo de sus logros que se encargaba Juanan (dejó la asignatura) y no hemos podido llegar a tiempo para terminarlo. Por otra parte, no hemos conseguido implementar los chats de grupo, con lo que por ahora solo es posible realizar chats usuario-usuario. Además, estuvimos debatiendo si era una buena idea que los usuarios pudiesen publicar y apuntarse a viajes por defecto todos los martes por ejemplo. Pensamos que no era una buena idea porque podría confundir más al usuario, asique decidimos no implementarlo. </p>

</ul>
</br>
<p style="margin-bottom: 0in; line-height: 100%"> El equipo UNICAR ha dado el máximo por conseguir implementar una página web que se salía un poco de lo convencional, y aunque nos queda mucho por mejorar, esperamos que tenga un uso real en el futuro. </p>
</br>

<p style="margin-bottom: 0in; line-height: 100%"><b>INTEGRANTES DEL
GRUPO</b></p>
<ul>
	<li>
<p style="margin-bottom: 0in; line-height: 100%">Gonzalo
	Gallego López</p>
	<li/>
<p style="margin-bottom: 0in; line-height: 100%">Alejandro
	García Rico</p>
	<li/>
<p style="margin-bottom: 0in; line-height: 100%">Guillermo
	Serra Ruidíaz</p>
	<li/>
<p style="margin-bottom: 0in; line-height: 100%">Jose Miguel
	Gómez Lozano</p>
	<li/>
<p style="margin-bottom: 0in; line-height: 100%">Carlos Vélez
	García (Responsable)</p>
</ul>
<p style="margin-bottom: 0in; line-height: 100%"><br/>

</p>
</body>
